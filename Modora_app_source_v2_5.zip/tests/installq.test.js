/* MINI 2A tests: install queue model + sequential engine (js/installq.js). Run: node tests/installq.test.js
 * No browser needed. The FAKE bridge runs each command with the real /bin/sh on a fake root in a temp dir (/sdcard and /data/adb are remapped
 * there) with a fake `ksud` on PATH: it succeeds for most zips, fails for any zip named bad*, and sleeps for slow* so cancel can be tested.
 * Nothing here touches a real device. */
"use strict";
var fs = require("fs"), os = require("os"), path = require("path"), cp = require("child_process"), vm = require("vm"), assert = require("assert");
var ASSETS = path.resolve(__dirname, "../app/src/main/assets");
var Q = require(path.join(ASSETS, "js/installq.js"));

var TMP = fs.mkdtempSync(path.join(os.tmpdir(), "instq-")), ROOT = path.join(TMP, "root"), BIN = path.join(TMP, "bin");
fs.mkdirSync(path.join(ROOT, "sdcard/Download"), { recursive: true }); fs.mkdirSync(BIN);
fs.writeFileSync(path.join(BIN, "ksud"),
  "#!/bin/sh\n" +
  'echo "ksud-fake: $1 $2 $3"\n' +
  'case "$3" in\n' +
  "  *slow*) sleep 30;;\n" +
  '  *bad*) if [ -f "' + ROOT + '/fixed" ]; then exit 0; fi; echo "fake failure"; exit 3;;\n' +
  "esac\nexit 0\n", { mode: 493 });
function remap(cmd) { return cmd.replace(/(^|[^A-Za-z0-9_.\/-])\/sdcard/g, "$1" + ROOT + "/sdcard"); }

var recorded;                                   // every command the fake bridge was asked to run
function fakeJob(withKsud) {
  return function (cmd, o) {
    recorded.push(cmd);
    var env = Object.assign({}, process.env, { PATH: (withKsud === false ? "/usr/bin:/bin" : BIN + ":/usr/bin:/bin") });
    if (withKsud === false) env.PATH = TMP + "/empty:/usr/bin:/bin";
    var child = cp.spawn("/bin/sh", ["-c", remap(cmd)], { env: env, detached: true, stdio: ["ignore", "pipe", "pipe"] });
    var out = "", wasCancelled = false;
    function feed(b) { var t = b.toString(); out += t; if (o && o.onOutput) o.onOutput(t, out); }
    child.stdout.on("data", feed); child.stderr.on("data", feed);
    var job = { state: "running", cancel: function () { wasCancelled = true; try { process.kill(-child.pid, "SIGKILL"); } catch (e) {} } };
    job.promise = new Promise(function (res) {
      child.on("close", function (code) { var st = wasCancelled ? "cancelled" : code === 0 ? "done" : "failed"; job.state = st; res({ state: st, ok: st === "done", code: code === null ? -1 : code, out: out, truncated: false, err: "" }); });
    });
    return job;
  };
}
function mk(names, opts) {
  var q = Q.createQueue(opts), logs = [], ends = [], items = [];
  var eng = Q.createEngine(Object.assign({ queue: q, runJob: fakeJob(), log: function (s) { logs.push(s); }, onEnd: function (s) { ends.push(s); }, onItem: function (it, ph) { items.push(ph + ":" + it.name); } }, opts || {}));
  (names || []).forEach(function (n) { var r = q.add({ path: "/sdcard/Download/" + n, source: "scan" }); assert.ok(r.ok, "add " + n); });
  return { q: q, eng: eng, logs: logs, ends: ends, items: items, log: function () { return logs.join(""); } };
}
function zipOf(cmd) { var m = /^ZIP='([^']*)'/.exec(cmd); return m && m[1]; }

var tests = [], failed = 0;
function test(name, fn) { tests.push([name, fn]); }

test("order: items run strictly in queue order, one command each, with [i/n] headers and a progress line", async function () {
  recorded = [];
  var t = mk(["a.zip", "b.zip", "c.zip"]);
  var s = await t.eng.run();
  assert.deepStrictEqual(recorded.map(zipOf), ["/sdcard/Download/a.zip", "/sdcard/Download/b.zip", "/sdcard/Download/c.zip"]);
  var L = t.log();
  assert.ok(L.indexOf("[1/3] a.zip") >= 0 && L.indexOf("[2/3] b.zip") > L.indexOf("[1/3]") && L.indexOf("[3/3] c.zip") > L.indexOf("[2/3]"), "headers in order");
  assert.strictEqual((L.match(/Installing…/g) || []).length, 3, "a progress line per item");
  assert.deepStrictEqual(t.items, ["start:a.zip", "end:a.zip", "start:b.zip", "end:b.zip", "start:c.zip", "end:c.zip"], "strictly sequential: no item starts before the previous ended");
  assert.strictEqual(s.installed, 3);
});

test("max 10: the 11th is refused with a displayable message; option cannot raise the cap", function () {
  var q = Q.createQueue();
  for (var i = 1; i <= 10; i++) assert.ok(q.add({ path: "/sdcard/Download/m" + i + ".zip" }).ok);
  var r = q.add({ path: "/sdcard/Download/m11.zip" });
  assert.strictEqual(r.ok, false); assert.strictEqual(r.reason, "full"); assert.strictEqual(r.msg, "The list is full (max 10 zips)."); assert.strictEqual(q.size(), 10);
  assert.strictEqual(Q.createQueue({ max: 50 }).max, 10);
  assert.strictEqual(Q.createQueue({ max: 3 }).max, 3);
});

test("duplicates: exact normalised path is not added twice and the message is displayable; other invalid paths are refused", function () {
  var q = Q.createQueue();
  assert.ok(q.add({ path: "/sdcard/Download/a.zip" }).ok);
  var d = q.add({ path: "/sdcard/Download/a.zip" });
  assert.strictEqual(d.ok, false); assert.strictEqual(d.reason, "dup"); assert.strictEqual(d.msg, "That zip is already in the list."); assert.strictEqual(d.key, "install.q_dup");
  assert.strictEqual(q.add({ path: "  /sdcard//Download/./a.zip " }).reason, "dup", "normalised spelling is the same path");
  assert.ok(q.add({ path: "/sdcard/Download/A.zip" }).ok, "case differs: a different path");
  assert.strictEqual(q.size(), 2);
  ["", "  ", "/sdcard/Download/x.txt", "/etc/x.zip", "/data/adb/module.zip", "/sdcard/../data/x.zip", "/sdcard/a\nb.zip", "/sdcard/a\u0000b.zip", "relative/x.zip", null, 5].forEach(function (p) {
    var r = q.add({ path: p }); assert.strictEqual(r.ok, false, JSON.stringify(p)); assert.strictEqual(r.reason, "invalid"); assert.ok(r.msg);
  });
  assert.strictEqual(q.size(), 2);
  assert.strictEqual(q.add({ path: "/data/local/tmp/modora_queue/picked-copy.zip" }).ok, true, "Modora-owned staged picker path is allowed");
  assert.strictEqual(q.add({ path: "/data/local/tmp/modora_queue/../escape.zip" }).ok, false);
});

test("queue ops: remove one, clear all, toggle scanned paths, validList", function () {
  var q = Q.createQueue();
  var a = q.toggle({ path: "/sdcard/Download/a.zip", name: "A", ver: "v1", size: 100, source: "scan" });
  assert.ok(a.ok && a.selected && a.item.name === "A" && a.item.ver === "v1" && a.item.size === 100 && a.item.source === "scan" && a.item.owner === "user" && a.item.cleanup === null);
  q.toggle({ path: "/sdcard/Download/b.zip", source: "scan" }); q.toggle({ path: "/sdcard/Download/c.zip", source: "scan" });
  assert.strictEqual(q.toggle({ path: "/sdcard/Download/b.zip" }).selected, false, "second tap deselects");
  assert.deepStrictEqual(q.validList().map(function (x) { return x.name; }), ["A", "c.zip"]);
  assert.strictEqual(q.remove(q.items()[0].id), true); assert.strictEqual(q.remove("/sdcard/Download/nope.zip"), false);
  assert.strictEqual(q.size(), 1); assert.strictEqual(q.clear(), 1); assert.strictEqual(q.size(), 0); assert.deepStrictEqual(q.validList(), []);
  assert.strictEqual(q.toggle({ path: "/data/x.txt" }).selected, false, "toggle of an invalid path selects nothing");
});

test("failure continues: a failing zip does not stop later ones; the summary is right", async function () {
  recorded = []; fs.rmSync(path.join(ROOT, "fixed"), { force: true });
  var t = mk(["a.zip", "bad1.zip", "c.zip"]);
  var s = await t.eng.run();
  assert.strictEqual(recorded.length, 3, "all three ran");
  assert.deepStrictEqual(s.results.map(function (r) { return r.status; }), ["installed", "failed", "installed"]);
  assert.strictEqual(s.results[1].code, 3); assert.strictEqual(s.results[1].reason, "exit");
  assert.deepStrictEqual([s.installed, s.failed, s.skipped, s.notrun], [2, 1, 0, 0]);
  assert.ok(t.log().indexOf("Install command failed (exit 3).") >= 0 && t.log().indexOf("fake failure") >= 0);
  assert.strictEqual(s.cancelled, false); assert.strictEqual(s.refresh, true);
});

test("cancel: stops the active item, no later command runs, remaining items are Not run", async function () {
  recorded = [];
  var t = mk(["a.zip", "slow1.zip", "c.zip", "d.zip"]);
  var p = t.eng.run();
  await new Promise(function (r) { var iv = setInterval(function () { if (recorded.length === 2) { clearInterval(iv); r(); } }, 20); });
  assert.strictEqual(t.eng.cancel(), true); assert.strictEqual(t.eng.cancel(), false, "second cancel is a no-op");
  var s = await p;
  assert.strictEqual(recorded.length, 2, "no command after the cancelled one");
  assert.deepStrictEqual(s.results.map(function (r) { return r.status; }), ["installed", "failed", "notrun", "notrun"]);
  assert.strictEqual(s.results[1].reason, "cancelled"); assert.strictEqual(s.results[1].state, "cancelled");
  assert.strictEqual(s.cancelled, true);
  assert.ok(t.log().indexOf("Install cancelled. The module may be partly installed; refresh the list.") >= 0);
  assert.strictEqual(t.ends.length, 1);
  assert.strictEqual(t.q.locked, false, "queue unlocks after the run");
});

test("cancel between items: nothing further is started", async function () {
  recorded = [];
  var cancelEng;
  var t = mk(["a.zip", "b.zip", "c.zip"], { onItem: function (it, ph) { if (ph === "end" && it.name === "a.zip") cancelEng.cancel(); } });
  cancelEng = t.eng;
  var s = await t.eng.run();
  assert.strictEqual(recorded.length, 1);
  assert.deepStrictEqual(s.results.map(function (r) { return r.status; }), ["installed", "notrun", "notrun"]);
});

test("summary + end action: onEnd fires exactly once per run (not per item); refresh only when something installed", async function () {
  recorded = []; fs.rmSync(path.join(ROOT, "fixed"), { force: true });
  var t = mk(["a.zip", "b.zip", "c.zip"]);
  var s = await t.eng.run();
  assert.strictEqual(t.ends.length, 1); assert.strictEqual(t.ends[0], s); assert.strictEqual(s.refresh, true);
  assert.strictEqual(t.eng.outcomeLabel("installed"), "Installed"); assert.strictEqual(t.eng.outcomeLabel("notrun"), "Not run");
  assert.strictEqual(t.eng.outcomeLabel("failed"), "Failed"); assert.strictEqual(t.eng.outcomeLabel("skipped"), "Skipped");
  var u = mk(["bad1.zip", "bad2.zip"]); var s2 = await u.eng.run();
  assert.strictEqual(s2.refresh, false); assert.strictEqual(u.ends.length, 1); assert.deepStrictEqual([s2.installed, s2.failed], [0, 2]);
  var e = mk([]); var s3 = await e.eng.run(); assert.strictEqual(s3.ran.length, 0); assert.strictEqual(s3.refresh, false);
});

test("retry failed: reruns ONLY failed items; installed ones are untouched; end action fires once more", async function () {
  recorded = []; fs.rmSync(path.join(ROOT, "fixed"), { force: true });
  var t = mk(["a.zip", "bad1.zip", "c.zip", "bad2.zip"]);
  var s1 = await t.eng.run();
  assert.deepStrictEqual(s1.results.map(function (r) { return r.status; }), ["installed", "failed", "installed", "failed"]);
  fs.writeFileSync(path.join(ROOT, "fixed"), "1");               // the fake ksud now succeeds for the bad zips
  recorded = []; t.logs.length = 0;
  var s2 = await t.eng.retryFailed();
  assert.deepStrictEqual(recorded.map(zipOf), ["/sdcard/Download/bad1.zip", "/sdcard/Download/bad2.zip"], "only the failed paths, in order");
  assert.ok(t.log().indexOf("[1/2] bad1.zip") >= 0 && t.log().indexOf("[2/2] bad2.zip") >= 0);
  assert.deepStrictEqual(s2.results.map(function (r) { return r.status; }), ["installed", "installed", "installed", "installed"]);
  assert.deepStrictEqual(s2.ran.length, 2); assert.strictEqual(s2.refresh, true); assert.strictEqual(t.ends.length, 2);
  recorded = []; var s3 = await t.eng.retryFailed(); assert.strictEqual(recorded.length, 0, "nothing failed: nothing runs"); assert.strictEqual(s3.refresh, false);
  fs.rmSync(path.join(ROOT, "fixed"), { force: true });
});

test("retry failed leaves not-run items alone; run() later continues the not-run ones", async function () {
  recorded = []; fs.rmSync(path.join(ROOT, "fixed"), { force: true });
  var t = mk(["bad1.zip", "slow1.zip", "c.zip"]);
  var p = t.eng.run();
  await new Promise(function (r) { var iv = setInterval(function () { if (recorded.length === 2) { clearInterval(iv); r(); } }, 20); });
  t.eng.cancel(); var s = await p;
  assert.deepStrictEqual(s.results.map(function (r) { return r.status; }), ["failed", "failed", "notrun"]);
  recorded = []; fs.writeFileSync(path.join(ROOT, "fixed"), "1");
  await t.eng.retryFailed();
  assert.ok(recorded.every(function (c) { return zipOf(c) !== "/sdcard/Download/c.zip"; }), "retry never touches the not-run item");
  recorded = []; var s2 = await t.eng.run();
  assert.deepStrictEqual(recorded.map(zipOf), ["/sdcard/Download/c.zip"]); assert.strictEqual(s2.results[2].status, "installed");
  fs.rmSync(path.join(ROOT, "fixed"), { force: true });
});

test("command text: byte-identical to home.html installCmd() for awkward paths", function () {
  var html = fs.readFileSync(path.join(ASSETS, "home.html"), "utf8");
  var m = /function installCmd\(path\) \{([\s\S]*?)\n  \}\n/.exec(html); assert.ok(m, "installCmd found in home.html");
  var ctx = { window: {}, console: console }; vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(ASSETS, "js/bridge.js"), "utf8"), ctx);
  var MDctx = ctx.window.MD; assert.ok(MDctx && MDctx.shq);
  var homeCmd = new Function("MD", "return function installCmd(path) {" + m[1] + "\n};")(MDctx);
  ["/sdcard/Download/a.zip", "/sdcard/Download/we ird 'name' <b>x.zip", "/sdcard/$(rm -rf x)`id`.zip", "/sdcard/Download/m;od.zip", "/storage/emulated/0/Download/é ü.zip"].forEach(function (p) {
    assert.strictEqual(Q.installCmd(p), homeCmd(p), p);
  });
  assert.strictEqual(Q.INSTALL_TIMEOUT, 600000);
  assert.ok(/const INSTALL_TIMEOUT = 10 \* 60 \* 1000;/.test(html), "sheet INSTALL_TIMEOUT unchanged");
});

test("command given to the runner is exactly installCmd(path); the path is single-quoted so it cannot inject", async function () {
  var seen = [], q = Q.createQueue();
  q.add({ path: "/sdcard/Download/a'; touch /tmp/pwned; '.zip" });
  var eng = Q.createEngine({ queue: q, runJob: function (cmd, o) { seen.push([cmd, o]); return { cancel: function () {}, promise: Promise.resolve({ state: "done", code: 0, out: "ok\n" }) }; } });
  await eng.run();
  assert.strictEqual(seen[0][0], Q.installCmd("/sdcard/Download/a'; touch /tmp/pwned; '.zip"));
  assert.ok(seen[0][0].indexOf("ZIP='/sdcard/Download/a'\\''; touch /tmp/pwned; '\\''.zip'; ") === 0);
  assert.strictEqual(seen[0][1].timeout, 600000); assert.strictEqual(seen[0][1].maxOut, 100000);
});

test("no root / no installer: 'No ksud/magisk found' fails every item, none is skipped, nothing throws", async function () {
  recorded = [];
  var q = Q.createQueue(), logs = [];
  q.add({ path: "/sdcard/Download/a.zip" }); q.add({ path: "/sdcard/Download/b.zip" });
  var eng = Q.createEngine({ queue: q, runJob: fakeJob(false), log: function (s) { logs.push(s); } });
  var s = await eng.run();
  assert.deepStrictEqual(s.results.map(function (r) { return r.status; }), ["failed", "failed"]);
  assert.ok(logs.join("").indexOf("No ksud/magisk found") >= 0); assert.strictEqual(s.refresh, false);
});

test("no bridge at all and a throwing runner are failed items, never a rejection", async function () {
  var q = Q.createQueue(); q.add({ path: "/sdcard/Download/a.zip" }); q.add({ path: "/sdcard/Download/b.zip" });
  var s = await Q.createEngine({ queue: q }).run();
  assert.deepStrictEqual(s.results.map(function (r) { return r.status + ":" + r.code; }), ["failed:-5", "failed:-5"]);
  var q2 = Q.createQueue(); q2.add({ path: "/sdcard/Download/a.zip" });
  var s2 = await Q.createEngine({ queue: q2, runJob: function () { throw new Error("boom"); } }).run();
  assert.strictEqual(s2.results[0].status, "failed"); assert.strictEqual(s2.results[0].reason, "error");
  var q3 = Q.createQueue(); q3.add({ path: "/sdcard/Download/a.zip" });
  var s3 = await Q.createEngine({ queue: q3, exec: function () { return Promise.resolve({ code: 0, out: "" }); } }).run();   // fallback runner like the sheet's shc()
  assert.strictEqual(s3.results[0].status, "installed");
});

test("timeout state is a failed item (reason timeout) and the queue continues", async function () {
  var states = ["timeout", "done"], n = 0, q = Q.createQueue(), logs = [];
  q.add({ path: "/sdcard/Download/a.zip" }); q.add({ path: "/sdcard/Download/b.zip" });
  var s = await Q.createEngine({ queue: q, log: function (x) { logs.push(x); }, runJob: function () { var st = states[n++]; return { cancel: function () {}, promise: Promise.resolve({ state: st, code: st === "done" ? 0 : -3, out: "" }) }; } }).run();
  assert.deepStrictEqual(s.results.map(function (r) { return r.status + ":" + r.reason; }), ["failed:timeout", "installed:"]);
  assert.ok(logs.join("").indexOf("Install stopped: it ran longer than 10 minutes.") >= 0);
});

test("an item whose path no longer validates is Skipped (no command), later items still run", async function () {
  recorded = [];
  var t = mk(["a.zip", "b.zip", "c.zip"]);
  t.q._raw("q2").path = "/etc/not-allowed.zip";                      // simulate a path that went bad after it was queued
  var s = await t.eng.run();
  assert.deepStrictEqual(s.results.map(function (r) { return r.status; }), ["installed", "skipped", "installed"]);
  assert.strictEqual(recorded.length, 2); assert.deepStrictEqual([s.installed, s.skipped], [2, 1]);
});

test("one run at a time; queue is locked while running and not afterwards", async function () {
  recorded = [];
  var t = mk(["a.zip", "slow1.zip"]);
  var p = t.eng.run();
  assert.strictEqual(t.eng.running, true); assert.strictEqual(await t.eng.run(), null, "second run refused");
  assert.strictEqual(await t.eng.retryFailed(), null);
  var r = t.q.add({ path: "/sdcard/Download/x.zip" }); assert.strictEqual(r.ok, false); assert.strictEqual(r.reason, "locked");
  assert.strictEqual(t.q.remove("q1"), false); assert.strictEqual(t.q.clear(), 0); assert.strictEqual(t.q.toggle({ path: "/sdcard/Download/x.zip" }).reason, "locked");
  await new Promise(function (res) { var iv = setInterval(function () { if (recorded.length === 2) { clearInterval(iv); res(); } }, 20); });
  t.eng.cancel(); await p;
  assert.strictEqual(t.eng.running, false); assert.ok(t.q.add({ path: "/sdcard/Download/x.zip" }).ok);
});

test("picked files: app-owned, fixed PICK_FILE cannot be queued twice or overwritten; user paths are never cleanup targets", async function () {
  var q = Q.createQueue();
  var u = q.add({ path: "/sdcard/Download/a.zip", source: "scan" }).item;
  assert.strictEqual(q.canPick(), true);
  var pk = q.add({ path: Q.PICK_FILE, name: "my module.zip", size: 2048, source: "browse", picked: true });
  assert.ok(pk.ok); assert.strictEqual(pk.item.owner, "app"); assert.deepStrictEqual(pk.item.cleanup, { dir: "/data/local/tmp/modora_install" }); assert.strictEqual(pk.item.name, "my module.zip");
  assert.strictEqual(q.canPick(), false, "Browse must wait: the fixed path is owned by a queued item");
  var again = q.add({ path: Q.PICK_FILE, name: "other.zip", picked: true });
  assert.strictEqual(again.ok, false); assert.ok(again.reason === "dup" || again.reason === "pickbusy"); assert.ok(again.msg);
  assert.strictEqual(q.add({ path: "/data/local/tmp/modora_install/module.zip", picked: false }).ok, false, "same path without the flag is also not double-owned");
  assert.strictEqual(u.owner, "user"); assert.strictEqual(u.cleanup, null);
  assert.deepStrictEqual(q.cleanupList(), [], "queued: nothing is deletable yet");
  var eng = Q.createEngine({ queue: q, runJob: function () { return { cancel: function () {}, promise: Promise.resolve({ state: "done", code: 0, out: "" }) }; } });
  await eng.run();
  assert.deepStrictEqual(q.cleanupList().map(function (x) { return x.dir; }), ["/data/local/tmp/modora_install"], "only the app-owned dir, never a user zip");
  q.remove(pk.item.id); assert.strictEqual(q.canPick(), true);
});

test("items() returns copies: callers cannot mutate queue state", function () {
  var q = Q.createQueue(); q.add({ path: "/sdcard/Download/a.zip" });
  var it = q.items()[0]; it.status = "installed"; it.path = "/etc/x"; assert.strictEqual(q.items()[0].status, "queued"); assert.strictEqual(q.items()[0].path, "/sdcard/Download/a.zip");
});

test("classic script: no modules/DOM; wired into the queue UI; saved-copy logic remains in its own helper", function () {
  var src = fs.readFileSync(path.join(ASSETS, "js/installq.js"), "utf8");
  var code = src.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/gm, "");
  assert.ok(!/^\s*(import|export)\s/m.test(code), "no ES module syntax");
  assert.ok(!/\b(document|localStorage|ksu)\b/.test(code), "no DOM / direct bridge use");
  assert.ok(!/saved|savecopy|Modora\/zips/i.test(code), "no saved-copy logic");
  var html = fs.readFileSync(path.join(ASSETS, "home.html"), "utf8");
  assert.ok(/<script defer src="js\/installq\.js"><\/script>/.test(html));
  assert.ok(!/ type="module"/.test(html));
});

test("i18n: queue keys exist in en.json and fil.json, key sets are identical, placeholders match", function () {
  var en = JSON.parse(fs.readFileSync(path.join(ASSETS, "i18n/en.json"), "utf8")), fil = JSON.parse(fs.readFileSync(path.join(ASSETS, "i18n/fil.json"), "utf8"));
  var ke = Object.keys(en).sort(), kf = Object.keys(fil).sort();
  assert.deepStrictEqual(ke.filter(function (k) { return kf.indexOf(k) < 0; }), [], "keys only in en");
  assert.deepStrictEqual(kf.filter(function (k) { return ke.indexOf(k) < 0; }), [], "keys only in fil");
  assert.strictEqual(ke.length, kf.length);
  Object.keys(Q.KEYS).forEach(function (n) {
    var k = Q.KEYS[n]; assert.ok(en[k] && fil[k], k);
    assert.deepStrictEqual((fil[k].match(/\{\w+\}/g) || []).sort(), (en[k].match(/\{\w+\}/g) || []).sort(), "placeholders of " + k);
  });
  assert.strictEqual(en["install.q_dup"], "That zip is already in the list.");
  assert.strictEqual(en["install.q_out_notrun"], "Not run");
});

(async function () {
  for (var i = 0; i < tests.length; i++) {
    try { await tests[i][1](); console.log("ok   - " + tests[i][0]); }
    catch (e) { failed++; console.log("FAIL - " + tests[i][0] + "\n       " + (e && e.stack || e).toString().split("\n").slice(0, 4).join("\n       ")); }
  }
  fs.rmSync(TMP, { recursive: true, force: true });
  console.log("\n" + (tests.length - failed) + " passed, " + failed + " failed");
  process.exit(failed ? 1 : 0);
})();
