/* MINI 2B tests: saved-ZIP backup core (js/savedcopy.js) + its hooks in the 2A engine. Run: node tests/savedcopy.test.js
 * No browser needed. A FAKE bridge runs every command with the real /bin/sh on a fake root in a temp dir (/sdcard and /data/local/tmp are
 * remapped there; fake `ksud` on PATH). Every executed command is recorded. Nothing here touches a real device. */
"use strict";
var fs = require("fs"), os = require("os"), path = require("path"), cp = require("child_process"), assert = require("assert");
var ASSETS = path.resolve(__dirname, "../app/src/main/assets");
var SC = require(path.join(ASSETS, "js/savedcopy.js")), Q = require(path.join(ASSETS, "js/installq.js"));

var TMP = fs.mkdtempSync(path.join(os.tmpdir(), "savedcopy-")), ROOT = path.join(TMP, "root"), BIN = path.join(TMP, "bin");
var SD = path.join(ROOT, "sdcard"), DL = path.join(SD, "Download"), BK = path.join(SD, "Modora/zips"), LT = path.join(ROOT, "tmp");
fs.mkdirSync(BIN);
fs.writeFileSync(path.join(BIN, "ksud"), "#!/bin/sh\necho \"ksud-fake: $1 $2 $3\"\ncase \"$3\" in *slow*) sleep 30;; *bad*) exit 3;; esac\nexit 0\n", { mode: 493 });
function remap(cmd) {
  return cmd.replace(/(^|[^A-Za-z0-9_.\/-])\/sdcard/g, "$1" + SD).replace(/(^|[^A-Za-z0-9_.\/-])\/storage\/emulated\/0/g, "$1" + SD)
    .replace(/(^|[^A-Za-z0-9_.\/-])\/data\/local\/tmp/g, "$1" + LT);
}
function reset() { fs.rmSync(ROOT, { recursive: true, force: true }); fs.mkdirSync(DL, { recursive: true }); fs.mkdirSync(LT, { recursive: true }); }
var cmds = [], failCp = false, truncCp = false;
function exec(cmd, o) {                          // fake MD.sh: records the command, runs it with the real sh on the fake root
  cmds.push(cmd);
  return new Promise(function (res) {
    var c = remap(cmd);
    if ((failCp || truncCp) && /(^|[ ;&|])cp /.test(c)) {   // inject faults only into the saved-copy cp
      if (failCp) c = c.replace(/(^|[ ;&|])cp ([^;&|]*)/, "$1{ echo 'cp: fake failure'; false; }");
      else c = c.replace(/(^|[ ;&|])cp ('[^']*') ('[^']*')/, "$1{ head -c 3 $2 > $3; true; }");
    }
    cp.execFile("/bin/sh", ["-c", c], { env: Object.assign({}, process.env, { PATH: BIN + ":/usr/bin:/bin" }) }, function (e, so, se) { res({ code: e ? (typeof e.code === "number" ? e.code : -1) : 0, out: String(so) + String(se) }); });
  });
}
function put(p, text) { fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, text); }
function ls(d) { try { return fs.readdirSync(d).sort(); } catch (e) { return []; } }
function saver(extra) { return SC.createSaver(Object.assign({ exec: exec, enabled: function () { return true; }, now: function () { return new Date(2026, 9, 22, 14, 5, 9); } }, extra || {})); }
var T0 = "20261022-140509";

var tests = [], failed = 0;
function test(name, fn) { tests.push([name, fn]); }

/* ---------- names ---------- */
test("sanitizeName: allowed set kept, everything else -> _, .zip preserved, max 100", function () {
  assert.strictEqual(SC.sanitizeName("My Module v1.2-b_3.zip"), "My Module v1.2-b_3.zip");
  assert.strictEqual(SC.sanitizeName("we ird 'name' <b>x.zip"), "we ird _name_ _b_x.zip");
  assert.strictEqual(SC.sanitizeName("a;b$(id)`x`\n\"q\".ZIP"), "a_b__id__x___q_.zip", "shell metacharacters and newline become _, extension normalised");
  assert.strictEqual(SC.sanitizeName("módulo ü 日本.zip"), "m_dulo _ __.zip");
  assert.strictEqual(SC.sanitizeName("noext"), "noext.zip");
  assert.strictEqual(SC.sanitizeName("..zip"), "module.zip"); assert.strictEqual(SC.sanitizeName(".zip"), "module.zip"); assert.strictEqual(SC.sanitizeName(""), "module.zip");
  assert.strictEqual(SC.sanitizeName("/sdcard/Download/x.zip"), "x.zip", "only the basename counts");
  var long = SC.sanitizeName(new Array(300).join("a") + ".zip");
  assert.strictEqual(long.length, 100); assert.ok(/\.zip$/.test(long));
  assert.ok(!/[^A-Za-z0-9._ -]/.test(SC.sanitizeName("%$#@!~^&*()=+[]{}|:,<>?\t\r\n\u0000")));
});

/* ---------- basic saving ---------- */
test("save: creates /sdcard/Modora/zips with mkdir -p, cp BEFORE install, verifies with wc -c, keeps the copy on success", async function () {
  reset(); put(path.join(DL, "a.zip"), "AAAA1234");
  cmds = []; var s = saver();
  var r = await s.prepare({ path: "/sdcard/Download/a.zip" });
  assert.strictEqual(r.state, "saved"); assert.strictEqual(r.created, true); assert.strictEqual(r.target, "/sdcard/Modora/zips/a.zip"); assert.strictEqual(r.size, 8);
  assert.strictEqual(fs.readFileSync(path.join(BK, "a.zip"), "utf8"), "AAAA1234");
  assert.ok(cmds[0] === "mkdir -p '/sdcard/Modora/zips'", "root-shell mkdir -p of the backup dir, quoted: " + cmds[0]);
  assert.ok(cmds.some(function (c) { return /cp '\/sdcard\/Download\/a\.zip' '\/sdcard\/Modora\/zips\/a\.zip'/.test(c); }), "cp with both paths quoted");
  assert.ok(cmds.some(function (c) { return c === "wc -c < '/sdcard/Modora/zips/a.zip' 2>/dev/null"; }), "byte count verified with wc -c");
  var f = await s.finalize(r, "installed"); assert.strictEqual(f.final, "kept"); assert.ok(fs.existsSync(path.join(BK, "a.zip")));
  assert.strictEqual(fs.readFileSync(path.join(DL, "a.zip"), "utf8"), "AAAA1234", "source untouched");
});

test("spaces and quotes in names/paths are handled; copy name is sanitised; /storage/emulated/0 sources work", async function () {
  reset(); var src = path.join(DL, "my 'odd' name $x.zip"); put(src, "12345");
  cmds = []; var r = await saver().prepare({ path: "/sdcard/Download/my 'odd' name $x.zip" });
  assert.strictEqual(r.state, "saved"); assert.strictEqual(r.copyName, "my _odd_ name _x.zip");
  assert.deepStrictEqual(ls(BK), ["my _odd_ name _x.zip"]);
  assert.ok(cmds.some(function (c) { return c.indexOf("cp '/sdcard/Download/my '\\''odd'\\'' name $x.zip' '/sdcard/Modora/zips/my _odd_ name _x.zip'") >= 0; }), "source single-quoted via shq");
  reset(); put(path.join(DL, "e.zip"), "xyz"); var r2 = await saver().prepare({ path: "/storage/emulated/0/Download/e.zip" });
  assert.strictEqual(r2.state, "saved"); assert.deepStrictEqual(ls(BK), ["e.zip"]);
});

test("display name (picked file) is used for the saved name, not the temp path", async function () {
  reset(); put(path.join(LT, "modora_queue/p1.zip"), "picked-data");
  var r = await saver().prepare({ path: "/data/local/tmp/modora_queue/p1.zip", name: "Real Module (v2).zip" });
  assert.strictEqual(r.state, "saved"); assert.strictEqual(r.copyName, "Real Module _v2_.zip"); assert.deepStrictEqual(ls(BK), ["Real Module _v2_.zip"]);
});

/* ---------- reuse / suffix ---------- */
test("same name + same size: reused, not overwritten, never deleted (even when the install fails)", async function () {
  reset(); put(path.join(DL, "a.zip"), "SAME"); put(path.join(BK, "a.zip"), "OLD!");     // same size, different bytes
  var before = fs.statSync(path.join(BK, "a.zip")).mtimeMs;
  var s = saver(), r = await s.prepare({ path: "/sdcard/Download/a.zip" });
  assert.strictEqual(r.state, "reused"); assert.strictEqual(r.created, false); assert.strictEqual(r.target, "/sdcard/Modora/zips/a.zip");
  assert.strictEqual(fs.readFileSync(path.join(BK, "a.zip"), "utf8"), "OLD!", "existing copy NOT overwritten"); assert.strictEqual(fs.statSync(path.join(BK, "a.zip")).mtimeMs, before);
  assert.ok(!cmds.slice(-3).some(function (c) { return /(^|[ ;&|])cp /.test(c); }), "no cp issued for a reuse");
  var f = await s.finalize(r, "failed"); assert.strictEqual(f.final, "reused"); assert.ok(fs.existsSync(path.join(BK, "a.zip")), "pre-existing copy survives a failed install");
  assert.deepStrictEqual(s.owned().created, []);
});

test("same name + different size: _yyyymmdd-hhmmss before .zip; original copy untouched; further collisions get -2", async function () {
  reset(); put(path.join(DL, "a.zip"), "NEW-LONGER"); put(path.join(BK, "a.zip"), "old");
  var s = saver(), r = await s.prepare({ path: "/sdcard/Download/a.zip" });
  assert.strictEqual(r.state, "saved"); assert.strictEqual(r.copyName, "a_" + T0 + ".zip");
  assert.deepStrictEqual(ls(BK), ["a.zip", "a_" + T0 + ".zip"]); assert.strictEqual(fs.readFileSync(path.join(BK, "a.zip"), "utf8"), "old");
  put(path.join(DL, "a.zip"), "THIRD-VERSION"); var r2 = await s.prepare({ path: "/sdcard/Download/a.zip" });     // same second again: must not overwrite the stamped file
  assert.strictEqual(r2.copyName, "a_" + T0 + "-2.zip"); assert.strictEqual(fs.readFileSync(path.join(BK, "a_" + T0 + ".zip"), "utf8"), "NEW-LONGER");
  assert.strictEqual(SC.stamp(new Date(2026, 0, 2, 3, 4, 5)), "20260102-030405");
  put(path.join(DL, "a.zip"), "NEW-LONGER"); var r3 = await s.prepare({ path: "/sdcard/Download/a.zip" });      // an existing stamped copy of the same size is reused
  assert.strictEqual(r3.state, "reused"); assert.strictEqual(r3.copyName, "a_" + T0 + ".zip");
});

test("long names stay <= 100 chars even with the timestamp suffix", async function () {
  reset(); var nm = new Array(120).join("n") + ".zip", base = SC.sanitizeName(nm); put(path.join(DL, nm), "ONE"); put(path.join(BK, base), "different-size");
  var r = await saver().prepare({ path: "/sdcard/Download/" + nm });
  assert.strictEqual(r.state, "saved"); assert.ok(r.copyName.length <= 100, String(r.copyName.length)); assert.ok(r.copyName.indexOf("_" + T0 + ".zip") > 0);
});

/* ---------- verification and failure ---------- */
test("copy failure: warn state, install still proceeds, nothing left behind, source untouched", async function () {
  reset(); put(path.join(DL, "a.zip"), "DATA"); failCp = true;
  var s = saver(), r = await s.prepare({ path: "/sdcard/Download/a.zip" }); failCp = false;
  assert.strictEqual(r.state, "warn"); assert.strictEqual(r.reason, "copy"); assert.deepStrictEqual(ls(BK), []); assert.strictEqual(fs.readFileSync(path.join(DL, "a.zip"), "utf8"), "DATA");
  // through the engine: the warning is logged and the install command STILL runs and succeeds
  reset(); put(path.join(DL, "a.zip"), "DATA"); put(path.join(DL, "b.zip"), "DATA2"); failCp = true;
  var q = Q.createQueue(), logs = [], ran = []; q.add({ path: "/sdcard/Download/a.zip" }); q.add({ path: "/sdcard/Download/b.zip" });
  var sv = saver(), eng = Q.createEngine(Object.assign({ queue: q, log: function (x) { logs.push(x); }, runJob: function (cmd) { ran.push(cmd); return { cancel: function () {}, promise: Promise.resolve({ state: "done", code: 0, out: "" }) }; } }, sv.hooks()));
  var sum = await eng.run(); failCp = false;
  assert.deepStrictEqual(sum.results.map(function (x) { return x.status; }), ["installed", "installed"]); assert.strictEqual(ran.length, 2);
  assert.ok(logs.join("").indexOf("Saved copy: warning (copy); installing anyway.") >= 0); assert.strictEqual(sum.results[0].save.state, "warn");
});

test("size verification: a short/corrupt copy is detected, removed (exact path, created by us) and reported as warn", async function () {
  reset(); put(path.join(DL, "a.zip"), "0123456789"); truncCp = true;
  var r = await saver().prepare({ path: "/sdcard/Download/a.zip" }); truncCp = false;
  assert.strictEqual(r.state, "warn"); assert.strictEqual(r.reason, "verify"); assert.deepStrictEqual(ls(BK), [], "the bad copy was removed"); assert.ok(fs.existsSync(path.join(DL, "a.zip")));
});

test("missing source / mkdir failure: warn, never throws", async function () {
  reset(); var r = await saver().prepare({ path: "/sdcard/Download/missing.zip" }); assert.strictEqual(r.state, "warn"); assert.strictEqual(r.reason, "nosource");
  var r2 = await saver({ exec: function () { return Promise.resolve({ code: 1, out: "" }); } }).prepare({ path: "/sdcard/Download/a.zip" }); assert.strictEqual(r2.state, "warn"); assert.strictEqual(r2.reason, "mkdir");
  var r3 = await saver({ exec: function () { return Promise.reject(new Error("x")); } }).prepare({ path: "/sdcard/Download/a.zip" }); assert.strictEqual(r3.state, "warn");
  var r4 = await SC.createSaver({ exec: null, enabled: function () { return true; } }).prepare({ path: "/sdcard/Download/a.zip" }); assert.strictEqual(r4.state, "warn");
});

/* ---------- failed / cancelled install: delete only our own new copy ---------- */
test("failed install removes ONLY the new copy; user source and pre-existing files survive", async function () {
  reset(); put(path.join(DL, "bad1.zip"), "BAD"); put(path.join(DL, "fresh.zip"), "FRESH"); put(path.join(BK, "keep.zip"), "pre-existing user file"); put(path.join(BK, "bad1.zip"), "other-size");
  var q = Q.createQueue(); q.add({ path: "/sdcard/Download/bad1.zip" }); q.add({ path: "/sdcard/Download/fresh.zip" });
  var sv = saver(), outcomes = { "bad1.zip": "failed", "fresh.zip": "done" };
  var eng = Q.createEngine(Object.assign({ queue: q, runJob: function (cmd) { var st = /bad1/.test(cmd) ? "failed" : "done"; return { cancel: function () {}, promise: Promise.resolve({ state: st, code: st === "done" ? 0 : 3, out: "" }) }; } }, sv.hooks()));
  var sum = await eng.run();
  assert.deepStrictEqual(sum.results.map(function (x) { return x.status; }), ["failed", "installed"]);
  assert.strictEqual(sum.results[0].save.final, "removed"); assert.strictEqual(sum.results[1].save.final, "kept");
  assert.strictEqual(fs.readFileSync(path.join(BK, "keep.zip"), "utf8"), "pre-existing user file", "pre-existing file untouched");
  assert.strictEqual(fs.readFileSync(path.join(BK, "bad1.zip"), "utf8"), "other-size", "same-named pre-existing copy untouched");
  assert.ok(ls(BK).indexOf("bad1_" + T0 + ".zip") < 0, "the stamped new copy of the failed item is gone");
  assert.deepStrictEqual(ls(BK), ["bad1.zip", "fresh.zip", "keep.zip"]); assert.ok(fs.existsSync(path.join(DL, "bad1.zip")) && fs.existsSync(path.join(DL, "fresh.zip")), "originals intact");
  assert.ok(!sv.owned().created.some(function (p) { return /bad1/.test(p); }));
});

test("cancelled install (real shell job, real cancel) removes only the new copy; later items are never copied or run", async function () {
  reset(); put(path.join(DL, "slow1.zip"), "SLOWDATA"); put(path.join(DL, "later.zip"), "LATER"); put(path.join(BK, "mine.zip"), "precious");
  var q = Q.createQueue(); q.add({ path: "/sdcard/Download/slow1.zip" }); q.add({ path: "/sdcard/Download/later.zip" });
  var ran = [];
  function runJob(cmd) {
    ran.push(cmd);
    var child = cp.spawn("/bin/sh", ["-c", remap(cmd)], { env: Object.assign({}, process.env, { PATH: BIN + ":/usr/bin:/bin" }), detached: true, stdio: "ignore" }), wc = false;
    return { cancel: function () { wc = true; try { process.kill(-child.pid, "SIGKILL"); } catch (e) {} },
      promise: new Promise(function (res) { child.on("close", function (c) { res({ state: wc ? "cancelled" : c === 0 ? "done" : "failed", code: c === null ? -1 : c, out: "" }); }); }) };
  }
  var sv = saver(), eng = Q.createEngine(Object.assign({ queue: q, runJob: runJob }, sv.hooks()));
  var p = eng.run();
  await new Promise(function (r) { var iv = setInterval(function () { if (ran.length === 1 && fs.existsSync(path.join(BK, "slow1.zip"))) { clearInterval(iv); r(); } }, 20); });
  assert.ok(fs.existsSync(path.join(BK, "slow1.zip")), "copy exists while installing (made BEFORE the install)");
  eng.cancel(); var sum = await p;
  assert.deepStrictEqual(sum.results.map(function (x) { return x.status; }), ["failed", "notrun"]); assert.strictEqual(sum.results[0].reason, "cancelled");
  assert.strictEqual(sum.results[0].save.final, "removed"); assert.deepStrictEqual(ls(BK), ["mine.zip"], "only the new copy was removed");
  assert.strictEqual(ran.length, 1, "no further install command"); assert.ok(!sum.results[1].save, "the not-run item was never copied");
  assert.ok(fs.existsSync(path.join(DL, "slow1.zip")) && fs.existsSync(path.join(DL, "later.zip")));
});

test("cancel DURING the copy: the install command never starts and the new copy is removed", async function () {
  reset(); put(path.join(DL, "a.zip"), "AAAA"); var q = Q.createQueue(); q.add({ path: "/sdcard/Download/a.zip" }); var ran = 0, eng;
  var sv = saver(); var h = sv.hooks();
  eng = Q.createEngine({ queue: q, runJob: function () { ran++; return { cancel: function () {}, promise: Promise.resolve({ state: "done", code: 0, out: "" }) }; },
    beforeItem: function (it) { return h.beforeItem(it).then(function (r) { eng.cancel(); return r; }); }, afterItem: h.afterItem });
  var sum = await eng.run();
  assert.strictEqual(ran, 0); assert.strictEqual(sum.results[0].status, "notrun"); assert.deepStrictEqual(ls(BK), [], "copy removed"); assert.ok(fs.existsSync(path.join(DL, "a.zip")));
});

test("finalize cannot delete anything this saver did not create (forged records, wrong paths)", async function () {
  reset(); put(path.join(BK, "user.zip"), "U"); put(path.join(DL, "x.zip"), "X"); var s = saver();
  var f1 = await s.finalize({ state: "saved", created: true, target: "/sdcard/Modora/zips/user.zip" }, "failed");
  var f2 = await s.finalize({ state: "saved", created: true, target: "/sdcard/Download/x.zip" }, "failed");
  var f3 = await s.finalize({ state: "saved", created: true, target: "/sdcard/Modora/zips/../../Download/x.zip" }, "failed");
  var f4 = await s.finalize({ state: "reused", created: false, target: "/sdcard/Modora/zips/user.zip" }, "failed");
  assert.deepStrictEqual([f1.final, f2.final, f3.final, f4.final], ["failed", "failed", "failed", "reused"]);
  assert.ok(fs.existsSync(path.join(BK, "user.zip")) && fs.existsSync(path.join(DL, "x.zip")));
  assert.strictEqual((await s.finalize(null, "failed")).final, "");
});

/* ---------- toggles and exclusions ---------- */
test("backup OFF creates nothing (no mkdir, no cp, nothing in /sdcard/Modora)", async function () {
  reset(); put(path.join(DL, "a.zip"), "AAAA"); cmds = [];
  var r = await saver({ enabled: function () { return false; } }).prepare({ path: "/sdcard/Download/a.zip" });
  assert.strictEqual(r.state, "off"); assert.strictEqual(cmds.length, 0); assert.ok(!fs.existsSync(path.join(SD, "Modora")));
  var s = saver({ enabled: function () { return false; } }), q = Q.createQueue(); q.add({ path: "/sdcard/Download/a.zip" }); cmds = [];
  var sum = await Q.createEngine(Object.assign({ queue: q, runJob: function () { return { cancel: function () {}, promise: Promise.resolve({ state: "done", code: 0, out: "" }) }; } }, s.hooks())).run();
  assert.strictEqual(sum.results[0].status, "installed"); assert.strictEqual(cmds.length, 0); assert.ok(!fs.existsSync(path.join(SD, "Modora")));
});

test("a source already inside /sdcard/Modora/zips/ is never copied (either path spelling), and never deleted on failure", async function () {
  reset(); put(path.join(BK, "a.zip"), "AAAA"); cmds = []; var s = saver();
  var r1 = await s.prepare({ path: "/sdcard/Modora/zips/a.zip" }), r2 = await s.prepare({ path: "/storage/emulated/0/Modora/zips/a.zip" }), r3 = await s.prepare({ path: "/sdcard//Modora/./zips/a.zip" });
  [r1, r2, r3].forEach(function (r) { assert.strictEqual(r.state, "skipped"); assert.strictEqual(r.reason, "inbackup"); });
  assert.strictEqual(cmds.length, 0); assert.deepStrictEqual(ls(BK), ["a.zip"]);
  var f = await s.finalize(r1, "failed"); assert.ok(fs.existsSync(path.join(BK, "a.zip"))); assert.notStrictEqual(f.final, "removed");
  assert.strictEqual(SC.isInBackupDir("/sdcard/Modora/zips"), true); assert.strictEqual(SC.isInBackupDir("/sdcard/Modora/zipsX/a.zip"), false);
});

test("sources outside the allowed roots are installed but not copied", async function () {
  reset(); cmds = []; var s = saver();
  assert.strictEqual((await s.prepare({ path: "/data/adb/x.zip" })).reason, "root"); assert.strictEqual((await s.prepare({ path: "/etc/x.zip" })).reason, "root");
  assert.strictEqual(cmds.length, 0);
});

/* ---------- injection ---------- */
test("injection: ; $() backticks, quotes in source paths/names stay inert (real sh, recorded commands); newline/NUL/.. are rejected", async function () {
  reset(); var evil = ["a;touch PWNED1;.zip", "b$(touch PWNED2).zip", "c`touch PWNED3`.zip", "d' ; touch PWNED4 ; '.zip", "e && touch PWNED5.zip", "f\"$(touch PWNED6)\".zip"];
  evil.forEach(function (n) { put(path.join(DL, n), "DATA-" + n.length); });
  var s = saver(); cmds = [];
  for (var i = 0; i < evil.length; i++) { var r = await s.prepare({ path: "/sdcard/Download/" + evil[i] }); assert.strictEqual(r.state, "saved", evil[i]); assert.ok(/^[A-Za-z0-9._ -]+\.zip$/.test(r.copyName), "sanitised: " + r.copyName); }
  var all = [DL, BK, SD, ROOT, process.cwd()]; all.forEach(function (d) { ls(d).forEach(function (f) { assert.ok(!/^PWNED/.test(f), "injected command ran: " + f); }); });
  cmds.forEach(function (c) { if (/cp /.test(c)) assert.ok(/cp '[^]*' '\/sdcard\/Modora\/zips\/[A-Za-z0-9._ -]+\.zip'/.test(c), "cp fully quoted: " + c); });
  assert.ok(cmds.some(function (c) { return c.indexOf("cp '/sdcard/Download/b$(touch PWNED2).zip'") >= 0; }), "metacharacters sit inside single quotes");
  assert.ok(cmds.some(function (c) { return c.indexOf("d'\\'' ; touch PWNED4 ; '\\''.zip'") >= 0; }), "embedded quote escaped by shq");
  cmds = [];
  for (var bad of ["/sdcard/Download/a\nb.zip", "/sdcard/Download/a\u0000b.zip", "/sdcard/Download/../../data/x.zip", "relative.zip", "/sdcard/Download/a\rb.zip", ""]) {
    var rr = await s.prepare({ path: bad }); assert.strictEqual(rr.state, "skipped"); assert.strictEqual(rr.reason, "invalid", JSON.stringify(bad));
  }
  assert.strictEqual(cmds.length, 0, "rejected paths never reach the shell");
  var rn = await s.prepare({ path: "/sdcard/Download/a;b.zip", name: "x\n$(touch PWNED7)`id`.zip" });    // hostile DISPLAY name
  assert.ok(rn.state === "warn" || /^[A-Za-z0-9._ -]+\.zip$/.test(rn.copyName)); assert.ok(!fs.existsSync(path.join(DL, "PWNED7")) && !fs.existsSync("PWNED7"));
});

/* ---------- picked files ---------- */
test("stagePicked: unique app-owned temp copies, PICK_FILE reuse by the native picker cannot clobber them, release deletes only the exact temp", async function () {
  reset(); var pick = path.join(LT, "modora_install/module.zip"); put(pick, "FIRST-PICK"); var s = saver();
  var a = await s.stagePicked({ path: SC.PICK_FILE, id: "q1" }); assert.ok(a.ok, a.reason);
  fs.rmSync(path.join(LT, "modora_install"), { recursive: true, force: true }); put(pick, "SECOND-PICK-LONGER");        // native picker wipes + rewrites the fixed file
  var b = await s.stagePicked({ path: SC.PICK_FILE, id: "q2" }); assert.ok(b.ok); assert.notStrictEqual(a.path, b.path);
  assert.ok(a.path.indexOf("/data/local/tmp/modora_queue/") === 0 && /^[A-Za-z0-9._\/-]+\.zip$/.test(a.path));
  assert.strictEqual(fs.readFileSync(path.join(LT, "modora_queue", path.basename(a.path)), "utf8"), "FIRST-PICK", "first copy survived the picker reuse");
  assert.deepStrictEqual(ls(path.join(LT, "modora_queue")).length, 2);
  put(path.join(DL, "u.zip"), "user"); put(path.join(LT, "modora_queue/stranger.zip"), "not ours");
  assert.strictEqual(await s.releaseTemp("/sdcard/Download/u.zip"), false); assert.strictEqual(await s.releaseTemp("/data/local/tmp/modora_queue/stranger.zip"), false, "not registered by this saver");
  assert.strictEqual(await s.releaseTemp("/data/local/tmp/modora_queue/../../../sdcard/Download/u.zip"), false);
  assert.strictEqual(await s.releaseTemp(a.path), true); assert.ok(!fs.existsSync(path.join(LT, "modora_queue", path.basename(a.path)))); assert.ok(fs.existsSync(path.join(LT, "modora_queue", path.basename(b.path))));
  assert.ok(fs.existsSync(path.join(DL, "u.zip")) && fs.existsSync(path.join(LT, "modora_queue/stranger.zip")));
  assert.deepStrictEqual(s.owned().temps, [b.path]);
  assert.strictEqual((await s.stagePicked({ path: "/sdcard/Download/u.zip" })).ok, false, "only the picker file can be staged");
  assert.strictEqual(await s.releaseTemp(b.path), true);
});

test("stagePicked: failed/short copies leave nothing behind and an existing name is never overwritten", async function () {
  reset(); put(path.join(LT, "modora_install/module.zip"), "PICKDATA"); var s = saver(); failCp = true;
  var r = await s.stagePicked({ path: SC.PICK_FILE }); failCp = false; assert.strictEqual(r.ok, false); assert.deepStrictEqual(ls(path.join(LT, "modora_queue")), []); assert.deepStrictEqual(s.owned().temps, []);
  // pre-create every possible name: staging must refuse rather than overwrite
  var s2 = saver({ now: function () { return new Date(1000); } }); var first = await s2.stagePicked({ path: SC.PICK_FILE }); assert.ok(first.ok);
  var s3 = saver({ now: function () { return new Date(1000); } }); var second = await s3.stagePicked({ path: SC.PICK_FILE });
  assert.ok(second.ok ? second.path !== first.path : second.reason === "exists");
  assert.strictEqual(fs.readFileSync(path.join(LT, "modora_queue", path.basename(first.path)), "utf8"), "PICKDATA");
});

/* ---------- setting ---------- */
test("setting md.install.savecopy: default ON, persisted as JSON in localStorage, corrupt value -> ON, memory fallback when storage throws", function () {
  var store = {}, ls1 = { getItem: function (k) { return k in store ? store[k] : null; }, setItem: function (k, v) { store[k] = String(v); }, removeItem: function (k) { delete store[k]; } };
  var st = SC.createSetting({ storage: ls1 }); assert.strictEqual(SC.SETTING_KEY, "md.install.savecopy");
  assert.strictEqual(st.get(), true, "default ON"); assert.strictEqual(st.set(false), true); assert.strictEqual(store["md.install.savecopy"], "false"); assert.strictEqual(st.get(), false);
  assert.strictEqual(SC.createSetting({ storage: ls1 }).get(), false, "survives a new instance (persisted)"); st.set(true); assert.strictEqual(store["md.install.savecopy"], "true");
  store["md.install.savecopy"] = "banana"; assert.strictEqual(st.get(), true, "corrupt -> default"); assert.strictEqual(st.set("yes"), false); assert.strictEqual(st.set(1), false);
  st.set(false); st.reset(); assert.strictEqual(st.get(), true); assert.ok(!("md.install.savecopy" in store));
  var bad = { getItem: function () { throw new Error("denied"); }, setItem: function () { throw new Error("quota"); }, removeItem: function () { throw new Error("x"); } };
  var m = SC.createSetting({ storage: bad }); assert.strictEqual(m.get(), true); assert.strictEqual(m.set(false), true); assert.strictEqual(m.get(), false, "memory fallback"); assert.strictEqual(m.persistent(), false);
  bad.setItem = function (k, v) { store[k] = String(v); }; // storage recovers later in the same session
  assert.strictEqual(m.set(true), true); assert.strictEqual(m.persistent(), true, "persistent storage recovery is reflected"); assert.strictEqual(store["md.install.savecopy"], "true");
  var none = SC.createSetting({ storage: null }); none.set(false); assert.strictEqual(none.get(), false);
  assert.strictEqual(SC.createSetting({ storage: { getItem: function () { return null; } } }).get(), true);
  assert.strictEqual(saver({ enabled: undefined, setting: SC.createSetting({ storage: ls1 }) }).setting.get(), true);
});

test("setting drives the saver by default (enabled() falls back to the setting)", async function () {
  reset(); put(path.join(DL, "a.zip"), "AAAA"); var store = {}, ls1 = { getItem: function (k) { return k in store ? store[k] : null; }, setItem: function (k, v) { store[k] = v; }, removeItem: function () {} };
  var st = SC.createSetting({ storage: ls1 }), s = SC.createSaver({ exec: exec, setting: st, now: function () { return new Date(2026, 0, 1); } });
  st.set(false); assert.strictEqual((await s.prepare({ path: "/sdcard/Download/a.zip" })).state, "off");
  st.set(true); assert.strictEqual((await s.prepare({ path: "/sdcard/Download/a.zip" })).state, "saved");
});

/* ---------- 2A contract unchanged ---------- */
test("2A contract: install command, INSTALL_TIMEOUT, job options and queue results are unchanged by the hooks; hooks are optional", async function () {
  reset(); put(path.join(DL, "a.zip"), "AAAA"); var seen = [];
  var q = Q.createQueue(); q.add({ path: "/sdcard/Download/a.zip" });
  var sv = saver(), eng = Q.createEngine(Object.assign({ queue: q, runJob: function (cmd, o) { seen.push([cmd, o]); return { cancel: function () {}, promise: Promise.resolve({ state: "done", code: 0, out: "ok\n" }) }; } }, sv.hooks()));
  await eng.run();
  assert.strictEqual(seen[0][0], Q.installCmd("/sdcard/Download/a.zip")); assert.strictEqual(seen[0][1].timeout, 600000); assert.strictEqual(seen[0][1].maxOut, 100000);
  var thrower = Q.createEngine({ queue: (function () { var x = Q.createQueue(); x.add({ path: "/sdcard/Download/a.zip" }); return x; })(), runJob: function () { return { cancel: function () {}, promise: Promise.resolve({ state: "done", code: 0, out: "" }) }; },
    beforeItem: function () { throw new Error("boom"); }, afterItem: function () { return Promise.reject(new Error("boom")); } });
  var s2 = await thrower.run(); assert.strictEqual(s2.results[0].status, "installed", "a throwing hook never blocks or fails the install");
  var html = fs.readFileSync(path.join(ASSETS, "home.html"), "utf8");
  assert.ok(/<script defer src="js\/savedcopy\.js"><\/script>/.test(html) && /const INSTALL_TIMEOUT = 10 \* 60 \* 1000;/.test(html));
});

test("classic script: no modules/DOM/direct bridge; no UI or saved-zips listing code; i18n key sets still identical", function () {
  var code = fs.readFileSync(path.join(ASSETS, "js/savedcopy.js"), "utf8").replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*$/gm, "");
  assert.ok(!/^\s*(import|export)\s/m.test(code)); assert.ok(!/\b(document|ksu)\b|innerHTML|onclick/.test(code)); assert.ok(!/rm -rf/.test(code), "never rm -rf");
  assert.ok(!/<script[^>]+type="module"/.test(fs.readFileSync(path.join(ASSETS, "home.html"), "utf8")));
  var en = JSON.parse(fs.readFileSync(path.join(ASSETS, "i18n/en.json"), "utf8")), fil = JSON.parse(fs.readFileSync(path.join(ASSETS, "i18n/fil.json"), "utf8"));
  assert.deepStrictEqual(Object.keys(en).sort(), Object.keys(fil).sort());
});

(async function () {
  for (var i = 0; i < tests.length; i++) {
    try { await tests[i][1](); console.log("ok   - " + tests[i][0]); }
    catch (e) { failed++; failCp = false; truncCp = false; console.log("FAIL - " + tests[i][0] + "\n       " + (e && e.stack || e).toString().split("\n").slice(0, 5).join("\n       ")); }
  }
  fs.rmSync(TMP, { recursive: true, force: true });
  console.log("\n" + (tests.length - failed) + " passed, " + failed + " failed");
  process.exit(failed ? 1 : 0);
})();
