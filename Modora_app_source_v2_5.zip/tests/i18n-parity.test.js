/* i18n parity: en/fil JSON key sets match, each JSON matches its generated js copy, {placeholders} match across languages,
 * and every data-i18n / data-i18n-attr key used in home.html (plus T('key', ...) calls) exists in both languages. Run: node tests/i18n-parity.test.js */
"use strict";
var fs = require("fs"), path = require("path"), vm = require("vm"), assert = require("assert");
var A = path.resolve(__dirname, "../app/src/main/assets");
function json(l) { return JSON.parse(fs.readFileSync(A + "/i18n/" + l + ".json", "utf8")); }
function js(l) { var w = {}; vm.runInNewContext(fs.readFileSync(A + "/js/i18n." + l + ".js", "utf8"), { window: w }); return w.MD_STRINGS[l]; }
var D = { en: json("en"), fil: json("fil") }, J = { en: js("en"), fil: js("fil") }, fails = 0;
function t(n, f) { try { f(); console.log("ok   - " + n); } catch (e) { fails++; console.log("FAIL - " + n + "\n       " + e.message.split("\n")[0]); } }
function diff(a, b) { return Object.keys(a).filter(function (k) { return !(k in b); }); }
t("en.json and fil.json have identical key sets", function () { assert.deepStrictEqual([diff(D.en, D.fil), diff(D.fil, D.en)], [[], []]); });
["en", "fil"].forEach(function (l) { t("i18n." + l + ".js equals " + l + ".json (keys and values)", function () { assert.deepStrictEqual(JSON.parse(JSON.stringify(J[l])), D[l]); }); });
t("{placeholders} match between en and fil", function () {
  var bad = Object.keys(D.en).filter(function (k) { var f = function (s) { return (String(s).match(/\{\w+\}/g) || []).sort().join(); }; return f(D.en[k]) !== f(D.fil[k]); });
  assert.deepStrictEqual(bad, []);
});
t("no removed install.s1/s2/s3 keys remain; new install keys exist in both", function () {
  ["install.s1", "install.s2", "install.s3"].forEach(function (k) { assert.ok(!(k in D.en) && !(k in D.fil)); });
  ["install.paste", "install.selected", "install.remove_aria", "install.found", "install.why_none", "install.run", "install.another"].forEach(function (k) { assert.ok(D.en[k] && D.fil[k], k); });
});
t("every key used in home.html exists in both languages", function () {
  var h = fs.readFileSync(A + "/home.html", "utf8"), keys = {};
  (h.match(/data-i18n="([^"]+)"/g) || []).forEach(function (m) { keys[m.slice(11, -1)] = 1; });
  (h.match(/data-i18n-attr="([^"]+)"/g) || []).forEach(function (m) { m.slice(16, -1).split(";").forEach(function (p) { keys[p.split(":")[1]] = 1; }); });
  (h.match(/\bT\('([a-z0-9_.]+)'/g) || []).forEach(function (m) { keys[m.slice(3, -1)] = 1; });
  var miss = Object.keys(keys).filter(function (k) { return !/_$/.test(k) && (!(k in D.en) || !(k in D.fil)); });  // keys ending in _ are dynamic prefixes (e.g. T('detail.cat_' + x))
  assert.deepStrictEqual(miss, []);
});
t("MINI 1C: keys used by js/zipscan-view.js, the scanner's noteKey and the new install sheet strings exist in both languages", function () {
  var v = fs.readFileSync(A + "/js/zipscan-view.js", "utf8"), keys = {};
  (v.match(/\bT\("([a-z0-9_.]+)"/g) || []).forEach(function (m) { keys[m.slice(3, -1)] = 1; });
  keys[require(A + "/js/zipscan.js").NOTE_KEY] = 1;
  ["install.other", "install.showall", "install.hideother", "install.nomodules", "install.zipscan_noinspect", "install.zipscan_err_timeout", "install.zipscan_err_bad", "install.zipscan_err_bridge",
    "install.zipscan_trunc", "install.zipscan_large", "install.zipscan_unread", "install.mod_title", "install.mod_title_nover", "install.mod_noname", "install.chip_problem",
    "install.chip_notmodule", "install.chip_unchecked", "install.notmodule_hint", "install.unchecked_hint"].forEach(function (k) { keys[k] = 1; });
  var miss = Object.keys(keys).filter(function (k) { return !D.en[k] || !D.fil[k] || !J.en[k] || !J.fil[k]; });
  assert.deepStrictEqual(miss, []);
  assert.strictEqual(D.en["install.zipscan_noinspect"], require(A + "/js/zipscan.js").NOTE_NOINSPECT);
});
console.log(fails ? fails + " failed" : "all passed"); process.exit(fails ? 1 : 0);
