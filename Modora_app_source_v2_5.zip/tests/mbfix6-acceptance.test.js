/* MINI 1D final acceptance for MBFIX.6 (scanner core + redesigned Install sheet together). Run: node tests/mbfix6-acceptance.test.js
 * Needs Playwright + Chromium (PLAYWRIGHT_MODULE / CHROMIUM) and the `zip` CLI. Fake native bridge + real /bin/sh on a temp fake root; no real device
 * filesystem is read or written. Screenshots go to $SHOTS (default: a temp dir) when the harness can take them. */
"use strict";
var fs = require("fs"), os = require("os"), path = require("path"), cp = require("child_process"), assert = require("assert");
var pw = require(process.env.PLAYWRIGHT_MODULE || "/opt/npm-tools/node_modules/playwright");
var CHROMIUM = process.env.CHROMIUM || "/opt/pw-browsers/chromium";
var ASSETS = path.resolve(__dirname, "../app/src/main/assets");
var TMP = fs.mkdtempSync(path.join(os.tmpdir(), "mbfix6-"));
var SHOTS = process.env.SHOTS || path.join(TMP, "shots"); fs.mkdirSync(SHOTS, { recursive: true });
var ROOT = path.join(TMP, "root"), BIN = path.join(TMP, "bin"), BIN_NOUNZIP = path.join(TMP, "bin-nounzip"), DL = path.join(ROOT, "sdcard/Download");
fs.mkdirSync(DL, { recursive: true }); fs.mkdirSync(BIN); fs.mkdirSync(BIN_NOUNZIP);
var KSUD = "#!/bin/sh\necho \"ARG3=[$3]\"\ncase \"$3\" in *slow*) sleep 30;; esac\nexit 0\n";
fs.writeFileSync(path.join(BIN, "ksud"), KSUD, { mode: 493 }); fs.writeFileSync(path.join(BIN_NOUNZIP, "ksud"), KSUD, { mode: 493 });
["find", "grep", "cut", "tr", "head", "wc", "cat", "rm", "sleep"].forEach(function (t) { var p = cp.spawnSync("sh", ["-c", "command -v " + t]).stdout.toString().trim(); if (p) fs.symlinkSync(p, path.join(BIN_NOUNZIP, t)); });
function mkzip(dir, name, files) {
  fs.mkdirSync(dir, { recursive: true });
  var src = fs.mkdtempSync(path.join(TMP, "src-"));
  Object.keys(files).forEach(function (e) { var p = path.join(src, e); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, files[e]); });
  cp.execFileSync("zip", ["-q", "-r", path.join(dir, name), "."], { cwd: src });
}
var QNAME = "My \"q\" it's $HOME `x` mod.zip";
mkzip(DL, "real_module.zip", { "module.prop": "id=real\nname=Real Module\nversion=v1.5\nversionCode=15\n", "service.sh": "#\n" });            // (a)
mkzip(DL, "source_nested.zip", { "repo/module.prop": "id=n\nname=Nested\nversion=1\nversionCode=1\n", "repo/a.c": "int a;\n" });                    // (b)
mkzip(DL, "plain_other.zip", { "readme.txt": "not a module\n" });                                                                               // (c)
mkzip(DL, QNAME, { "module.prop": "id=q\nname=Quoted Module\nversion=2\nversionCode=2\n" });                                                    // (d)
mkzip(DL, "slow.zip", { "module.prop": "id=s\nname=Slow\nversion=1\nversionCode=1\n" });

var cmdLog = [], mode = "normal";
function remap(c) { return c.replace(/\/storage\/emulated\/0/g, ROOT + "/sdcard").replace(/(^|[^A-Za-z0-9_.\/-])\/sdcard/g, "$1" + ROOT + "/sdcard").replace(/(^|[^A-Za-z0-9_.\/-])\/data\/adb/g, "$1" + ROOT + "/adb"); }
function hostExec(cmd, timeout) {
  cmdLog.push(cmd);
  var pathEnv = mode === "nounzip" ? BIN_NOUNZIP : BIN + ":" + process.env.PATH;
  return new Promise(function (resolve) {
    var ch = cp.spawn("/bin/sh", ["-c", remap(cmd)], { env: { PATH: pathEnv }, detached: true, stdio: ["ignore", "pipe", "pipe"] }), out = "", done = false;
    ch.stdout.on("data", function (d) { out += d; }); ch.stderr.on("data", function (d) { out += d; });
    var t = timeout > 0 ? setTimeout(function () { try { process.kill(-ch.pid, "SIGKILL"); } catch (e) {} fin(-2); }, timeout) : null;
    function fin(c) { if (done) return; done = true; if (t) clearTimeout(t); resolve({ code: c, out: out.split(ROOT + "/sdcard").join("/sdcard"), err: "" }); }
    ch.on("close", function (c) { fin(c == null ? -1 : c); }); ch.on("error", function () { fin(-1); });
  });
}
var INIT = function () {
  window.__picks = [];
  window.ksu = {
    exec: function (cmd, opts, cb) { var o = {}; try { o = JSON.parse(opts || "{}"); } catch (e) {} window.__hostExec(cmd, o.timeout || 0).then(function (r) { setTimeout(function () { if (window[cb]) window[cb](r.code, r.out, r.err); }, 0); }); },
    pickZip: function (cb) { window.__picks.push(cb); }, toast: function () {}, appInfo: function () { return "{}"; }
  };
  try { localStorage.setItem("md.onboarded", "1"); } catch (e) {}
};
var queue = [], passed = 0, failed = 0;
function test(n, f) { queue.push([n, f]); }
async function openPage(b, opts, file) {
  var ctx = await b.newContext(Object.assign({ viewport: { width: 360, height: 640 } }, opts || {})), page = await ctx.newPage(), errors = [];
  page.on("pageerror", function (e) { errors.push("pageerror: " + e); });
  page.on("console", function (m) { if (m.type() === "error") errors.push("console: " + m.text()); });
  await page.exposeFunction("__hostExec", hostExec); await page.addInitScript(INIT);
  await page.goto("file://" + ASSETS + "/" + (file || "home.html"));
  if (!file || file === "home.html") await page.waitForFunction("window.MDRouter && window.MDI18n && window.MD && MD.sh && window.MDZipScan && window.MDZipView", null, { timeout: 8000 });
  await page.waitForTimeout(300); page.__errors = errors; return page;
}
async function openInstall(page) {
  await page.evaluate(function () { document.querySelector("#more").click(); document.querySelector('[data-qa="install"]').click(); });
  await page.waitForSelector("#install.on"); await page.waitForFunction("!document.getElementById('inst-scan').disabled", null, { timeout: 15000 });
}
function txt(p, s) { return p.evaluate(function (x) { return document.querySelector(x).textContent.trim(); }, s); }
function vis(p, s) { return p.locator(s).isVisible(); }
function fixedByName(p) { return p.evaluate(function () { return [].slice.call(document.querySelectorAll("#inst-list .row")).map(function (r) { return r.dataset.zip.split("/").pop(); }).sort(); }); }

test("(a)(b)(c)(d) real scan: module / nested / non-module / quoted name classified from actual output", async function (b) {
  mode = "normal"; var page = await openPage(b); await openInstall(page);
  assert.deepStrictEqual(await fixedByName(page), [QNAME, "real_module.zip", "slow.zip"].sort());
  await page.click("#inst-showall");
  var other = await page.evaluate(function () { return [].slice.call(document.querySelectorAll("#inst-other-list .row")).map(function (r) { return r.dataset.zip.split("/").pop(); }).sort(); });
  assert.deepStrictEqual(other, ["plain_other.zip", "source_nested.zip"]);
  var t = await page.evaluate(function () { return [].slice.call(document.querySelectorAll("#inst-list .row b")).map(function (x) { return x.textContent; }).sort(); });
  assert.deepStrictEqual(t, ["Quoted Module v2", "Real Module v1.5", "Slow v1"]);
  assert.deepStrictEqual(page.__errors, []);
});
test("(d) quoted/spaced file name: selected, installed, and the installer receives the EXACT path (no shell expansion)", async function (b) {
  mode = "normal"; var page = await openPage(b); await openInstall(page);
  await page.evaluate(function (n) { var r = [].slice.call(document.querySelectorAll("#inst-list .row")).filter(function (x) { return x.dataset.zip.split("/").pop() === n; })[0]; r.click(); }, QNAME);
  assert.strictEqual(await txt(page, "#inst-sel-n"), QNAME); assert.strictEqual(await txt(page, "#inst-sel-chip"), "OK");
  await page.click("#inst-run"); await page.waitForSelector("#inst-done:not([hidden])", { timeout: 15000 });
  var log = await txt(page, "#inst-log");
  assert.ok(log.indexOf("ARG3=[/sdcard/Download/" + QNAME + "]") >= 0, log);
  assert.ok(/Finished \(exit 0\)/.test(log));
});
test("(e) inspection tool missing: honest note, zero modules, everything under Other, not-a-module claim never made", async function (b) {
  mode = "nounzip"; var page = await openPage(b); await openInstall(page);
  assert.strictEqual(await txt(page, "#inst-scan-note"), "Could not look inside zips on this device, so they are not checked.");
  assert.strictEqual(await page.locator("#inst-list .row").count(), 0); assert.ok(!(await vis(page, "#inst-found")));
  assert.strictEqual(await txt(page, "#inst-other-l"), "Other zips (5)");
  await page.click("#inst-showall"); await page.click('#inst-other-list [data-zip$="real_module.zip"]');
  assert.strictEqual(await txt(page, "#inst-sel-chip"), "Not checked"); assert.ok(!/Real Module/.test(await txt(page, "#inst-sel")));
  mode = "normal";
});
test("interaction chain: main select -> Other select -> chip -> Remove -> select another immediately", async function (b) {
  mode = "normal"; var page = await openPage(b); await openInstall(page);
  await page.click('#inst-list [data-zip$="real_module.zip"]'); assert.strictEqual(await txt(page, "#inst-sel-chip"), "OK");
  await page.click("#inst-found-t"); await page.click("#inst-showall"); await page.click('#inst-other-list [data-zip$="plain_other.zip"]');
  assert.strictEqual(await txt(page, "#inst-sel-chip"), "Not a module"); assert.strictEqual(await txt(page, "#inst-sel-n"), "plain_other.zip");
  await page.click("#inst-remove"); assert.ok(!(await vis(page, "#inst-sel")));
  assert.strictEqual(await page.locator('#install [aria-current="true"]').count(), 0);
  await page.click('#inst-list [data-zip$="slow.zip"]'); assert.strictEqual(await txt(page, "#inst-sel-n"), "slow.zip");
});
test("keyboard: Enter/Space toggle both sections, aria-expanded tracks, Paste toggle", async function (b) {
  mode = "normal"; var page = await openPage(b); await openInstall(page);
  for (var id of ["inst-found-t", "inst-other-t", "inst-paste"]) {
    var before = await page.getAttribute("#" + id, "aria-expanded");
    await page.focus("#" + id); await page.keyboard.press("Enter");
    var mid = await page.getAttribute("#" + id, "aria-expanded"); assert.notStrictEqual(mid, before, id + " Enter");
    await page.focus("#" + id);   // Paste path moves focus into its input on open, so return to the toggle before Space
    await page.keyboard.press("Space"); assert.strictEqual(await page.getAttribute("#" + id, "aria-expanded"), before, id + " Space");
  }
});
test("Back closes the sheet via MDRouter.onBack; then nothing else", async function (b) {
  mode = "normal"; var page = await openPage(b); await openInstall(page);
  await page.click("#inst-other-t");
  var r = await page.evaluate(function () { var a = window.MD.onBack(), on = document.getElementById("install").classList.contains("on"); return [a, on, window.MD.onBack()]; });
  assert.strictEqual(r[1], false); assert.strictEqual(r[0], true); assert.strictEqual(r[2], false);
});
test("install log live, Cancel install, Done, Install another reset", async function (b) {
  mode = "normal"; var page = await openPage(b); await openInstall(page);
  await page.click('#inst-list [data-zip$="slow.zip"]'); await page.click("#inst-run");
  await page.waitForSelector("#inst-cancel:not([hidden])"); assert.ok(await vis(page, "#inst-log")); assert.ok(!(await vis(page, "#inst-src")));
  await page.waitForFunction("/ARG3=/.test(document.getElementById('inst-log').textContent)", null, { timeout: 10000 });
  await page.click("#inst-cancel"); await page.waitForSelector("#inst-done:not([hidden])", { timeout: 20000 });
  assert.ok(/cancelled/i.test(await txt(page, "#inst-log")));
  await page.click("#inst-another");
  assert.ok(!(await vis(page, "#inst-log")) && !(await vis(page, "#inst-sel")) && await vis(page, "#inst-src") && await page.isDisabled("#inst-run"));
  assert.ok(await page.locator("#inst-list .row").count() >= 3, "scan results kept after Install another");
  await page.click('#inst-list [data-zip$="real_module.zip"]'); await page.click("#inst-run"); await page.waitForSelector("#inst-done:not([hidden])", { timeout: 15000 });
  await page.click("#inst-done"); assert.ok(!(await page.evaluate("document.getElementById('install').classList.contains('on')")));
});
test("picker flow preserved: picked zip card, error mapping, cancel is silent, cleanup on Remove / install / close", async function (b) {
  mode = "normal"; var page = await openPage(b); await openInstall(page);
  var E = { notzip: "That file is not a zip archive.", toolarge: "That file is too large (limit 256 MB).", copy: "Could not copy the file. Check that root access is allowed.", open: "Could not open that file.", busy: "The file picker is already open.", nopicker: "The file picker is not available in this build. Scan zips or paste a path.", weird: "Could not pick that file." };
  for (var k of Object.keys(E)) {
    await page.click("#inst-browse"); assert.ok(await page.isDisabled("#inst-browse"), "Browse disabled while picking");
    await page.evaluate(function (e) { var cb = window.__picks.pop(); window[cb](false, "", "", 0, e); }, k);
    assert.strictEqual(await txt(page, "#inst-msg"), E[k], k); assert.ok(!(await page.isDisabled("#inst-browse")));
  }
  await page.click("#inst-browse"); await page.evaluate(function () { var cb = window.__picks.pop(); window[cb](false, "", "", 0, "cancelled"); });
  assert.strictEqual(await txt(page, "#inst-msg"), ""); assert.ok(!(await vis(page, "#inst-sel")));
  async function pick() { await page.click("#inst-browse"); await page.evaluate(function () { var cb = window.__picks.pop(); window[cb](true, "/data/local/tmp/modora_install/picked.zip", "picked.zip", 5242880, ""); }); }
  await pick(); assert.strictEqual(await txt(page, "#inst-sel-n"), "picked.zip"); assert.ok(/5\.0 MB/.test(await txt(page, "#inst-sel-d"))); assert.strictEqual(await txt(page, "#inst-sel-chip"), "OK");
  cmdLog.length = 0; await page.click("#inst-remove");
  assert.ok(cmdLog.indexOf("rm -rf /data/local/tmp/modora_install") >= 0, "Remove -> dropPicked()");
  await pick(); cmdLog.length = 0; await page.click("#inst-close");
  await page.waitForTimeout(300); assert.ok(cmdLog.indexOf("rm -rf /data/local/tmp/modora_install") >= 0, "closing -> dropPicked()");
  await page.evaluate(function () { document.querySelector("#more").click(); document.querySelector('[data-qa="install"]').click(); });
  await page.waitForFunction("!document.getElementById('inst-scan').disabled", null, { timeout: 15000 });
  await pick(); cmdLog.length = 0; await page.click("#inst-run"); await page.waitForSelector("#inst-done:not([hidden])", { timeout: 15000 });
  assert.ok((await txt(page, "#inst-log")).indexOf("ARG3=[/data/local/tmp/modora_install/picked.zip]") >= 0, "installer got the picked path");
  assert.ok(cmdLog.indexOf("rm -rf /data/local/tmp/modora_install") >= 0, "after install -> dropPicked()");
});
test("layout: Install visible in the sticky footer without scrolling the body; 360x640 and 412x915, dark and light; screenshots", async function (b) {
  mode = "normal"; var shots = 0;
  for (var vp of [[360, 640], [412, 915]]) for (var theme of ["dark", "light"]) {
    var page = await openPage(b, { viewport: { width: vp[0], height: vp[1] } });
    await page.evaluate(function (t) { document.documentElement.setAttribute("data-theme", t); }, theme);
    await openInstall(page);
    var states = ["empty", "module", "other"];
    for (var s of states) {
      if (s === "module") await page.click('#inst-list [data-zip$="real_module.zip"]');
      if (s === "other") { await page.click("#inst-remove"); await page.click("#inst-showall"); await page.click('#inst-other-list [data-zip$="plain_other.zip"]'); }
      var r = await page.evaluate(function () {
        var run = document.getElementById("inst-run"), q = run.getBoundingClientRect(), f = document.querySelector(".ins-f").getBoundingClientRect(), sh = document.getElementById("inst-sheet").getBoundingClientRect();
        var hit = document.elementFromPoint(q.left + q.width / 2, q.top + q.height / 2), css = getComputedStyle(document.querySelector(".ins-f"));
        return { vh: innerHeight, run: [q.top, q.bottom, q.height], fb: f.bottom, sh: sh.height, hit: !!hit && (hit === run || run.contains(hit)), pos: css.position, pb: css.paddingBottom, bg: css.backgroundColor, bodyY: window.scrollY };
      });
      var tag = vp.join("x") + "/" + theme + "/" + s;
      assert.ok(r.run[0] >= 0 && r.run[1] <= r.vh && r.fb <= r.vh + 1 && r.run[2] >= 44, tag + " " + JSON.stringify(r));
      assert.ok(r.hit, tag + ": Install must be hit-testable (not covered)"); assert.ok(r.sh <= r.vh * 0.9 + 1, tag + " sheet height");
      assert.ok(!/rgba\(0, 0, 0, 0\)|transparent/.test(r.bg), tag + " footer opaque");
      try { await page.screenshot({ path: path.join(SHOTS, "install_" + tag.replace(/\//g, "_") + ".png") }); shots++; } catch (e) {}
    }
    await page.context().close();
  }
  assert.strictEqual(shots, 12, "screenshots captured: " + shots);
  var css = fs.readFileSync(ASSETS + "/css/install.css", "utf8");
  assert.ok(/--md-safe-b/.test(css), "footer keeps the safe-area inset (system navigation)");
});
test("reduced motion honoured; Install visible with the live log shown too", async function (b) {
  mode = "normal"; var page = await openPage(b, { reducedMotion: "reduce" }); await openInstall(page);
  await page.click('#inst-list [data-zip$="real_module.zip"]'); await page.click("#inst-run"); await page.waitForSelector("#inst-done:not([hidden])", { timeout: 15000 });
  var r = await page.evaluate(function () { var d = document.getElementById("inst-done").getBoundingClientRect(); return [d.top >= 0 && d.bottom <= innerHeight, getComputedStyle(document.querySelector("#inst-found-t .md-icon")).transitionDuration]; });
  assert.ok(r[0]); assert.ok(r[1].split(",").every(function (x) { return parseFloat(x) < 0.001; }), r[1]);
});
test("page-load matrix: home, action, rme50, anr load with no console/page errors", async function (b) {
  for (var f of ["home.html", "action.html", "rme50.html", "anr.html"]) {
    var page = await openPage(b, null, f);
    assert.deepStrictEqual(page.__errors, [], f + ": " + JSON.stringify(page.__errors));
    assert.ok((await page.evaluate("document.body.innerText.length")) > 0, f + " rendered");
    await page.context().close();
  }
});

(async function () {
  var browser = await pw.chromium.launch({ executablePath: CHROMIUM, args: ["--no-sandbox"] });
  for (var i = 0; i < queue.length; i++) {
    try { await queue[i][1](browser); passed++; console.log("ok   - " + queue[i][0]); }
    catch (e) { failed++; console.log("FAIL - " + queue[i][0] + "\n       " + String(e && e.stack || e).split("\n").slice(0, 6).join("\n       ")); }
  }
  await browser.close();
  if (process.env.SHOTS) console.log("screenshots in " + SHOTS); else try { fs.rmSync(TMP, { recursive: true, force: true }); } catch (e) {}
  console.log("\n" + passed + " passed, " + failed + " failed"); process.exit(failed ? 1 : 0);
})();
