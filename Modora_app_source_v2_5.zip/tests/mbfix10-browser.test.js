const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/opt/npm-tools/node_modules/playwright'); const path=require('path'); const cp=require('child_process'), fs=require('fs'), os=require('os');
const A=path.resolve(__dirname,'../app/src/main/assets'); const out=fs.mkdtempSync(path.join(os.tmpdir(),'mbfix10-shots-')); fs.mkdirSync(out,{recursive:true});
const T=fs.mkdtempSync(path.join(os.tmpdir(),'sh-')); const DL=T+'/sdcard/Download'; fs.mkdirSync(DL,{recursive:true});
for (const n of ['alpha','beta']) { const d=fs.mkdtempSync(T+'/m'); fs.writeFileSync(d+'/module.prop',`id=${n}\nname=${n[0].toUpperCase()+n.slice(1)} Tweaks\nversion=v1.${n.length}\nversionCode=1\n`); cp.execFileSync('zip',['-q','-r',DL+'/'+n+'.zip','.'],{cwd:d}); }
fs.mkdirSync(T+'/bin'); fs.writeFileSync(T+'/bin/ksud','#!/bin/sh\necho ksud-fake "$@"\nexit 0\n',{mode:493});
const log=[];
(async()=>{ const b=await chromium.launch({ executablePath: process.env.CHROMIUM || '/opt/pw-browsers/chromium', args: ['--no-sandbox'] }); let fails=0; const ck=(n,c,x)=>{console.log((c?'PASS ':'FAIL ')+n+(x?' :: '+x:'')); if(!c)fails++;};
 for (const [vp,sc,tag] of [[{width:360,height:740},'dark','360d'],[{width:412,height:915},'light','412l']]) {
  const ctx=await b.newContext({viewport:vp,colorScheme:sc}); const p=await ctx.newPage(); const errs=[]; p.on('pageerror',e=>errs.push(String(e)));
  await p.exposeFunction('__ex',(cmd)=>{ log.push(cmd); return new Promise(r=>{ const c=cp.spawn('/bin/sh',['-c',cmd.replace(/(^|[^A-Za-z0-9_.\/-])\/sdcard/g,'$1'+T+'/sdcard')],{env:{PATH:T+'/bin:'+process.env.PATH},stdio:['ignore','pipe','pipe']}); let o=''; c.stdout.on('data',d=>o+=d); c.stderr.on('data',d=>o+=d); c.on('close',x=>r({code:x,out:o.split(T+'/sdcard').join('/sdcard')})); c.on('error',()=>r({code:-1,out:''})); }); });
  await p.addInitScript(()=>{ try{localStorage.setItem('md.onboarded','1');localStorage.setItem('md.theme',window.matchMedia('(prefers-color-scheme: light)').matches?'light':'dark')}catch(e){} window.ksu={exec(c,o,cb){window.__ex(c).then(r=>setTimeout(()=>window[cb](r.code,r.out,''),0))},pickZip(){},toast(){},appInfo(){return '{}'},rootShellInfo(){return '{}'},webrootCacheInfo(){return '{}'},setBars(){return true}}; });
  await p.goto('file://'+A+'/home.html'); await p.waitForTimeout(900);
  await p.screenshot({path:`${out}/deck-${tag}.png`});
  await p.click('.md-stats-toggle'); await p.waitForTimeout(500); await p.screenshot({path:`${out}/deck-expanded-${tag}.png`}); await p.click('.md-stats-toggle');
  await p.evaluate(()=>{document.querySelector('#more').click();document.querySelector('[data-qa="install"]').click()});
  await p.waitForSelector('#install.on'); await p.waitForFunction("!document.getElementById('inst-scan').disabled",null,{timeout:15000}); await p.waitForTimeout(400);
  ck('reboot hidden before install', !(await p.locator('#inst-reboot').isVisible()));
  await p.screenshot({path:`${out}/install-empty-${tag}.png`});
  await p.click('#inst-list [data-zip$="alpha.zip"]'); await p.click('#inst-list [data-zip$="beta.zip"]'); await p.waitForTimeout(300);
  await p.screenshot({path:`${out}/install-queued-${tag}.png`});
  ck('reboot hidden while queued', !(await p.locator('#inst-reboot').isVisible()));
  await p.click('#inst-run'); await p.waitForSelector('#inst-done:not([hidden])',{timeout:15000}); await p.waitForTimeout(300);
  ck('reboot visible after successful install', await p.locator('#inst-reboot').isVisible());
  const bb=await p.locator('#inst-reboot').boundingBox(); ck('reboot >=44px', bb.height>=44, JSON.stringify(bb));
  await p.screenshot({path:`${out}/install-done-${tag}.png`});
  log.length=0; await p.click('#inst-reboot'); await p.waitForTimeout(500);
  ck('confirm dialog opened, no reboot cmd yet', (await p.locator('.md-pw').count())>0 && !log.some(c=>/reboot/.test(c)));
  await p.screenshot({path:`${out}/install-reboot-confirm-${tag}.png`});
  await p.keyboard.press('Escape'); await p.waitForTimeout(300);
  ck('cancel: still no reboot cmd', !log.some(c=>/reboot/.test(c)));
  await p.click('#inst-done'); await p.waitForTimeout(300);
  ck('no console errors '+tag, errs.length===0, errs.join('|'));
  await ctx.close(); }
 await b.close(); process.exit(fails?1:0); })();
