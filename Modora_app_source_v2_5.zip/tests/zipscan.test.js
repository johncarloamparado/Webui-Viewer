/* MINI 1A tests for app/src/main/assets/js/zipscan.js. Run: node tests/zipscan.test.js
 * Uses only Node built-ins plus the `zip` CLI (to generate fixture archives in a temp dir) and the system `sh`.
 * Shell tests run the REAL generated script with /bin/sh against a fake root in a temp dir (dirs injected via options.dirs). */
"use strict";
var fs = require("fs"), os = require("os"), path = require("path"), cp = require("child_process"), assert = require("assert");
var Z = require("../app/src/main/assets/js/zipscan.js");

var passed = 0, failed = 0, queue = [];
function test(name, fn) { queue.push([name, fn]); }

var TMP = fs.mkdtempSync(path.join(os.tmpdir(), "zipscan-"));
var T = "\t";
function row() { return ["MDZS1"].concat([].slice.call(arguments)).join(T); }
function frame(rows, o) {
  o = o || {};
  var n = rows.filter(function (r) { return /^MDZS1\t[MO]\t/.test(r); }).length;
  return ["MDZS1\tBEGIN", "MDZS1\tMETHOD\t" + (o.method || "unzip")].concat(rows, ["MDZS1\tSKIP\t" + (o.big || 0) + "\t" + (o.bad || 0) + "\t" + (o.trunc ? 1 : 0), "MDZS1\tEND\t" + (o.n == null ? n : o.n)]).join("\n") + "\n";
}

/* ---------- fixtures ---------- */
function mkzip(dir, name, files) {          // files: {entryName: content}
  fs.mkdirSync(dir, { recursive: true });
  var src = fs.mkdtempSync(path.join(TMP, "src-"));
  Object.keys(files).forEach(function (e) { var p = path.join(src, e); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, files[e]); });
  var out = path.join(dir, name);
  cp.execFileSync("zip", ["-q", "-r", out, "."], { cwd: src });
  return out;
}
var PROP = "id=demo\nname=Demo Module\nversion=v1.2=beta\nversionCode=12\nname=SECOND\nversion=9\n";

/* sh-backed executor: runs the script with a restricted PATH so tools can be hidden */
function binDir(tools, extra) {
  var d = fs.mkdtempSync(path.join(TMP, "bin-"));
  tools.forEach(function (t) {
    var p = cp.spawnSync("sh", ["-c", "command -v " + t]).stdout.toString().trim();
    if (!p) throw new Error("test host lacks " + t);
    fs.symlinkSync(p, path.join(d, t));
  });
  Object.keys(extra || {}).forEach(function (n) { fs.writeFileSync(path.join(d, n), extra[n], { mode: 493 }); });
  return d;
}
var BASE_TOOLS = ["find", "grep", "cut", "tr", "head", "wc", "cat", "printf"];
function shExec(bin) {
  return function (cmd, opts) {
    return new Promise(function (resolve) {
      var r = cp.spawnSync("/bin/sh", ["-c", cmd], { env: { PATH: bin }, encoding: "utf8", timeout: opts.timeout, maxBuffer: 1 << 24 });
      resolve({ code: r.status == null ? -2 : r.status, out: r.stdout });
    });
  };
}

/* ---------- pure parse() ---------- */
test("parse: valid module + other with metadata", function () {
  var r = Z.parse(frame([row("M", 100, "/sdcard/Download/a.zip", "Demo", "v1.2=beta", "12"), row("O", 50, "/sdcard/Download/b.zip")]));
  assert.ok(r.ok); assert.strictEqual(r.method, "unzip");
  assert.deepStrictEqual(r.modules, [{ path: "/sdcard/Download/a.zip", name: "Demo", nameKnown: true, ver: "v1.2=beta", code: "12", size: 100 }]);
  assert.deepStrictEqual(r.others, [{ path: "/sdcard/Download/b.zip", size: 50 }]);
});
test("parse: missing name falls back to file name", function () {
  var r = Z.parse(frame([row("M", 1, "/sdcard/x/Cool.zip", "", "", "")]));
  assert.strictEqual(r.modules[0].name, "Cool"); assert.strictEqual(r.modules[0].nameKnown, false);
});
test("parse: spaces and quotes in file names are kept intact", function () {
  var p = "/sdcard/Download/My \"best\" it's module (1).zip";
  var r = Z.parse(frame([row("O", 7, p)]));
  assert.ok(r.ok); assert.strictEqual(r.others[0].path, p);
});
test("parse: banner lines outside the frame are ignored", function () {
  var r = Z.parse("welcome to su\n" + frame([row("O", 1, "/sdcard/a.zip")]) + "\nbye\n");
  assert.ok(r.ok);
});
test("parse: alias dedupe by basename + size keeps one (first)", function () {
  var r = Z.parse(frame([row("O", 5, "/sdcard/Download/a.zip"), row("O", 5, "/storage/emulated/0/Download/a.zip"), row("O", 6, "/sdcard/Download/a.zip")], { n: 3 }));
  assert.ok(r.ok); assert.strictEqual(r.others.length, 2); assert.strictEqual(r.others[0].path, "/sdcard/Download/a.zip");
});
test("parse: rejects empty / whitespace output", function () {
  assert.strictEqual(Z.parse("").reason, "empty"); assert.strictEqual(Z.parse("  \n").reason, "empty"); assert.strictEqual(Z.parse(null).reason, "empty");
});
test("parse: rejects output with no markers", function () { assert.strictEqual(Z.parse("hello\nworld\n").reason, "nomarker"); });
test("parse: rejects truncated output (no END)", function () {
  var full = frame([row("O", 1, "/sdcard/a.zip")]);
  assert.strictEqual(Z.parse(full.slice(0, full.indexOf("MDZS1\tEND"))).reason, "noend");
  assert.strictEqual(Z.parse("MDZS1\tBEGIN\n").reason, "noend");
});
test("parse: rejects row-count mismatch", function () {
  assert.strictEqual(Z.parse(frame([row("O", 1, "/sdcard/a.zip")], { n: 2 })).reason, "badcount");
});
test("parse: rejects malformed rows", function () {
  var cases = [
    row("O", "abc", "/sdcard/a.zip"), row("O", 1, "relative.zip"), row("O", 1, "/sdcard/../a.zip"), row("O", 1), row("O", 1, "/sdcard/a.zip", "extra"),
    row("M", 1, "/sdcard/a.zip", "n", "v"), row("X", 1, "/sdcard/a.zip"), "garbage inside frame", row("O", -1, "/sdcard/a.zip"), row("O", 1, "/sdcard/a\u0001.zip")
  ];
  cases.forEach(function (c) { var r = Z.parse(frame([c], { n: 1 })); assert.ok(!r.ok && r.reason === "malformed", JSON.stringify(c) + " -> " + JSON.stringify(r)); });
});
test("parse: rejects duplicate BEGIN / METHOD / END mid-frame and blank line inside frame", function () {
  assert.ok(!Z.parse("MDZS1\tBEGIN\nMDZS1\tBEGIN\n").ok);
  assert.ok(!Z.parse("MDZS1\tBEGIN\nMDZS1\tMETHOD\tunzip\nMDZS1\tMETHOD\tunzip\n").ok);
  assert.ok(!Z.parse("MDZS1\tBEGIN\nMDZS1\tMETHOD\tunzip\n\nMDZS1\tSKIP\t0\t0\t0\nMDZS1\tEND\t0\n").ok);
  assert.ok(!Z.parse(frame([]) + "MDZS1\tO\t1\t/sdcard/late.zip\n").ok);
});
test("parse: rejects a module row when no inspection method exists", function () {
  assert.strictEqual(Z.parse(frame([row("M", 1, "/sdcard/a.zip", "n", "v", "1")], { method: "none" })).reason, "malformed");
});
test("parse: rejects unknown method id and missing METHOD line", function () {
  assert.ok(!Z.parse(frame([], { method: "evil" })).ok);
  assert.ok(!Z.parse("MDZS1\tBEGIN\nMDZS1\tO\t1\t/sdcard/a.zip\nMDZS1\tSKIP\t0\t0\t0\nMDZS1\tEND\t1\n").ok);
});
test("parse: valid empty scan (zero zips) is ok but only with full framing", function () {
  var r = Z.parse(frame([])); assert.ok(r.ok); assert.strictEqual(r.modules.length + r.others.length, 0);
});

/* ---------- scan() with a fake executor ---------- */
test("scan: no executor and no MD.sh -> nobridge", async function () {
  var r = await Z.scan(null, {}); assert.strictEqual(r.status, "nobridge"); assert.deepStrictEqual(r.modules, []);
});
test("scan: passes timeout option and a script to the executor", async function () {
  var seen; var r = await Z.scan(function (cmd, o) { seen = [cmd, o]; return Promise.resolve({ code: 0, out: frame([]) }); }, { timeout: 12345 });
  assert.strictEqual(r.status, "ok"); assert.strictEqual(seen[1].timeout, 12345); assert.ok(/find /.test(seen[0]));
});
test("scan: timeout / bridge codes -> error with reason", async function () {
  var r = await Z.scan(function () { return Promise.resolve({ code: -2, out: "" }); }); assert.deepStrictEqual([r.status, r.reason], ["error", "timeout"]);
  r = await Z.scan(function () { return Promise.resolve({ code: -3, out: frame([]) }); }); assert.strictEqual(r.reason, "timeout");
  r = await Z.scan(function () { return Promise.resolve({ code: -5, out: "" }); }); assert.deepStrictEqual([r.status, r.reason], ["error", "bridge"]);
  r = await Z.scan(function () { return Promise.reject(new Error("x")); }); assert.strictEqual(r.reason, "bridge");
  r = await Z.scan(function () { throw new Error("x"); }); assert.strictEqual(r.reason, "bridge");
});
test("scan: truncated / empty output never looks like success", async function () {
  var r = await Z.scan(function () { return Promise.resolve({ code: 0, out: "MDZS1\tBEGIN\nMDZS1\tMETHOD\tunzip\n" }); });
  assert.deepStrictEqual([r.status, r.reason, r.modules.length], ["error", "noend", 0]);
  r = await Z.scan(function () { return Promise.resolve({ code: 0, out: "" }); }); assert.deepStrictEqual([r.status, r.reason], ["error", "empty"]);
});
test("scan: method none -> noinspector, note text, no modules", async function () {
  var r = await Z.scan(function () { return Promise.resolve({ code: 0, out: frame([row("O", 9, "/sdcard/a.zip")], { method: "none" }) }); });
  assert.strictEqual(r.status, "noinspector"); assert.strictEqual(r.note, "Could not look inside zips on this device, so they are not checked.");
  assert.deepStrictEqual(r.modules, []); assert.strictEqual(r.others.length, 1); assert.strictEqual(r.method, "none");
});
test("scan: rejects bad injected directories", async function () {
  var r = await Z.scan(function () { return Promise.resolve({ code: 0, out: frame([]) }); }, { dirs: ["/sdcard/$(rm -rf x)"] });
  assert.strictEqual(r.status, "error");
});

/* ---------- real sh on a fake root ---------- */
function fakeRoot() {
  var r = fs.mkdtempSync(path.join(TMP, "root-")), dl = path.join(r, "sdcard", "Download");
  mkzip(dl, "mod.zip", { "module.prop": PROP, "system/bin/x": "x" });
  mkzip(dl, "nested.zip", { "folder/module.prop": PROP });
  mkzip(dl, "source.zip", { "README.md": "hi", "src/a.c": "int a;" });
  mkzip(dl, "My \"q\" it's mod (2).zip", { "module.prop": "name=Quoted One\nversion=2.0\nversionCode=20\n" });
  fs.writeFileSync(path.join(dl, "broken.zip"), "this is not a zip");
  mkzip(path.join(dl, "sub"), "deep.zip", { "module.prop": "name=Deep\nversion=1\nversionCode=1\n" });
  mkzip(path.join(dl, "sub", "sub2"), "toodeep.zip", { "module.prop": "name=TooDeep\n" });   // depth 3 under dl, beyond maxdepth
  return { root: r, dl: dl };
}
var TOOLS = BASE_TOOLS.concat(["unzip"]);
function byName(list) { var o = {}; list.forEach(function (x) { o[path.basename(x.path)] = x; }); return o; }

test("shell: real unzip classifies modules, nested module.prop, non-modules, broken zip, spaces/quotes", async function () {
  var fr = fakeRoot();
  var r = await Z.scan(shExec(binDir(TOOLS)), { dirs: [fr.dl] });
  assert.strictEqual(r.status, "ok", JSON.stringify(r)); assert.strictEqual(r.method, "unzip");
  var m = byName(r.modules), o = byName(r.others);
  assert.deepStrictEqual(Object.keys(m).sort(), ["My \"q\" it's mod (2).zip", "deep.zip", "mod.zip"]);
  assert.deepStrictEqual(Object.keys(o).sort(), ["broken.zip", "nested.zip", "source.zip"]);
  assert.strictEqual(m["mod.zip"].name, "Demo Module");            // FIRST name= wins
  assert.strictEqual(m["mod.zip"].ver, "v1.2=beta");               // value after the FIRST "="
  assert.strictEqual(m["mod.zip"].code, "12");
  assert.strictEqual(m["mod.zip"].size, fs.statSync(path.join(fr.dl, "mod.zip")).size);
  assert.strictEqual(m["My \"q\" it's mod (2).zip"].name, "Quoted One");
  assert.ok(!("toodeep.zip" in m) && !("toodeep.zip" in o));
});
test("shell: nested folder/module.prop is NOT a module (isolated)", async function () {
  var r0 = fs.mkdtempSync(path.join(TMP, "n-")); mkzip(r0, "n.zip", { "folder/module.prop": PROP });
  var r = await Z.scan(shExec(binDir(TOOLS)), { dirs: [r0] });
  assert.strictEqual(r.status, "ok"); assert.strictEqual(r.modules.length, 0); assert.strictEqual(r.others.length, 1);
});
test("shell: script is read-only (fixture tree unchanged, nothing extracted)", async function () {
  var fr = fakeRoot(), before = cp.execSync("find " + JSON.stringify(fr.root) + " -printf '%p %s %T@\\n' | sort").toString();
  await Z.scan(shExec(binDir(TOOLS)), { dirs: [fr.dl] });
  assert.strictEqual(cp.execSync("find " + JSON.stringify(fr.root) + " -printf '%p %s %T@\\n' | sort").toString(), before);
  assert.ok(!/\b(rm|mv|cp|mkdir|unzip -o|>\s*\/)\b/.test(Z.buildScript().replace(/2>\/dev\/null|>\/dev\/null|<\/dev\/null/g, "")), "script contains a write-like command");
});
test("shell: alias dirs (same basename + size) are deduped to one result", async function () {
  var fr = fakeRoot(), alias = path.join(fr.root, "alias"); fs.symlinkSync(fr.dl, alias);
  // symlinked dir is walked by find only when given explicitly; give both spellings
  var r = await Z.scan(shExec(binDir(TOOLS)), { dirs: [fr.dl, alias] });
  assert.strictEqual(r.status, "ok");
  assert.strictEqual(r.modules.length + r.others.length, 6);
  assert.strictEqual(r.modules.filter(function (x) { return /mod\.zip$/.test(x.path); }).length, 1);
});
test("shell: copy under a second dir with same name+size is deduped (default dir pair /sdcard + /sdcard/Download shape)", async function () {
  var r0 = fs.mkdtempSync(path.join(TMP, "d-")), a = path.join(r0, "Download"); mkzip(a, "one.zip", { "module.prop": "name=One\n" });
  var top = r0;                                   // r0 contains Download/one.zip at depth 2 -> scanned twice
  var r = await Z.scan(shExec(binDir(TOOLS)), { dirs: [a, top] });
  assert.strictEqual(r.modules.length, 1); assert.strictEqual(r.others.length, 0);
});
test("shell: files over 256 MB are skipped (sparse file)", async function () {
  var r0 = fs.mkdtempSync(path.join(TMP, "big-")); mkzip(r0, "ok.zip", { "module.prop": "name=Ok\n" });
  var fd = fs.openSync(path.join(r0, "huge.zip"), "w"); fs.ftruncateSync(fd, Z.MAX_BYTES + 1); fs.closeSync(fd);
  var fd2 = fs.openSync(path.join(r0, "edge.zip"), "w"); fs.ftruncateSync(fd2, Z.MAX_BYTES); fs.closeSync(fd2);   // exactly 256 MiB is allowed
  var r = await Z.scan(shExec(binDir(TOOLS)), { dirs: [r0] });
  assert.strictEqual(r.status, "ok"); assert.strictEqual(r.skipped.large, 1);
  var all = r.modules.concat(r.others).map(function (x) { return path.basename(x.path); }).sort();
  assert.deepStrictEqual(all, ["edge.zip", "ok.zip"]);
});
test("shell: at most 60 zips examined, truncated flag set", async function () {
  var r0 = fs.mkdtempSync(path.join(TMP, "many-"));
  for (var i = 0; i < 65; i++) fs.writeFileSync(path.join(r0, "z" + i + ".zip"), "x" + i);   // distinct sizes/contents not required: names differ
  var r = await Z.scan(shExec(binDir(TOOLS)), { dirs: [r0] });
  assert.strictEqual(r.status, "ok"); assert.strictEqual(r.modules.length + r.others.length, 60); assert.strictEqual(r.truncated, true);
});
test("shell: file names with a newline are skipped and counted, never mis-parsed", async function () {
  var r0 = fs.mkdtempSync(path.join(TMP, "nl-")); mkzip(r0, "fine.zip", { "module.prop": "name=Fine\n" });
  fs.writeFileSync(path.join(r0, "bad\nname.zip"), "x"); fs.writeFileSync(path.join(r0, "tab\tname.zip"), "y");
  var r = await Z.scan(shExec(binDir(TOOLS)), { dirs: [r0] });
  assert.strictEqual(r.status, "ok");
  assert.deepStrictEqual(r.modules.concat(r.others).map(function (x) { return path.basename(x.path); }), ["fine.zip"]);
  assert.ok(r.skipped.unreadable >= 1);
});
test("shell: missing zip tool -> noinspector, every zip in others, zero modules, exact note", async function () {
  var fr = fakeRoot();
  var r = await Z.scan(shExec(binDir(BASE_TOOLS)), { dirs: [fr.dl] });
  assert.strictEqual(r.status, "noinspector"); assert.strictEqual(r.method, "none"); assert.deepStrictEqual(r.modules, []);
  assert.strictEqual(r.others.length, 6); assert.strictEqual(r.note, "Could not look inside zips on this device, so they are not checked.");
});
test("shell: busybox fallback (fake busybox wrapper) is detected after unzip is absent", async function () {
  var real = cp.spawnSync("sh", ["-c", "command -v unzip"]).stdout.toString().trim(), fr = fakeRoot();
  var bb = "#!/bin/sh\n[ \"$1\" = unzip ] && { shift; exec " + real + " \"$@\"; }\necho \"busybox: applet not found\"; exit 1\n";
  var r = await Z.scan(shExec(binDir(BASE_TOOLS, { busybox: bb })), { dirs: [fr.dl] });
  assert.strictEqual(r.status, "ok", JSON.stringify(r)); assert.strictEqual(r.method, "busybox"); assert.strictEqual(r.modules.length, 3);
});
test("shell: toybox without an unzip applet is NOT accepted", async function () {
  var fr = fakeRoot();
  var tb = "#!/bin/sh\necho \"toybox: Unknown command $1\"; exit 1\n";
  var r = await Z.scan(shExec(binDir(BASE_TOOLS, { toybox: tb })), { dirs: [fr.dl] });
  assert.strictEqual(r.status, "noinspector");
});
test("shell: no find on the device -> error nofind (never ok)", async function () {
  var r = await Z.scan(shExec(binDir(["grep", "cut", "tr", "head", "wc"])), { dirs: [os.tmpdir()] });
  assert.deepStrictEqual([r.status, r.reason], ["error", "nofind"]);
});
test("shell: missing/empty dirs give a valid empty ok result", async function () {
  var r = await Z.scan(shExec(binDir(TOOLS)), { dirs: [path.join(TMP, "does-not-exist")] });
  assert.strictEqual(r.status, "ok"); assert.strictEqual(r.modules.length + r.others.length, 0);
});

/* ---------- static checks on the file itself ---------- */
test("zipscan.js is classic JS: no import/export/DOM use, under 600 lines", function () {
  var src = fs.readFileSync(path.join(__dirname, "../app/src/main/assets/js/zipscan.js"), "utf8");
  assert.ok(!/^\s*(import|export)\s/m.test(src)); assert.ok(!/\b(document|querySelector|innerHTML|onclick)\b/.test(src.replace(/\/\*[\s\S]*?\*\//, "")));
  assert.ok(src.split("\n").length < 600);
});
test("default scan dirs and limits match the handoff", function () {
  assert.deepStrictEqual(Z.DIRS, ["/sdcard/Download", "/sdcard/Downloads", "/storage/emulated/0/Download", "/sdcard", "/data/adb", "/sdcard/Modora/zips"]);
  assert.strictEqual(Z.MAX_ZIPS, 60); assert.strictEqual(Z.MAX_BYTES, 268435456);
  assert.deepStrictEqual(Z.METHODS, ["unzip", "busybox", "ksu-busybox", "magisk-busybox", "toybox"]);
  var s = Z.buildScript(); assert.ok(s.indexOf("-maxdepth 2") > 0);
});

(async function () {
  for (var i = 0; i < queue.length; i++) {
    try { await queue[i][1](); passed++; console.log("ok   - " + queue[i][0]); }
    catch (e) { failed++; console.log("FAIL - " + queue[i][0] + "\n       " + String(e && e.stack || e).split("\n").slice(0, 4).join("\n       ")); }
  }
  try { fs.rmSync(TMP, { recursive: true, force: true }); } catch (e) {}
  console.log("\n" + passed + " passed, " + failed + " failed");
  process.exit(failed ? 1 : 0);
})();
