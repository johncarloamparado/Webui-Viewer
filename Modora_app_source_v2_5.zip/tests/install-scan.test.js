/* MINI 1C tests: Scan zips -> MDZipScan -> install sheet (module list, Other zips, Selected card, i18n). Run: node tests/install-scan.test.js
 * Needs Playwright + Chromium (PLAYWRIGHT_MODULE / CHROMIUM env vars) and the `zip` CLI. Same fake-bridge approach as install-sheet.test.js:
 * window.ksu.exec runs the command with the real /bin/sh on a fake root in a temp dir; nothing touches a real device. */
"use strict";
var fs = require("fs"), os = require("os"), path = require("path"), cp = require("child_process"), assert = require("assert");
var pw = require(process.env.PLAYWRIGHT_MODULE || "/opt/npm-tools/node_modules/playwright");
var CHROMIUM = process.env.CHROMIUM || "/opt/pw-browsers/chromium";
var ASSETS = path.resolve(__dirname, "../app/src/main/assets");
var PAGE = "file://" + ASSETS + "/home.html";

var TMP = fs.mkdtempSync(path.join(os.tmpdir(), "inst-scan-"));
var ROOT = path.join(TMP, "root"), BIN = path.join(TMP, "bin"), BIN_NOUNZIP = path.join(TMP, "bin-nounzip");
var DL = path.join(ROOT, "sdcard/Download");
fs.mkdirSync(DL, { recursive: true }); fs.mkdirSync(path.join(ROOT, "sdcard/Modora/zips"), { recursive: true }); fs.mkdirSync(BIN); fs.mkdirSync(BIN_NOUNZIP);
var FAKE_KSUD = "#!/bin/sh\necho \"ksud-fake: $1 $2 $3\"\nexit 0\n";
fs.writeFileSync(path.join(BIN, "ksud"), FAKE_KSUD, { mode: 493 });
fs.writeFileSync(path.join(BIN_NOUNZIP, "ksud"), FAKE_KSUD, { mode: 493 });
["find", "grep", "cut", "tr", "head", "wc", "cat", "rm", "sleep"].forEach(function (t) {     // a PATH with NO unzip/busybox/toybox
  var p = cp.spawnSync("sh", ["-c", "command -v " + t]).stdout.toString().trim();
  if (p) fs.symlinkSync(p, path.join(BIN_NOUNZIP, t));
});

function mkzip(dir, name, files) {
  var src = fs.mkdtempSync(path.join(TMP, "src-"));
  Object.keys(files).forEach(function (e) { var p = path.join(src, e); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, files[e]); });
  cp.execFileSync("zip", ["-q", "-r", path.join(dir, name), "."], { cwd: src });
}
mkzip(DL, "alpha_release.zip", { "module.prop": "id=alpha\nname=Alpha Tweaks\nversion=v2.1\nversionCode=21\n", "service.sh": "#!/system/bin/sh\n" });
mkzip(DL, "noname.zip", { "module.prop": "id=noname\nversion=3\nversionCode=3\n" });
mkzip(DL, "xss.zip", { "module.prop": "id=x\nname=<img src=x onerror=window.__xss=1>\nversion=1\nversionCode=1\n" });
mkzip(path.join(ROOT, "sdcard/Modora/zips"), "saved_beta.zip", { "module.prop": "id=beta\nname=Beta\nversion=0.9\nversionCode=9\n" });
mkzip(DL, "nested.zip", { "folder/module.prop": "id=n\nname=Nested\nversion=1\nversionCode=1\n" });
mkzip(DL, "source-main.zip", { "repo-main/README.md": "hello\n", "repo-main/src/a.c": "int a;\n" });
fs.writeFileSync(DL + "/notazip.zip", "this is not a zip");

var INSTALL_CMD_1B = "  function installCmd(path) {\n    return 'ZIP=' + MD.shq(path) + '; ' +\n      'if command -v ksud >/dev/null 2>&1; then ksud module install \"$ZIP\" 2>&1; ' +\n      'elif command -v magisk >/dev/null 2>&1; then magisk --install-module \"$ZIP\" 2>&1; ' +\n      'elif [ -x /data/adb/ksud ]; then /data/adb/ksud module install \"$ZIP\" 2>&1; ' +\n      'elif [ -x /data/adb/magisk/magisk ]; then /data/adb/magisk/magisk --install-module \"$ZIP\" 2>&1; ' +\n      'else echo \"No ksud/magisk found\"; exit 1; fi';\n  }\n";
var cmdLog = [], mode = "normal";
function remap(cmd) {
  return cmd.replace(/\/storage\/emulated\/0/g, ROOT + "/sdcard").replace(/(^|[^A-Za-z0-9_.\/-])\/sdcard/g, "$1" + ROOT + "/sdcard").replace(/(^|[^A-Za-z0-9_.\/-])\/data\/adb/g, "$1" + ROOT + "/adb");
}
function hostExec(cmd, timeout) {
  cmdLog.push(cmd);
  var bin = mode === "nounzip" ? BIN_NOUNZIP : BIN + ":" + process.env.PATH;
  return new Promise(function (resolve) {
    var ch = cp.spawn("/bin/sh", ["-c", remap(cmd)], { env: { PATH: bin }, detached: true, stdio: ["ignore", "pipe", "pipe"] });
    var out = "", done = false;
    ch.stdout.on("data", function (d) { out += d; }); ch.stderr.on("data", function (d) { out += d; });
    var t = timeout > 0 ? setTimeout(function () { try { process.kill(-ch.pid, "SIGKILL"); } catch (e) {} fin(-2); }, timeout) : null;
    function fin(code) { if (done) return; done = true; if (t) clearTimeout(t); resolve({ code: code, out: out.split(ROOT + "/sdcard").join("/sdcard"), err: "" }); }
    ch.on("close", function (c) { fin(c == null ? -1 : c); });
    ch.on("error", function () { fin(-1); });
  });
}
var INIT = function () {
  window.ksu = {
    exec: function (cmd, opts, cb) {
      var o = {}; try { o = JSON.parse(opts || "{}"); } catch (e) {}
      if (window.__fake && /MDZS1/.test(cmd)) { var f = window.__fake; setTimeout(function () { if (window[cb]) window[cb](f.code, f.out, ""); }, 0); return; }
      window.__hostExec(cmd, o.timeout || 0).then(function (r) { setTimeout(function () { if (window[cb]) window[cb](r.code, r.out, r.err); }, 0); });
    },
    pickZip: function () {}, toast: function () {}, appInfo: function () { return "{}"; }
  };
  try { localStorage.setItem("md.onboarded", "1"); } catch (e) {}
};

var queue = [], passed = 0, failed = 0;
function test(name, fn) { queue.push([name, fn]); }
async function openPage(browser, opts) {
  var ctx = await browser.newContext(Object.assign({ viewport: { width: 360, height: 800 } }, opts || {}));
  var page = await ctx.newPage(), errors = [];
  page.on("pageerror", function (e) { errors.push(String(e)); });
  await page.exposeFunction("__hostExec", hostExec);
  await page.addInitScript(INIT);
  await page.goto(PAGE);
  await page.waitForFunction("window.MDRouter && window.MDI18n && window.MD && MD.sh && window.MDZipScan && window.MDZipView", null, { timeout: 8000 });
  await page.waitForTimeout(300);
  page.__errors = errors;
  return page;
}
async function openInstall(page) {
  await page.evaluate(function () { document.querySelector("#more").click(); document.querySelector('[data-qa="install"]').click(); });
  await page.waitForSelector("#install.on");
  await page.waitForFunction("!document.getElementById('inst-scan').disabled", null, { timeout: 15000 });
}
function txt(page, sel) { return page.evaluate(function (s) { return document.querySelector(s).textContent.trim(); }, sel); }
function vis(page, sel) { return page.locator(sel).isVisible(); }
async function rescan(page) { await page.click("#inst-scan"); await page.waitForFunction("!document.getElementById('inst-scan').disabled", null, { timeout: 15000 }); }

test("modules section: only root module.prop zips, titled from module.prop, subtitle = file name + size", async function (b) {
  mode = "normal"; var page = await openPage(b); await openInstall(page);
  assert.strictEqual(await txt(page, "#inst-found-l"), "Zips found (4)");           // alpha, noname, xss, saved_beta
  var rows = await page.evaluate(function () { return [].slice.call(document.querySelectorAll("#inst-list .row")).map(function (r) { return [r.dataset.zip, r.querySelector("b").textContent, r.querySelector("small").textContent]; }); });
  var by = {}; rows.forEach(function (r) { by[r[0].split("/").pop()] = r; });
  assert.deepStrictEqual(Object.keys(by).sort(), ["alpha_release.zip", "noname.zip", "saved_beta.zip", "xss.zip"], JSON.stringify(rows));
  assert.strictEqual(by["alpha_release.zip"][1], "Alpha Tweaks v2.1");
  assert.ok(/^alpha_release\.zip · \d+(\.\d)? (KB|MB)$/.test(by["alpha_release.zip"][2]), by["alpha_release.zip"][2]);
  assert.strictEqual(by["noname.zip"][1], "Unnamed module v3", by["noname.zip"][1]);   // filename is never used as the module name
  assert.ok(by["saved_beta.zip"][0].indexOf("/sdcard/Modora/zips/") === 0, "the /sdcard/Modora/zips directory is scanned");
  assert.strictEqual(await page.evaluate("window.__xss"), undefined, "module name must be rendered as text");
  assert.ok(/<img src=x/.test(by["xss.zip"][1]));
  assert.deepStrictEqual(page.__errors, []);
});
test("Other zips: collapsed by default, lists nested/source/non-zip, header + Show-all toggle stay in sync, keyboard works", async function (b) {
  mode = "normal"; var page = await openPage(b); await openInstall(page);
  assert.strictEqual(await txt(page, "#inst-other-l"), "Other zips (3)");           // nested, source-main, notazip
  assert.strictEqual(await page.getAttribute("#inst-other-t", "aria-expanded"), "false");
  assert.ok(!(await vis(page, "#inst-other-list")));
  assert.strictEqual(await txt(page, "#inst-showall"), "Show all zips");
  await page.focus("#inst-other-t"); await page.keyboard.press("Enter");
  assert.strictEqual(await page.getAttribute("#inst-other-t", "aria-expanded"), "true");
  assert.strictEqual(await page.getAttribute("#inst-showall", "aria-expanded"), "true");
  assert.strictEqual(await txt(page, "#inst-showall"), "Hide other zips");
  var names = await page.evaluate(function () { return [].slice.call(document.querySelectorAll("#inst-other-list .row")).map(function (r) { return r.dataset.zip.split("/").pop(); }).sort(); });
  assert.deepStrictEqual(names, ["nested.zip", "notazip.zip", "source-main.zip"]);
  await page.keyboard.press("Space");
  assert.strictEqual(await page.getAttribute("#inst-other-t", "aria-expanded"), "false");
  await page.click("#inst-showall");
  assert.strictEqual(await page.getAttribute("#inst-other-t", "aria-expanded"), "true");
  assert.strictEqual(await page.getAttribute("#inst-other-b", "role"), "region");
  assert.ok(await page.evaluate(function () { return document.getElementById("inst-showall").getBoundingClientRect().height >= 43.5; }));
});
var FIL = JSON.parse(fs.readFileSync(ASSETS + "/i18n/fil.json", "utf8"));
function qrows(page) { return page.evaluate(function () { return [].slice.call(document.querySelectorAll("#inst-queue-list .ins-q-row")).map(function (r) { return { id: r.dataset.queueId, name: r.querySelector("b").textContent, meta: r.querySelector("small").textContent, status: r.querySelector(".ins-q-status").textContent }; }); }); }
test("selecting a module adds it to the install queue (name, version, size, path, status); tapping again removes it", async function (b) {
  mode = "normal"; var page = await openPage(b); await openInstall(page);
  assert.ok(!(await vis(page, "#inst-queue")) && await page.isDisabled("#inst-run"));
  await page.click('#inst-list [data-zip$="alpha_release.zip"]');
  var r = await qrows(page); assert.strictEqual(r.length, 1);
  assert.strictEqual(r[0].name, "Alpha Tweaks"); assert.strictEqual(r[0].status, "Queued");
  assert.ok(/^v2\.1 · \d/.test(r[0].meta) && r[0].meta.endsWith("/Download/alpha_release.zip"), r[0].meta);
  assert.strictEqual(await txt(page, "#inst-queue-count"), "1 of 10 modules selected");
  assert.strictEqual(await page.getAttribute('#inst-list [data-zip$="alpha_release.zip"]', "aria-current"), "true");
  assert.ok(!(await vis(page, "#inst-sel")), "legacy single Selected card is retired");
  assert.ok(!(await page.isDisabled("#inst-run"))); assert.strictEqual(await txt(page, "#inst-run"), "Install 1 module");
  await page.click('#inst-list [data-zip$="alpha_release.zip"]');
  assert.strictEqual((await qrows(page)).length, 0); assert.ok(await page.isDisabled("#inst-run"));
});
test("selecting an Other zip queues it, lists stay intact, and the install command is unchanged", async function (b) {
  mode = "normal"; var page = await openPage(b); await openInstall(page);
  await page.click("#inst-showall");
  await page.click('#inst-other-list [data-zip$="nested.zip"]');
  var r = await qrows(page); assert.strictEqual(r.length, 1); assert.ok(/\/Download\/nested\.zip$/.test(r[0].meta), r[0].meta);
  assert.strictEqual(await page.locator("#inst-other-list .row").count(), 3);
  assert.strictEqual(await page.locator("#inst-list .row").count(), 4);
  assert.ok(!(await page.isDisabled("#inst-run")), "an Other zip must not by itself block Install");
  cmdLog.length = 0;
  await page.click("#inst-run"); await page.waitForSelector("#inst-done:not([hidden])", { timeout: 15000 });
  assert.ok(cmdLog.some(function (c) { return c.indexOf("/sdcard/Download/nested.zip") >= 0 && c.indexOf("ksud module install") >= 0; }), "the install command ran for the selected path");
  var html = fs.readFileSync(ASSETS + "/home.html", "utf8"), a = html.indexOf("  function installCmd(path) {"), z = html.indexOf("  function instMsg");
  assert.strictEqual(html.slice(a, z), INSTALL_CMD_1B, "installCmd(path) must stay byte-identical to the MINI 1B source");
});
test("Remove (per row) and Clear all: lists stay intact, source controls enabled, another file can be chosen", async function (b) {
  mode = "normal"; var page = await openPage(b); await openInstall(page);
  await page.click("#inst-showall"); await page.click('#inst-other-list [data-zip$="source-main.zip"]');
  assert.strictEqual((await qrows(page)).length, 1);
  await page.click("#inst-queue-list .ins-q-remove");
  assert.strictEqual((await qrows(page)).length, 0); assert.ok(!(await vis(page, "#inst-queue")));
  assert.ok(await page.isDisabled("#inst-run"));
  assert.ok(!(await page.isDisabled("#inst-browse")) && !(await page.isDisabled("#inst-scan")));
  assert.strictEqual(await page.locator("#inst-list .row").count(), 4); assert.strictEqual(await page.locator("#inst-other-list .row").count(), 3);
  assert.strictEqual(await page.locator('[aria-current="true"]').count(), 0);
  await page.click('#inst-list [data-zip$="noname.zip"]'); await page.click('#inst-list [data-zip$="alpha_release.zip"]');
  assert.strictEqual((await qrows(page)).length, 2); assert.strictEqual(await txt(page, "#inst-run"), "Install 2 modules");
  await page.click("#inst-clear");
  assert.strictEqual((await qrows(page)).length, 0); assert.strictEqual(await page.locator('[aria-current="true"]').count(), 0);
});
test("pasted path: a bad path is skipped with the human reason and not queued; a good path is queued", async function (b) {
  mode = "normal"; var page = await openPage(b); await openInstall(page);
  await page.click("#inst-paste"); await page.fill("#inst-path", "/etc/passwd.zip"); await page.click("#inst-add-path");
  assert.ok(/^Skipped: Use \/sdcard/.test(await txt(page, "#inst-msg")), await txt(page, "#inst-msg"));
  assert.strictEqual((await qrows(page)).length, 0); assert.ok(await page.isDisabled("#inst-run"));
  await page.fill("#inst-path", "/sdcard/Download/nested.zip"); await page.click("#inst-add-path");
  await page.waitForFunction("document.querySelectorAll('#inst-queue-list .ins-q-row').length === 1", null, { timeout: 8000 });
  assert.ok(!(await page.isDisabled("#inst-run")));
});
test("no inspection tool: note shown, NOTHING listed as a module, all zips under Other; a queued zip shows 'Version unknown'", async function (b) {
  mode = "nounzip"; var page = await openPage(b); await openInstall(page);
  assert.strictEqual(await txt(page, "#inst-scan-note"), "Could not look inside zips on this device, so they are not checked.");
  assert.strictEqual(await page.locator("#inst-list .row").count(), 0);
  assert.strictEqual(await txt(page, "#inst-other-l"), "Other zips (7)");
  assert.strictEqual(await page.getAttribute("#inst-other-t", "aria-expanded"), "false");
  await page.click("#inst-showall");
  assert.strictEqual(await page.locator("#inst-other-list .row").count(), 7);
  await page.click('#inst-other-list [data-zip$="alpha_release.zip"]');
  var r = await qrows(page); assert.strictEqual(r.length, 1);
  assert.ok(/^Version unknown/.test(r[0].meta), "must not claim module metadata: " + r[0].meta);
  assert.ok(!(await page.isDisabled("#inst-run")));
  await page.click("#inst-queue-list .ins-q-remove");
  assert.strictEqual(await page.locator("#inst-other-list .row").count(), 7);          // results stay visible after removing
  mode = "normal";
});
test("no module zips found: empty-state text; Other zips still reachable", async function (b) {
  mode = "normal"; var page = await openPage(b); await openInstall(page);
  await page.evaluate(function () { window.__fake = { code: 0, out: "MDZS1\tBEGIN\nMDZS1\tMETHOD\tunzip\nMDZS1\tO\t10\t/sdcard/Download/only.zip\nMDZS1\tSKIP\t0\t0\t0\nMDZS1\tEND\t1\n" }; });
  await rescan(page);
  assert.strictEqual(await txt(page, "#inst-found-l"), "Zips found (0)");
  assert.strictEqual(await txt(page, "#inst-list .empty"), "No module zips found. Use Browse or paste a path.");
  assert.strictEqual(await txt(page, "#inst-other-l"), "Other zips (1)");
  await page.evaluate(function () { window.__fake = { code: 0, out: "MDZS1\tBEGIN\nMDZS1\tMETHOD\tunzip\nMDZS1\tSKIP\t0\t0\t0\nMDZS1\tEND\t0\n" }; });
  await rescan(page);
  assert.strictEqual(await txt(page, "#inst-list .empty"), "No module zips found. Use Browse or paste a path.");
  assert.ok(!(await vis(page, "#inst-other")));
});
test("scan failures are reported honestly: timeout, bridge, malformed, incomplete; no zips shown; Scan can be retried", async function (b) {
  mode = "normal"; var page = await openPage(b); await openInstall(page);
  var cases = [
    [{ code: -2, out: "" }, /took too long/], [{ code: -5, out: "" }, /Could not scan for zips/], [{ code: 0, out: "" }, /Could not scan for zips/],
    [{ code: 0, out: "MDZS1\tBEGIN\nMDZS1\tMETHOD\tunzip\nMDZS1\tO\t1\t/sdcard/a.zip\n" }, /incomplete/],
    [{ code: 0, out: "MDZS1\tBEGIN\nMDZS1\tMETHOD\tunzip\nMDZS1\tO\tx\t/sdcard/a.zip\nMDZS1\tSKIP\t0\t0\t0\nMDZS1\tEND\t1\n" }, /incomplete/],
    [{ code: 0, out: "MDZS1\tBEGIN\nMDZS1\tMETHOD\tunzip\nMDZS1\tO\t1\t/sdcard/a.zip\nMDZS1\tSKIP\t0\t0\t0\nMDZS1\tEND\t5\n" }, /incomplete/],
    [{ code: 0, out: "garbage without markers" }, /incomplete/]
  ];
  for (var i = 0; i < cases.length; i++) {
    await page.evaluate(function (f) { window.__fake = f; }, cases[i][0]);
    await rescan(page);
    var note = await txt(page, "#inst-scan-note");
    assert.ok(cases[i][1].test(note), i + ": " + note);
    assert.ok(!(await vis(page, "#inst-found")) && !(await vis(page, "#inst-other")) && !(await vis(page, "#inst-showall")), i + ": nothing may be listed after a failed scan");
    assert.ok(!(await page.isDisabled("#inst-scan")));
  }
  await page.evaluate(function () { window.__fake = null; }); await rescan(page);        // recovers on a good scan
  assert.strictEqual(await txt(page, "#inst-found-l"), "Zips found (4)"); assert.strictEqual(await txt(page, "#inst-scan-note"), "");
});
test("busy: Scan is disabled while a scan runs and a second tap does not start another scan", async function (b) {
  mode = "normal"; var page = await openPage(b); await openInstall(page);
  cmdLog.length = 0;
  var r = await page.evaluate(function () {
    var s = document.getElementById("inst-scan"); s.click(); var dis = s.disabled; s.click(); s.click();
    return dis;
  });
  assert.strictEqual(r, true);
  await page.waitForFunction("!document.getElementById('inst-scan').disabled", null, { timeout: 15000 });
  assert.strictEqual(cmdLog.filter(function (c) { return c.indexOf("MDZS1") >= 0; }).length, 1, "exactly one scan command");
});
test("scan command is read-only and has an overall timeout", async function (b) {
  mode = "normal"; var page = await openPage(b); cmdLog.length = 0; await openInstall(page);
  var sc = cmdLog.filter(function (c) { return c.indexOf("MDZS1") >= 0; });
  assert.strictEqual(sc.length, 1);
  var body = sc[0].replace(/2>&1|2>\/dev\/null|>\/dev\/null/g, "");
  assert.ok(!/\b(rm|mv|cp|chmod|mkdir|touch|tee|dd|ln|chown)\b|sed -i|>\s*[^&\s]/.test(body), "scan script must not write");
  (body.match(/\bzi [^\n|]*/g) || []).filter(function (x) { return !/^zi\(\)/.test(x); }).forEach(function (x) { assert.ok(/^zi -[lp] /.test(x), "only unzip -l / -p are used: " + x); });
  var src = fs.readFileSync(ASSETS + "/home.html", "utf8");
  assert.ok(/MDZipScan\.scan\(MD\.sh, \{ timeout: SCAN_TIMEOUT(, dirs: dirs)? \}\)/.test(src) && /SCAN_TIMEOUT = 30000/.test(src));
});
test("Filipino: new strings are localized (section, toggle, chip, note, empty state)", async function (b) {
  mode = "normal"; var page = await openPage(b); await page.evaluate("MDI18n.setLang('fil')"); await openInstall(page);
  assert.ok(/^Mga zip na nakita \(4\)$/.test(await txt(page, "#inst-found-l")), await txt(page, "#inst-found-l"));
  assert.strictEqual(await txt(page, "#inst-other-l"), "Iba pang mga zip (3)");
  assert.strictEqual(await txt(page, "#inst-showall"), "Ipakita ang lahat ng zip");
  await page.click("#inst-showall"); assert.strictEqual(await txt(page, "#inst-showall"), "Itago ang iba pang zip");
  await page.click('#inst-other-list [data-zip$="nested.zip"]');
  assert.strictEqual(await txt(page, "#inst-queue-count"), FIL["install.queue_count"].replace("{n}", "1"));
  assert.strictEqual(await txt(page, "#inst-queue-list .ins-q-status"), FIL["install.q_out_queued"]);
  await page.click("#inst-queue-list .ins-q-remove");
  await page.evaluate(function () { window.__fake = { code: 0, out: "MDZS1\tBEGIN\nMDZS1\tMETHOD\tunzip\nMDZS1\tSKIP\t0\t0\t0\nMDZS1\tEND\t0\n" }; });
  await rescan(page);
  assert.strictEqual(await txt(page, "#inst-list .empty"), "Walang nakitang module zip. Gamitin ang Browse o mag-paste ng path.");
  await page.evaluate("MDI18n.setLang('en')");
});
test("keyboard + touch targets + reduced motion for the new controls; no inline handlers; files stay small", async function (b) {
  mode = "normal"; var page = await openPage(b, { reducedMotion: "reduce" }); await openInstall(page);
  await page.click("#inst-showall");
  var small = await page.evaluate(function () { return [].slice.call(document.querySelectorAll("#install button")).filter(function (x) { return x.offsetParent !== null && x.getBoundingClientRect().height < 43.5; }).map(function (x) { return x.id || x.className; }); });
  assert.deepStrictEqual(small, []);
  var d = await page.evaluate("getComputedStyle(document.querySelector('#inst-other-t .md-icon')).transitionDuration");
  assert.ok(d.split(",").every(function (x) { return parseFloat(x) < 0.001; }), d);
  var html = fs.readFileSync(ASSETS + "/home.html", "utf8");
  assert.ok(!/onclick=/i.test(html.slice(html.indexOf("<!-- Install module"), html.indexOf("<nav id=\"md-tabbar\""))));
  ["js/zipscan-view.js", "js/zipscan.js", "css/install.css"].forEach(function (f) { assert.ok(fs.readFileSync(ASSETS + "/" + f, "utf8").split("\n").length < 600, f); });
  assert.ok(!/\bimport\b|\bexport\b|innerHTML/.test(fs.readFileSync(ASSETS + "/js/zipscan-view.js", "utf8").replace(/\/\*[\s\S]*?\*\//g, "")));
  assert.deepStrictEqual(page.__errors, []);
});

(async function () {
  var browser = await pw.chromium.launch({ executablePath: CHROMIUM, args: ["--no-sandbox"] });
  for (var i = 0; i < queue.length; i++) {
    try { await queue[i][1](browser); passed++; console.log("ok   - " + queue[i][0]); }
    catch (e) { failed++; console.log("FAIL - " + queue[i][0] + "\n       " + String(e && e.stack || e).split("\n").slice(0, 5).join("\n       ")); }
  }
  await browser.close();
  try { fs.rmSync(TMP, { recursive: true, force: true }); } catch (e) {}
  console.log("\n" + passed + " passed, " + failed + " failed");
  process.exit(failed ? 1 : 0);
})();
