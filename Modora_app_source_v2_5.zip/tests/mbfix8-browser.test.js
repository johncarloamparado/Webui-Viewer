const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/opt/npm-tools/node_modules/playwright');
const path = require('path');
const A = path.resolve(__dirname, '../app/src/main/assets');
const results = []; const ok=(n,c,x)=>{results.push([n,!!c]); console.log((c?'PASS ':'FAIL ')+n+(x?' :: '+x:''));};
(async()=>{
 const b = await chromium.launch({ executablePath: process.env.CHROMIUM || '/opt/pw-browsers/chromium', args: ['--no-sandbox'] });
 async function page(vp, scheme, file='home.html'){
  const ctx = await b.newContext({viewport:vp, colorScheme:scheme});
  const p = await ctx.newPage(); const errs=[]; const cmds=[];
  p.on('pageerror',e=>errs.push(String(e))); p.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
  await p.addInitScript(()=>{ try{localStorage.setItem('md.onboarded','1')}catch(e){} window.__cmds=[]; window.ksu={ exec:function(c,o,cb){window.__cmds.push(c);setTimeout(()=>{window[cb](0,'cpu  1 1 1 1 1 1 1 0\nMemTotal: 1000 kB\nMemAvailable: 400 kB\nB:capacity=80\nB:temp=350\n','')},5)}, toast(){},copy(){},share(){},vibrate(){},appInfo(){return '{}'},sysAccent(){return ''},setBars(){return true},rootShellInfo(){return '{}'},webrootCacheInfo(){return '{}'} }; });
  await p.goto('file://'+A+'/'+file); await p.waitForTimeout(800);
  return {p,ctx,errs};
 }
 // 1. collapsed default, no sampling
 let {p,ctx,errs} = await page({width:360,height:640},'dark');
 await p.waitForTimeout(3500);
 const nstat = await p.evaluate(()=>window.__cmds.filter(c=>/MemAvailable|\/proc\/stat/.test(c)).length);
 ok('stats collapsed by default', await p.evaluate(()=>document.getElementById('stats-strip').classList.contains('is-collapsed')||!!document.querySelector('#stats-strip .is-collapsed')));
 ok('no stats command while collapsed', nstat===0, 'count='+nstat);
 await p.screenshot({path:'shots/deck-collapsed-dark-360.png'});
 // toggle expand
 const tg = p.locator('.md-stats-toggle'); 
 const bb = await tg.boundingBox(); ok('toggle >=44px', bb.width>=44&&bb.height>=44, JSON.stringify(bb));
 await tg.click(); await p.waitForTimeout(3500);
 const n2 = await p.evaluate(()=>window.__cmds.filter(c=>/MemAvailable|\/proc\/stat/.test(c)).length);
 ok('sampling starts when expanded', n2>0, 'count='+n2);
 ok('aria-expanded true', (await tg.getAttribute('aria-expanded'))==='true');
 ok('localStorage collapsed=0', (await p.evaluate(()=>localStorage.getItem('md.stats.collapsed')))==='0');
 await p.screenshot({path:'shots/deck-expanded-dark-360.png'});
 await p.reload(); await p.waitForTimeout(2000);
 ok('expanded state persists across reload', (await p.locator('.md-stats-toggle').getAttribute('aria-expanded'))==='true');
 await p.locator('.md-stats-toggle').click(); await p.waitForTimeout(500);
 await p.reload(); await p.waitForTimeout(2000);
 ok('collapsed persists across reload', (await p.locator('.md-stats-toggle').getAttribute('aria-expanded'))==='false');
 ok('no console errors (deck)', errs.length===0, errs.join('|'));
 await ctx.close();

 // 2. Tools tab
 for (const [vp,sc] of [[{width:360,height:640},'dark'],[{width:412,height:915},'light']]) {
  ({p,ctx,errs} = await page(vp,sc));
  await p.evaluate(()=>window.MDShell.open('tools')); await p.waitForTimeout(800);
  const txt = await p.evaluate(()=>document.getElementById('tools-body').innerText);
  ok(`tools has Diagnostics+Logs ${vp.width}`, /diagnostic/i.test(txt) && /log/i.test(txt));
  ok(`tools no Profiles/Backup/Restore ${vp.width}`, !/profile|backup|restore/i.test(txt), txt.slice(0,200).replace(/\n/g,' / '));
  await p.screenshot({path:`shots/tools-${sc}-${vp.width}.png`});
  // 3. select bug
  const sels = await p.locator('#tools-body select').count(); ok('logs selects exist', sels>=2, 'n='+sels);
  for (const id of ['dg-src','dg-n']) {
    const s = p.locator('#'+id); await s.focus();
    ok(`${id} focus: no md-kbd`, !(await p.evaluate(()=>document.body.classList.contains('md-kbd'))));
    const opts = await s.locator('option').evaluateAll(o=>o.map(x=>x.value));
    await s.selectOption(opts[opts.length-1]); await p.waitForTimeout(300);
    ok(`${id} after choose: no md-kbd`, !(await p.evaluate(()=>document.body.classList.contains('md-kbd'))));
    const vis = await p.evaluate(()=>{const b=document.getElementById('md-tabbar');const r=b.getBoundingClientRect();return getComputedStyle(b).display!=='none'&&r.height>0});
    ok(`${id} tab bar visible`, vis);
  }
  await p.screenshot({path:`shots/logs-after-select-${sc}-${vp.width}.png`});
  ok(`no console errors tools ${vp.width}`, errs.length===0, errs.join('|'));
  await ctx.close();
 }
 // 4. old-bug repro: simulate base shell? (select focus with base) done separately
 // 5. text input still hides bar then releases
 ({p,ctx,errs} = await page({width:360,height:640},'dark'));
 await p.evaluate(()=>window.MDShell.open('modules')); await p.waitForTimeout(500);
 await p.evaluate(()=>{const i=document.createElement('input');i.type='text';i.id='tmpin';document.body.appendChild(i);});
 await p.focus('#tmpin'); await p.waitForTimeout(100);
 ok('text input hides bar', await p.evaluate(()=>document.body.classList.contains('md-kbd')));
 await p.evaluate(()=>document.activeElement.blur()); await p.waitForTimeout(400);
 ok('text input blur releases bar', !(await p.evaluate(()=>document.body.classList.contains('md-kbd'))));
 // Settings selects
 await p.evaluate(()=>window.MDShell.open('settings')); await p.waitForTimeout(600);
 const ss = p.locator('select'); const sc2 = await ss.count(); let sok=true;
 for (let i=0;i<sc2;i++){ const s=ss.nth(i); if(!(await s.isVisible()))continue; await s.focus(); const o=await s.locator('option').evaluateAll(o=>o.map(x=>x.value)); if(o.length>1) await s.selectOption(o[o.length-1]).catch(()=>{}); await p.waitForTimeout(150); if(await p.evaluate(()=>document.body.classList.contains('md-kbd'))) sok=false; }
 ok('settings selects ('+sc2+') never leave md-kbd', sok);
 await ctx.close();
 // 6. page-load matrix
 for (const f of ['home.html','action.html','rme50.html','anr.html']) {
  ({p,ctx,errs} = await page({width:360,height:640},'dark',f));
  ok('loads '+f+' no errors', errs.length===0 && (await p.evaluate(()=>document.body.innerText.length))>20, errs.join('|'));
  await ctx.close();
 }
 await b.close();
 const f = results.filter(r=>!r[1]).length; console.log(`\n${results.length-f}/${results.length} passed`); process.exit(f?1:0);
})();
