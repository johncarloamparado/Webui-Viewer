/* MINI 2C: source-level guardrails for queue + saved-copy UI integration.
 * Runtime behavior is covered by installq.test.js / savedcopy.test.js; browser tests use the project's Playwright suite.
 */
"use strict";
const fs = require("node:fs");
const path = require("node:path");
const assert = require("node:assert/strict");
const ROOT = path.resolve(__dirname, "..");
const ASSETS = path.join(ROOT, "app/src/main/assets");
const read = (p) => fs.readFileSync(path.join(ASSETS, p), "utf8");
const home = read("home.html");
const settings = read("js/settings.js");
const zipView = read("js/zipscan-view.js");
const saved = read("js/savedcopy.js");
const q = read("js/installq.js");
const css = read("css/install.css");
const en = JSON.parse(fs.readFileSync(path.join(ASSETS, "i18n/en.json"), "utf8"));
const fil = JSON.parse(fs.readFileSync(path.join(ASSETS, "i18n/fil.json"), "utf8"));

function check(name, fn) {
  try { fn(); process.stdout.write("ok   - " + name + "\n"); }
  catch (err) { process.stderr.write("not ok - " + name + "\n" + (err.stack || err) + "\n"); process.exitCode = 1; }
}

check("home includes the queue UI, per-item remove, clear-all, progress, summary and retry controls", () => {
  for (const id of ["inst-queue", "inst-queue-count", "inst-queue-list", "inst-clear", "inst-progress", "inst-summary", "inst-retry", "inst-cancel"]) {
    assert.match(home, new RegExp('id="' + id + '"'));
  }
  assert.match(home, /remove\.dataset\.qremove\s*=\s*item\.id/);
  assert.match(home, /installQueue\.clear\(\)/);
  assert.match(home, /install\.q_version_unknown/);
  assert.match(home, /install\.q_size_unknown/);
  assert.match(home, /installQueue\.items\(\)\.filter\(function \(it\) \{ return it\.status === 'failed'; \}\)/);
});

check("scan rows multi-select and visibly tag saved copies without injecting HTML", () => {
  assert.match(home, /function toggleQueuePath\(path\)/);
  assert.match(home, /MDZipView\.mark\([^;]+chosen\)/);
  assert.match(zipView, /Array\.isArray\(selected\)/);
  assert.match(zipView, /ins-saved-tag/);
  assert.match(zipView, /tag\.textContent\s*=\s*o\.savedLabel/);
  assert.doesNotMatch(zipView, /\.innerHTML\s*=/);
});

check("Browse stages each native single-picked ZIP into its own queued temp copy", () => {
  assert.match(home, /savedCopier\.stagePicked\(\{ path: path, id:/);
  assert.match(home, /addQueueItem\(\{ path: staged\.path,[\s\S]*?source: 'browse' \}\)/);
  assert.match(saved, /stagePicked:\s*function/);
  assert.match(saved, /TMP_DIR\s*=\s*"\/data\/local\/tmp\/modora_queue"/);
  assert.match(home, /installQueue\.size\(\) > 0\) \? T\('install\.add_another'/);
});

check("engine handles the whole queue with one completion refresh and running-install protection", () => {
  assert.match(home, /MDInstallQ\.createEngine\(/);
  assert.match(home, /onEnd:\s*function \(summary\)/);
  assert.match(home, /if \(summary && summary\.refresh\)[\s\S]*?load\(true\)/);
  assert.match(home, /\(\(installEngine && installEngine\.running\) \|\| instJob \|\| installing\)/);
  assert.match(q, /Skipped: /);
  assert.match(q, /retryFailed:\s*function/);
});

check("saved-copy Settings uses the required key, ON default, read-only folder, stats call and saved-only scan", () => {
  assert.match(saved, /SETTING_KEY\s*=\s*"md\.install\.savecopy"/);
  assert.match(saved, /: true;\s*\/\/ anything else \(missing, corrupt\) -> default ON/);
  assert.match(settings, /settings\.savecopy_folder/);
  assert.match(settings, /settings\.show_saved_zips/);
  assert.match(settings, /MD\.sh\(cmd, \{ timeout: 7000 \}\)/);
  assert.match(home, /const dirs = savedOnly \? \['\/sdcard\/Modora\/zips'\]/);
  assert.match(home, /showSavedZips: function \(\) \{ installOpen\(true, \{ savedOnly: true \}\); \}/);
  assert.doesNotMatch(settings, /addEventListener\(['"]click['"],[\s\S]{0,150}rm\s+-rf/);
});

check("visible controls are accessible, classic-script based and avoid inline onclick handlers", () => {
  assert.match(home, /aria-expanded="false" aria-controls="inst-pastebox"/);
  assert.match(home, /role="status" aria-live="polite"/);
  assert.match(home, /<script defer src="js\/installq\.js"><\/script>/);
  assert.match(home, /<script defer src="js\/savedcopy\.js"><\/script>/);
  assert.doesNotMatch(home, /\sonclick\s*=/i);
  assert.match(css, /min-height:\s*var\(--md-tap\)/);
  assert.match(css, /prefers-reduced-motion/);
  assert.match(read("css/tokens.css"), /--md-tap:\s*44px/);
});

check("per-ZIP install command and timeout remain the expected baseline values", () => {
  const start = home.indexOf("  function installCmd(path) {");
  assert.notEqual(start, -1);
  const end = home.indexOf("\n  }", start) + 4;
  const fn = home.slice(start, end);
  assert.ok(fn.includes("MD.shq(path)"));
  assert.ok(fn.includes("ksud module install \"$ZIP\""));
  assert.ok(fn.includes("magisk --install-module \"$ZIP\""));
  assert.match(home, /const INSTALL_TIMEOUT = 10 \* 60 \* 1000;/);
});

check("English and Filipino include matching keys/placeholders for new UI strings", () => {
  assert.deepEqual(Object.keys(en).sort(), Object.keys(fil).sort());
  for (const k of Object.keys(en)) {
    const a = (String(en[k]).match(/\{\w+\}/g) || []).sort();
    const b = (String(fil[k]).match(/\{\w+\}/g) || []).sort();
    assert.deepEqual(a, b, "placeholder mismatch for " + k);
  }
  for (const k of ["settings.savecopy", "settings.show_saved_zips", "install.queue_count", "install.retry_failed", "install.savedcopy_tag", "install.skipped_reason"]) {
    assert.ok(k in en && k in fil, "missing " + k);
  }
});
