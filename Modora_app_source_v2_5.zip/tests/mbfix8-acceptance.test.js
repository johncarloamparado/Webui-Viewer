const fs = require('fs'), path = require('path'), assert = require('assert');
const A = 'app/src/main/assets/';
const read = p => fs.readFileSync(path.join(A,p),'utf8');
const stats = read('js/stats-view.js'), css = read('css/stats.css'), shell = read('js/shell.js'), tools = read('js/profiles-view.js');
const en = JSON.parse(fs.readFileSync(path.join(A,'i18n/en.json'),'utf8'));
const fil = JSON.parse(fs.readFileSync(path.join(A,'i18n/fil.json'),'utf8'));
let pass=0;
function test(n, fn){ try{fn(); pass++; console.log('ok - '+n)}catch(e){console.error('FAIL - '+n+' :: '+e.message);process.exitCode=1;} }
test('stats collapsed default and persisted key',()=>{assert(stats.includes('CKEY = "md.stats.collapsed"'));assert(stats.includes('return v === "0" ? false : v === "1" ? true : cmem'));assert(stats.includes('saveCollapsed(collapsed)') && stats.includes('applyCollapsed()'));});
test('collapsed state blocks sampler',()=>{assert(stats.includes('!collapsed && !paused'));assert(stats.includes('row.hidden = collapsed'));});
test('pause state remains independent and persisted',()=>{assert(stats.includes('PKEY = "md.stats.paused"'));assert(stats.includes('savePaused(paused)'));});
test('toggle has accessible expanded state and 44px target',()=>{assert(stats.includes('setAttribute("aria-expanded"'));assert(css.includes('min-width: 44px'));assert(css.includes('min-height: 44px') || css.includes('.md-stats-head .md-btn { min-height: 44px;'));});
test('reduced motion is respected',()=>{assert(css.includes('prefers-reduced-motion: reduce'));});
test('select is not a text field and change/blur/resize/visibility clear guard',()=>{assert(!shell.includes('n === "select"'));for(const x of ['"change"','"blur"','"resize"','"visibilitychange"','onChange']) assert(shell.includes(x) || (x==='onChange' && shell.includes('MDRouter.onChange')));});
test('tools mounts only Diagnostics + Logs view',()=>{assert(/box\.textContent = "";[\s\S]*?if \(window\.MDDiagView\) window\.MDDiagView\.mount\(box\);/.test(tools));assert(!tools.includes('MDBackupView.mount'));assert(!tools.includes('MDProfilesReview.mount'));});
test('English and Filipino keys match and stats labels exist',()=>{assert.deepStrictEqual(Object.keys(en).sort(),Object.keys(fil).sort());assert(en['stats.expand'] && fil['stats.expand'] && en['stats.collapse'] && fil['stats.collapse']);});
console.log(`${pass} passed`);
