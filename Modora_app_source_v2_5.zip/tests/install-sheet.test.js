/* MINI 1B behaviour tests for the install sheet (home.html + css/install.css). Run: node tests/install-sheet.test.js
 * Needs Playwright + Chromium (PLAYWRIGHT_MODULE / CHROMIUM env vars override the defaults below). The page runs from file:// with a FAKE native
 * bridge (window.ksu) whose exec() runs the command with the real /bin/sh on a fake root in a temp dir (/sdcard, /storage/emulated/0 and
 * /data/adb are remapped there; a fake `ksud` on PATH stands in for the installer). Nothing here touches a real device. */
"use strict";
var fs = require("fs"), os = require("os"), path = require("path"), cp = require("child_process"), assert = require("assert");
var pw = require(process.env.PLAYWRIGHT_MODULE || "/opt/npm-tools/node_modules/playwright");
var CHROMIUM = process.env.CHROMIUM || "/opt/pw-browsers/chromium";
var ASSETS = path.resolve(__dirname, "../app/src/main/assets");
var PAGE = "file://" + ASSETS + "/home.html";

var TMP = fs.mkdtempSync(path.join(os.tmpdir(), "inst-ui-"));
var ROOT = path.join(TMP, "root"), BIN = path.join(TMP, "bin");
fs.mkdirSync(path.join(ROOT, "sdcard/Download"), { recursive: true });
fs.mkdirSync(BIN);
// MINI 1C: Scan zips now inspects archives, so the fixtures are REAL zips with a root module.prop (they are listed as modules).
function mkmod(file, name) {
  var src = fs.mkdtempSync(path.join(TMP, "src-"));
  fs.writeFileSync(path.join(src, "module.prop"), "id=" + name.replace(/\W/g, "") + "\nname=" + name + "\nversion=v1.0\nversionCode=1\n");
  cp.execFileSync("zip", ["-q", "-r", file, "."], { cwd: src });
}
for (var i = 1; i <= 25; i++) mkmod(path.join(ROOT, "sdcard/Download", "mod" + (i < 10 ? "0" : "") + i + ".zip"), "Mod " + i);
mkmod(path.join(ROOT, "sdcard/Download", "we ird 'name' <b>x.zip"), "<b>Weird</b>");
// fake installer: prints the argument it received; "slow" zips sleep so Cancel can be tested
fs.writeFileSync(path.join(BIN, "ksud"), "#!/bin/sh\necho \"ksud-fake: $1 $2 $3\"\ncase \"$3\" in *slow*) sleep 30;; esac\nexit 0\n", { mode: 493 });
mkmod(path.join(ROOT, "sdcard/Download", "slow.zip"), "Slow");

var cmdLog = [];
function remap(cmd) {
  return cmd.replace(/\/storage\/emulated\/0/g, ROOT + "/sdcard").replace(/(^|[^A-Za-z0-9_.\/-])\/sdcard/g, "$1" + ROOT + "/sdcard").replace(/(^|[^A-Za-z0-9_.\/-])\/data\/adb/g, "$1" + ROOT + "/adb").replace(/(^|[^A-Za-z0-9_.\/-])\/data\/local\/tmp/g, "$1" + ROOT + "/tmp");
}
function hostExec(cmd, timeout) {
  cmdLog.push(cmd);
  return new Promise(function (resolve) {
    var ch = cp.spawn("/bin/sh", ["-c", remap(cmd)], { env: { PATH: BIN + ":" + process.env.PATH }, detached: true, stdio: ["ignore", "pipe", "pipe"] });
    var out = "", err = "", done = false;
    ch.stdout.on("data", function (d) { out += d; }); ch.stderr.on("data", function (d) { err += d; });
    var t = timeout > 0 ? setTimeout(function () { try { process.kill(-ch.pid, "SIGKILL"); } catch (e) {} fin(-2); }, timeout) : null;
    function fin(code) { if (done) return; done = true; if (t) clearTimeout(t); resolve({ code: code, out: out.split(ROOT + "/sdcard").join("/sdcard"), err: err }); }
    ch.on("close", function (c) { fin(c == null ? -1 : c); });
    ch.on("error", function () { fin(-1); });
  });
}

var INIT = function () {
  window.__picks = [];
  window.ksu = {
    exec: function (cmd, opts, cb) {
      var o = {}; try { o = JSON.parse(opts || "{}"); } catch (e) {}
      window.__hostExec(cmd, o.timeout || 0).then(function (r) { setTimeout(function () { if (window[cb]) window[cb](r.code, r.out, r.err); }, 0); });
    },
    pickZip: function (cb) { window.__picks.push(cb); },
    toast: function () {}, appInfo: function () { return "{}"; }
  };
  try { localStorage.setItem("md.onboarded", "1"); } catch (e) {}
};

var queue = [], passed = 0, failed = 0;
function test(name, fn) { queue.push([name, fn]); }

async function openPage(browser, opts) {
  var ctx = await browser.newContext(Object.assign({ viewport: { width: 360, height: 640 }, hasTouch: false }, opts || {}));
  var page = await ctx.newPage();
  var errors = [];
  page.on("pageerror", function (e) { errors.push(String(e)); });
  await page.exposeFunction("__hostExec", hostExec);
  await page.addInitScript(INIT);
  await page.goto(PAGE);
  await page.waitForFunction("window.MDRouter && window.MDI18n && window.MD && MD.sh", null, { timeout: 8000 });
  await page.waitForTimeout(300);
  page.__errors = errors;
  return page;
}
async function openInstall(page) {
  await page.evaluate(function () {
    var b = document.querySelector('[data-qa="install"]');
    // the quick-action menu button is a plain button; opening through the real click path
    document.querySelector("#more").click(); b.click();
  });
  await page.waitForSelector("#install.on");
  await page.waitForFunction("document.querySelectorAll('#inst-list .row').length > 0");
}
function vis(page, sel) { return page.locator(sel).isVisible(); }

test("layout: no numbered Choose/Check/Install headings, no old .ist markup", async function (b) {
  var page = await openPage(b); await openInstall(page);
  var r = await page.evaluate(function () {
    var h = document.getElementById("install");
    return { ist: h.querySelectorAll(".ist,.ist-n").length, text: h.innerText };
  });
  assert.strictEqual(r.ist, 0); assert.ok(!r.text.split("\n").some(function (l) { return /^(Choose a zip|Check|Install|[123])$/.test(l.trim()) && l.trim() !== "Install"; }), r.text);
  var heads = await page.evaluate(function () { return [].slice.call(document.querySelectorAll("#install b,#install h1,#install h2,#install h3")).map(function (x) { return x.textContent.trim(); }); });
  assert.ok(heads.indexOf("Choose a zip") < 0 && heads.indexOf("Check") < 0 && heads.indexOf("1") < 0, JSON.stringify(heads));
  assert.deepStrictEqual(page.__errors, []);
});
test("layout: sheet <= 90% height, sticky footer + Install visible without scrolling (25+ zips, 640px and 360px tall)", async function (b) {
  for (var h of [640, 360]) {
    var page = await openPage(b, { viewport: { width: 360, height: h } }); await openInstall(page);
    var r = await page.evaluate(function () {
      var s = document.getElementById("inst-sheet").getBoundingClientRect(), f = document.querySelector(".ins-f").getBoundingClientRect(),
        run = document.getElementById("inst-run").getBoundingClientRect(), body = document.getElementById("inst-body");
      return { vh: innerHeight, sh: s.height, fb: f.bottom, run: [run.top, run.bottom, run.height], bodyScroll: body.scrollHeight > body.clientHeight };
    });
    assert.ok(r.sh <= r.vh * 0.9 + 1, "sheet " + r.sh + " vs " + r.vh);
    assert.ok(r.fb <= r.vh + 1 && r.run[0] >= 0 && r.run[1] <= r.vh, JSON.stringify(r));
    assert.ok(r.run[2] >= 44, "Install height " + r.run[2]);
    if (h === 360) assert.ok(r.bodyScroll, "body should scroll on a short screen");
    await page.context().close();
  }
});
test("source row: Browse/Scan/Paste visible, paste input hidden by default and toggled with aria-expanded", async function (b) {
  var page = await openPage(b); await openInstall(page);
  assert.ok(await vis(page, "#inst-scan") && await vis(page, "#inst-paste"));
  assert.ok(!(await vis(page, "#inst-path")));
  assert.strictEqual(await page.getAttribute("#inst-paste", "aria-expanded"), "false");
  await page.click("#inst-paste");
  assert.ok(await vis(page, "#inst-path")); assert.strictEqual(await page.getAttribute("#inst-paste", "aria-expanded"), "true");
  assert.strictEqual(await page.evaluate("document.activeElement.id"), "inst-path");
  await page.click("#inst-paste");
  assert.ok(!(await vis(page, "#inst-path")));
});
function qrows(page) { return page.evaluate(function () { return [].slice.call(document.querySelectorAll("#inst-queue-list .ins-q-row")).map(function (r) { return { name: r.querySelector("b").textContent, meta: r.querySelector("small").textContent, status: r.querySelector(".ins-q-status").textContent }; }); }); }
test("paste: Add path validates (invalid -> Skipped message, nothing queued; valid -> queued and Install enabled)", async function (b) {
  var page = await openPage(b); await openInstall(page);
  assert.ok(await page.isDisabled("#inst-run"));
  await page.click("#inst-paste");
  await page.fill("#inst-path", "/sdcard/Download/a.txt"); await page.click("#inst-add-path");
  assert.ok(/Skipped: .*\.zip/.test(await page.textContent("#inst-msg")), await page.textContent("#inst-msg")); assert.ok(await page.isDisabled("#inst-run"));
  await page.fill("#inst-path", "/sdcard/Download/../x.zip"); await page.click("#inst-add-path");
  assert.ok(/\.\./.test(await page.textContent("#inst-msg")) || /Skipped/.test(await page.textContent("#inst-msg")), await page.textContent("#inst-msg"));
  assert.strictEqual((await qrows(page)).length, 0);
  await page.fill("#inst-path", "/sdcard/Download/mod01.zip"); await page.click("#inst-add-path");
  await page.waitForFunction("document.querySelectorAll('#inst-queue-list .ins-q-row').length === 1", null, { timeout: 8000 });
  assert.strictEqual((await page.textContent("#inst-msg")).trim(), ""); assert.ok(!(await page.isDisabled("#inst-run")));
  assert.ok(/mod01\.zip$/.test((await qrows(page))[0].meta));
});
test("queue hidden when nothing selected; list stays expanded; row select queues it and enables Install", async function (b) {
  var page = await openPage(b); await openInstall(page);
  assert.ok(!(await vis(page, "#inst-queue")));
  assert.strictEqual(await page.getAttribute("#inst-found-t", "aria-expanded"), "true");
  assert.ok(/^Zips found \(27\)$/.test((await page.textContent("#inst-found-l")).trim()), await page.textContent("#inst-found-l"));
  await page.click('#inst-list [data-zip$="mod03.zip"]');
  assert.ok(await vis(page, "#inst-queue")); var r = await qrows(page); assert.strictEqual(r.length, 1); assert.ok(r[0].meta.endsWith("mod03.zip"), r[0].meta);
  assert.strictEqual(await page.getAttribute("#inst-found-t", "aria-expanded"), "true");   // multi-select: the list stays open
  assert.ok(!(await page.isDisabled("#inst-run")));
});
test("collapsible: native button, Enter and Space toggle, aria-controls/labelledby resolve", async function (b) {
  var page = await openPage(b); await openInstall(page);
  var r = await page.evaluate(function () {
    var t = document.getElementById("inst-found-t"), body = document.getElementById(t.getAttribute("aria-controls"));
    return { tag: t.tagName, type: t.type, ok: !!body, lab: body && body.getAttribute("aria-labelledby") === t.id };
  });
  assert.deepStrictEqual(r, { tag: "BUTTON", type: "button", ok: true, lab: true });
  await page.focus("#inst-found-t"); await page.keyboard.press("Enter");
  assert.strictEqual(await page.getAttribute("#inst-found-t", "aria-expanded"), "false");
  await page.keyboard.press("Space");
  assert.strictEqual(await page.getAttribute("#inst-found-t", "aria-expanded"), "true");
  var box = await page.locator("#inst-list").evaluate(function (n) { return getComputedStyle(n).overflowY; });
  assert.strictEqual(box, "auto");
});
test("Remove (queued row): one tap clears it, keeps scan results, source controls enabled, Install disabled again", async function (b) {
  var page = await openPage(b); await openInstall(page);
  var n0 = await page.locator("#inst-list .row").count();
  await page.click('#inst-list [data-zip$="mod03.zip"]');
  await page.click("#inst-queue-list .ins-q-remove");
  assert.ok(!(await vis(page, "#inst-queue"))); assert.ok(await page.isDisabled("#inst-run"));
  assert.strictEqual(await page.locator("#inst-list .row").count(), n0);
  assert.strictEqual(await page.getAttribute("#inst-found-t", "aria-expanded"), "true");
  assert.ok(!(await page.isDisabled("#inst-browse"))); assert.ok(!(await page.isDisabled("#inst-scan")));
});
test("Remove (picked zip): staged temp copy is deleted with rm -f of the exact temp path, scan list kept", async function (b) {
  fs.mkdirSync(path.join(ROOT, "tmp/modora_install"), { recursive: true }); fs.writeFileSync(path.join(ROOT, "tmp/modora_install/module.zip"), "PK-fake");
  var page = await openPage(b); await openInstall(page);
  var n0 = await page.locator("#inst-list .row").count();
  await page.click("#inst-browse"); await page.waitForFunction("window.__picks.length===1");
  await page.evaluate(function () { var cb = window.__picks[0]; window[cb](true, "/data/local/tmp/modora_install/module.zip", "Picked <i>One</i>.zip", 5 * 1048576, ""); });
  await page.waitForFunction("document.querySelectorAll('#inst-queue-list .ins-q-row').length === 1", null, { timeout: 8000 });
  var r = (await qrows(page))[0]; assert.strictEqual(r.name, "Picked <i>One</i>.zip"); assert.ok(/5\.0 MB/.test(r.meta), r.meta);
  assert.strictEqual(await page.locator("#inst-queue-list i").count(), 0);       // textContent, not HTML
  cmdLog.length = 0;
  await page.click("#inst-queue-list .ins-q-remove");
  await page.waitForFunction("document.querySelectorAll('#inst-queue-list .ins-q-row').length === 0");
  await page.waitForTimeout(300);
  assert.ok(cmdLog.some(function (c) { return /^rm -f '?\/data\/local\/tmp\/modora_queue\//.test(c); }), JSON.stringify(cmdLog));
  assert.strictEqual(await page.locator("#inst-list .row").count(), n0);
});
test("untrusted file names are rendered as text (no HTML injection) and rows are buttons", async function (b) {
  var page = await openPage(b); await openInstall(page);
  var r = await page.evaluate(function () {
    var rows = [].slice.call(document.querySelectorAll("#inst-list .row"));
    return { bold: document.querySelectorAll("#inst-list b b").length, tags: rows.every(function (x) { return x.tagName === "BUTTON"; }), weird: rows.some(function (x) { return x.dataset.zip.indexOf("<b>x") > 0 && x.textContent.indexOf("<b>x") > 0; }) };
  });
  assert.deepStrictEqual(r, { bold: 0, tags: true, weird: true });
});
test("install flow: running hides source row + lists and shows log + Cancel; finish keeps log, shows Done + Install another", async function (b) {
  var page = await openPage(b); await openInstall(page);
  await page.click('#inst-list [data-zip$="mod05.zip"]');
  await page.click("#inst-run");
  await page.waitForFunction("document.getElementById('inst-another') && !document.getElementById('inst-another').hidden", null, { timeout: 15000 });
  var r = await page.evaluate(function () {
    function v(id) { var e = document.getElementById(id); return !!(e && e.offsetParent !== null); }
    return { src: v("inst-src"), found: v("inst-found"), log: v("inst-log"), run: v("inst-run"), cancel: v("inst-cancel"), done: v("inst-done"), another: v("inst-another"), logText: document.getElementById("inst-log").textContent, msgLoc: !!document.querySelector(".ins-f #inst-msg") };
  });
  assert.deepStrictEqual([r.src, r.found, r.log, r.run, r.cancel, r.done, r.another], [false, false, true, false, false, true, true], JSON.stringify(r));
  assert.ok(/ksud-fake: module install .*mod05\.zip/.test(r.logText), r.logText); assert.ok(/Finished \(exit 0\)/.test(r.logText)); assert.ok(r.msgLoc);
  // Install another -> empty state, results kept
  var n0 = await page.locator("#inst-list .row").count();
  await page.click("#inst-another");
  var s = await page.evaluate(function () { function v(id) { var e = document.getElementById(id); return !!(e && e.offsetParent !== null); } return { src: v("inst-src"), found: v("inst-found"), log: v("inst-log"), sel: v("inst-sel"), run: v("inst-run"), runDis: document.getElementById("inst-run").disabled, done: v("inst-done"), focus: document.activeElement.id }; });
  assert.deepStrictEqual(s, { src: true, found: true, log: false, sel: false, run: true, runDis: true, done: false, focus: "inst-browse" }, JSON.stringify(s));
  assert.strictEqual(await page.locator("#inst-list .row").count(), n0);
  assert.deepStrictEqual(page.__errors, []);
});
test("Done closes the sheet; reopening gives the empty state", async function (b) {
  var page = await openPage(b); await openInstall(page);
  await page.click('#inst-list [data-zip$="mod06.zip"]'); await page.click("#inst-run");
  await page.waitForFunction("!document.getElementById('inst-done').hidden", null, { timeout: 15000 });
  await page.click("#inst-done");
  assert.ok(!(await page.evaluate("document.getElementById('install').classList.contains('on')")));
  await openInstall(page);
  assert.ok(!(await vis(page, "#inst-queue"))); assert.ok(!(await vis(page, "#inst-log"))); assert.ok(await vis(page, "#inst-src"));
});
test("Cancel install works while running (existing cancel path)", async function (b) {
  var page = await openPage(b); await openInstall(page);
  await page.click('#inst-list [data-zip$="slow.zip"]'); await page.click("#inst-run");
  await page.waitForSelector("#inst-cancel:not([hidden])"); await page.waitForTimeout(1200);
  await page.click("#inst-cancel");
  await page.waitForFunction("!document.getElementById('inst-done').hidden", null, { timeout: 20000 });
  var t = await page.textContent("#inst-log"); assert.ok(/Install cancelled/.test(t), t);
});
test("Back: MDRouter.onBack closes the install sheet first (even with sections open), then does not close anything else", async function (b) {
  var page = await openPage(b); await openInstall(page);
  assert.strictEqual(await page.getAttribute("#inst-found-t", "aria-expanded"), "true");
  var r = await page.evaluate(function () { var a = window.MD.onBack(); return { a: a, on: document.getElementById("install").classList.contains("on") }; });
  assert.deepStrictEqual(r, { a: true, on: false });
  await openInstall(page); await page.click("#inst-paste");
  await page.keyboard.press("Escape");
  assert.ok(!(await page.evaluate("document.getElementById('install').classList.contains('on')")));
});
test("focus: opening focuses the dialog, closing restores focus to the opener area; footer buttons are >= 44px", async function (b) {
  var page = await openPage(b); await openInstall(page);
  assert.strictEqual(await page.evaluate("document.activeElement.id"), "inst-sheet");
  var small = await page.evaluate(function () { return [].slice.call(document.querySelectorAll("#install button")).filter(function (x) { return x.offsetParent !== null && x.getBoundingClientRect().height < 43.5; }).map(function (x) { return x.id; }); });
  assert.deepStrictEqual(small, []);
});
test("reduced motion: chevron transition disabled", async function (b) {
  var page = await openPage(b, { reducedMotion: "reduce" }); await openInstall(page);
  var d = await page.evaluate("getComputedStyle(document.querySelector('#inst-found-t .md-icon')).transitionDuration");
  assert.ok(d.split(",").every(function (x) { return parseFloat(x) < 0.001; }), d);
});
test("themes: card/footer/sections have opaque token backgrounds in dark and light", async function (b) {
  var page = await openPage(b); await openInstall(page);
  await page.click('#inst-list [data-zip$="mod03.zip"]');
  async function snap() { return page.evaluate(function () { function bg(s) { return getComputedStyle(document.querySelector(s)).backgroundColor; } return [bg(".ins-card"), bg(".ins-f"), bg("#inst-sheet")]; }); }
  var dark = await snap();
  await page.evaluate(function () { document.documentElement.setAttribute("data-theme", "light"); });
  var light = await snap();
  [dark, light].forEach(function (t) { t.forEach(function (c) { assert.ok(!/rgba\(0, 0, 0, 0\)|transparent/.test(c), c); }); });
  assert.notStrictEqual(dark[2], light[2], "sheet background should change with the theme: " + dark[2]);
});
test("static: install.css has no hard-coded colours; home.html links it; no inline onclick in the install markup", async function () {
  var css = fs.readFileSync(ASSETS + "/css/install.css", "utf8"), html = fs.readFileSync(ASSETS + "/home.html", "utf8");
  assert.ok(!/#[0-9a-fA-F]{3,8}\b/.test(css.replace(/\/\*[\s\S]*?\*\//g, "")) && !/rgba?\(/.test(css.replace(/\/\*[\s\S]*?\*\//g, "")));
  assert.ok(html.indexOf('href="css/install.css"') > 0);
  var m = html.slice(html.indexOf("<!-- Install module"), html.indexOf("</div>\n</div>\n", html.indexOf('id="inst-log"')));
  assert.ok(!/onclick=/i.test(m));
  assert.ok(fs.readFileSync(ASSETS + "/css/install.css", "utf8").split("\n").length < 600);
});

(async function () {
  var browser = await pw.chromium.launch({ executablePath: CHROMIUM, args: ["--no-sandbox"] });
  for (var i = 0; i < queue.length; i++) {
    try { await queue[i][1](browser); passed++; console.log("ok   - " + queue[i][0]); }
    catch (e) { failed++; console.log("FAIL - " + queue[i][0] + "\n       " + String(e && e.stack || e).split("\n").slice(0, 5).join("\n       ")); }
  }
  await browser.close();
  cp.spawnSync("sh", ["-c", "rm -rf /data/local/tmp/modora_jobs"]);
  try { fs.rmSync(TMP, { recursive: true, force: true }); } catch (e) {}
  console.log("\n" + passed + " passed, " + failed + " failed");
  process.exit(failed ? 1 : 0);
})();
