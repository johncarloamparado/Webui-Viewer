/* Modora system bars sync (MB7.3). Classic script, standalone (needs neither core.js nor bridge.js, so every page can load it).
 * Tells the native side which colour to paint behind the status/navigation bars, so the bars match the page background.
 * Source of the colour: the CSS token --md-bg on <html> when it is a plain #RGB/#RRGGBB value, else the default app background.
 * Native picks light or dark bar icons by contrast. Without the native method (older build, desktop browser) nothing happens.
 * API: window.MDBars { sync(), color(), last() }.   Re-syncs on load, when the page becomes visible, and on MDTheme changes. */
(function () {
  "use strict";
  var DEFAULT = "#060b1c", sent = null;
  function color() {
    try {
      var v = (getComputedStyle(document.documentElement).getPropertyValue("--md-bg") || "").trim();
      if (/^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i.test(v)) return v.toLowerCase();
    } catch (e) {}
    return DEFAULT;
  }
  function sync() {
    var c = color();
    try {
      if (typeof window.ksu === "undefined" || typeof window.ksu.setBars !== "function") return false;
      if (c === sent) return true;               // unchanged: no native call
      if (window.ksu.setBars(c) === false) return false; // native rejected it (stays unsent so a later sync retries)
      sent = c; return true;
    } catch (e) { return false; }
  }
  window.MDBars = { sync: sync, color: color, last: function () { return sent; } };
  function start() {
    sync();
    document.addEventListener("visibilitychange", function () { if (!document.hidden) sync(); });
    window.addEventListener("pageshow", sync);
    try { if (window.MDTheme && MDTheme.onChange) MDTheme.onChange(function () { setTimeout(sync, 0); }); } catch (e) {}
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
