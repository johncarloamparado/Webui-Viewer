/* Modora saved-ZIP backup core (MBFIX.7 / MINI 2B). Classic script (<script defer>), no modules, NO DOM, no direct native-bridge access:
 * every command goes through an injected executor (default window.MD.sh), so Node tests drive it on a fake root filesystem.
 * Not wired into the sheet or settings UI (Mini 2C). Does NOT touch the per-zip install command, INSTALL_TIMEOUT, cancel or no-root handling.
 *
 * API  (window.MDSavedCopy; also module.exports under Node for tests)
 *   createSetting(options?) -> {get(), set(bool), reset(), persistent()}   key "md.install.savecopy", default ON (true), JSON "true"/"false"
 *       (same encoding as js/store.js, so 2C may define it there). localStorage with an in-memory fallback when storage is missing/throws.
 *       options: {storage (tests), key}. A stored value that is not exactly true/false reads back as the default (ON).
 *   createSaver(options?) -> saver     options: {exec(cmd,{timeout}) -> Promise<{code,out}> (default MD.sh), enabled() (default: setting.get()),
 *                                                now() -> Date (tests), setting}
 *     saver.prepare({path, name?}) -> Promise<record>   NEVER rejects. Run BEFORE the install command. record:
 *         {state:"off"|"skipped"|"saved"|"reused"|"warn", reason, target, created:bool, size, copyName, final:""}
 *           off      backup disabled: nothing created.
 *           skipped  reason "inbackup" (source is already in /sdcard/Modora/zips/) | "root" (source not under an allowed root) | "invalid"
 *           saved    a NEW copy was made and size-verified (created:true). Kept only if the install succeeds (finalize).
 *           reused   target already existed with the same byte count: used as is, never overwritten, never deleted (created:false).
 *           warn     the copy could not be made/verified (reason mkdir|probe|nosource|copy|verify|exists). Install must still proceed;
 *                    a half-written copy that Modora itself created is removed (exact path).
 *     saver.finalize(record, outcome) -> Promise<record>   outcome "installed" keeps a new copy (final:"kept"); anything else deletes ONLY the
 *         exact file this saver created for that record (final:"removed"; "failed" if the rm failed). Reused copies and sources are never deleted.
 *     saver.hooks() -> {beforeItem, afterItem} for installq.createEngine (copy before install, finalize after; no install command is touched).
 *     saver.stagePicked({path, id?}) -> Promise<{ok, path, reason}>   copy a native-picker file (fixed PICK_FILE) to a UNIQUE app-owned temp path under
 *         /data/local/tmp/modora_queue/ (never overwrites; size-verified) so the next pick cannot clobber it.
 *     saver.releaseTemp(path) -> Promise<bool>   delete one temp copy this saver staged (exact registered path only; rm -f, never -rf).
 *     saver.owned() -> {created:[...], temps:[...]}   registries of what this saver may delete.
 *   sanitizeName(name) -> string   keep [A-Za-z0-9._ -], every other character (per code point) -> "_", ".zip" preserved, max 100 chars.
 *   isInBackupDir(path), sourceRootOk(path), stamp(date) -> "yyyymmdd-hhmmss", plus constants DIR, TMP_DIR, PICK_FILE, SETTING_KEY, MAX_NAME.
 *
 * Safety: paths are validated (absolute, no control chars/newline/NUL, no ".." segment, allowed roots only) and EVERY path is single-quoted with
 * MD.shq (or the identical local copy). Delete is `rm -f <exact path>` and only for paths in this saver's own registry that are inside DIR or TMP_DIR.
 * Allowed source roots: /sdcard/, /storage/emulated/0/, the app-owned temp dir and the fixed picker file. Sources elsewhere (e.g. /data/adb) are
 * installed normally but not copied (state "skipped", reason "root").
 */
(function (root) {
  "use strict";
  var DIR = "/sdcard/Modora/zips", TMP_DIR = "/data/local/tmp/modora_queue", PICK_FILE = "/data/local/tmp/modora_install/module.zip";
  var SETTING_KEY = "md.install.savecopy", MAX_NAME = 100, EXT = ".zip";
  var COPY_TIMEOUT = 180000, QUICK_TIMEOUT = 20000;

  function shq(v) {
    var m = root.MD && typeof root.MD.shq === "function" ? root.MD.shq : null;
    if (m) return m(v);
    if (v === null || v === undefined) throw new TypeError("shq: null/undefined value");
    var s = String(v);
    if (s.indexOf("\u0000") !== -1) throw new TypeError("shq: NUL byte not allowed");
    return "'" + s.replace(/'/g, "'\\''") + "'";
  }

  /* ---------- names and paths ---------- */
  function baseName(p) { p = String(p == null ? "" : p); var i = p.lastIndexOf("/"); return i < 0 ? p : p.slice(i + 1); }
  function sanitizeName(name) {
    var s = baseName(name).replace(/\\/g, "/"); s = s.slice(s.lastIndexOf("/") + 1);
    var stem = /\.zip$/i.test(s) ? s.slice(0, -EXT.length) : s;
    stem = Array.from(stem).map(function (ch) { return /[A-Za-z0-9._ -]/.test(ch) ? ch : "_"; });
    stem = stem.slice(0, MAX_NAME - EXT.length).join("");
    if (!stem.replace(/[. ]/g, "")) stem = "module";                // nothing but dots/spaces/empty: a visible, non-hidden file name
    return stem + EXT;                                             // ".zip" always lower-case, always the end
  }
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function stamp(d) { return d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + "-" + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds()); }
  function pathOk(p) {            /* absolute, no control chars/NUL/newline, no ".." segment */
    return typeof p === "string" && p.charAt(0) === "/" && !/[\u0000-\u001f\u007f]/.test(p) && !/(^|\/)\.\.(\/|$)/.test(p);
  }
  function clean(p) { return String(p).replace(/\/{2,}/g, "/").replace(/\/\.(?=\/)/g, ""); }
  function inDir(p, dir) { return p.indexOf(dir + "/") === 0 && p.length > dir.length + 1; }
  function isInBackupDir(p) {
    if (!pathOk(p)) return false; p = clean(p);
    return inDir(p, DIR) || inDir(p, "/storage/emulated/0/Modora/zips") || p === DIR || p === "/storage/emulated/0/Modora/zips";
  }
  function sourceRootOk(p) {
    if (!pathOk(p)) return false; p = clean(p);
    return p.indexOf("/sdcard/") === 0 || p.indexOf("/storage/emulated/0/") === 0 || inDir(p, TMP_DIR) || p === PICK_FILE;
  }

  /* ---------- setting: md.install.savecopy, default ON ---------- */
  function createSetting(options) {
    options = options || {};
    var key = options.key || SETTING_KEY, mem, hasMem = false, persist = true;
    function store() { try { return options.storage || (root.localStorage || null); } catch (e) { return null; } }
    return {
      get: function () {
        if (hasMem) return mem;
        var s = store(), raw = null;
        if (s) { try { raw = s.getItem(key); } catch (e) { raw = null; } }
        return raw === "false" ? false : raw === "true" ? true : true;        // anything else (missing, corrupt) -> default ON
      },
      set: function (v) {
        if (v !== true && v !== false) return false;
        var s = store();
        if (s) { try { s.setItem(key, v ? "true" : "false"); hasMem = false; persist = true; return true; } catch (e) {} }
        mem = v; hasMem = true; persist = false; return true;                  // storage unavailable: remember for this session
      },
      reset: function () { hasMem = false; var s = store(); if (s) { try { s.removeItem(key); } catch (e) {} } },
      persistent: function () { return persist; }
    };
  }

  /* ---------- saver ---------- */
  function createSaver(options) {
    options = options || {};
    var setting = options.setting || createSetting(options);
    var created = {}, temps = {}, tmpSeq = 0, rnd = 0;
    function exec(cmd, o) {
      var f = options.exec || (root.MD && root.MD.sh);
      if (typeof f !== "function") return Promise.resolve({ code: -5, out: "" });
      try { return Promise.resolve(f(cmd, o || { timeout: QUICK_TIMEOUT })).then(function (r) { r = r || {}; return { code: typeof r.code === "number" ? r.code : -1, out: String(r.out == null ? "" : r.out) }; }, function () { return { code: -1, out: "" }; }); }
      catch (e) { return Promise.resolve({ code: -1, out: "" }); }
    }
    function enabled() { try { return typeof options.enabled === "function" ? !!options.enabled() : setting.get() !== false; } catch (e) { return true; } }
    function now() { try { return typeof options.now === "function" ? options.now() : new Date(); } catch (e) { return new Date(); } }
    function rec(state, reason, extra) {
      var r = { state: state, reason: reason || "", target: "", created: false, size: null, copyName: "", final: "" };
      if (extra) for (var k in extra) r[k] = extra[k];
      return r;
    }
    /* "src=<bytes|none> tgt=<bytes|none>" for two exact, single-quoted paths; wc -c < file so only a number comes back */
    function probe(src, tgt) {
      var cmd = "S=none; T=none; if [ -f " + shq(src) + " ]; then S=$(wc -c < " + shq(src) + " 2>/dev/null); fi; " +
        "if [ -e " + shq(tgt) + " ]; then T=$(wc -c < " + shq(tgt) + " 2>/dev/null); fi; echo \"MDSC1 src=$S tgt=$T\"";
      return exec(cmd).then(function (r) {
        var m = /MDSC1 src=(\S*) tgt=(\S*)/.exec(r.out || "");
        if (r.code !== 0 || !m) return null;
        function n(x) { return x === "none" ? "none" : /^\d+$/.test(x.trim()) ? parseInt(x, 10) : NaN; }
        var s = n(m[1]), t = n(m[2]);
        return (s !== s || t !== t) ? null : { src: s, tgt: t };
      });
    }
    function sizeOf(p) {
      return exec("wc -c < " + shq(p) + " 2>/dev/null").then(function (r) { var t = (r.out || "").trim(); return r.code === 0 && /^\d+$/.test(t) ? parseInt(t, 10) : null; });
    }
    function rmExact(p) { return exec("rm -f " + shq(p)).then(function (r) { return r.code === 0; }); }

    var saver = {
      setting: setting,
      prepare: function (item) {
        try { return prepare(item || {}); } catch (e) { return Promise.resolve(rec("warn", "copy")); }
      },
      finalize: function (record, outcome) {
        record = record || {};
        var out = {}; for (var k in record) out[k] = record[k];
        if (!record.created || record.state !== "saved") { out.final = record.state === "reused" ? "reused" : (record.final || ""); return Promise.resolve(out); }
        if (outcome === "installed") { out.final = "kept"; return Promise.resolve(out); }
        var t = record.target;
        if (!created[t] || !pathOk(t) || !inDir(clean(t), DIR) || !/\.zip$/.test(t)) { out.final = "failed"; return Promise.resolve(out); }   // only what THIS saver made
        return rmExact(t).then(function (ok) { if (ok) delete created[t]; out.final = ok ? "removed" : "failed"; return out; });
      },
      hooks: function () {
        return {
          beforeItem: function (item) {
            return saver.prepare({ path: item.path, name: item.name }).then(function (r) {
              var log = r.state === "warn" ? "Saved copy: warning (" + r.reason + "); installing anyway." : "";
              return { save: r, log: log };
            });
          },
          afterItem: function (item, outcome) {
            if (!item.save) return null;
            return saver.finalize(item.save, outcome).then(function (r) { return { save: r }; });
          }
        };
      },
      stagePicked: function (o) {
        o = o || {}; var src = o.path || PICK_FILE;
        if (!(src === PICK_FILE || inDir(clean(src), TMP_DIR)) || !pathOk(src)) return Promise.resolve({ ok: false, path: "", reason: "root" });
        var id = String(o.id || "").replace(/[^A-Za-z0-9]/g, "").slice(0, 12);
        function uniq() { return TMP_DIR + "/p" + now().getTime().toString(36) + "-" + (++tmpSeq).toString(36) + (++rnd).toString(36) + (id ? "-" + id : "") + EXT; }
        var dest = uniq();
        if (!inDir(dest, TMP_DIR) || !pathOk(dest)) return Promise.resolve({ ok: false, path: "", reason: "name" });
        return exec("mkdir -p " + shq(TMP_DIR) + " && if [ -e " + shq(dest) + " ]; then echo MDEXISTS; exit 9; fi; cp " + shq(src) + " " + shq(dest) + " 2>&1 && chmod 644 " + shq(dest), { timeout: COPY_TIMEOUT }).then(function (r) {
          if (r.code !== 0) { if (/MDEXISTS/.test(r.out)) return { ok: false, path: "", reason: "exists" }; return rmExact(dest).then(function () { return { ok: false, path: "", reason: "copy" }; }); }
          temps[dest] = true;           // registered as soon as the copy exists, so it can always be cleaned up
          return Promise.all([sizeOf(src), sizeOf(dest)]).then(function (z) {
            if (z[0] === null || z[0] !== z[1]) return rmExact(dest).then(function () { delete temps[dest]; return { ok: false, path: "", reason: "verify" }; });
            return { ok: true, path: dest, reason: "" };
          });
        });
      },
      releaseTemp: function (p) {
        if (typeof p !== "string" || !temps[p] || !pathOk(p) || !inDir(clean(p), TMP_DIR) || !/\.zip$/.test(p)) return Promise.resolve(false);
        return rmExact(p).then(function (ok) { if (ok) delete temps[p]; return ok; });
      },
      owned: function () { return { created: Object.keys(created), temps: Object.keys(temps) }; }
    };

    function prepare(item) {
      if (!enabled()) return Promise.resolve(rec("off", "off"));
      var src = typeof item.path === "string" ? item.path : "";
      if (!pathOk(src)) return Promise.resolve(rec("skipped", "invalid"));
      src = clean(src);
      if (isInBackupDir(src)) return Promise.resolve(rec("skipped", "inbackup"));      // never copy a copy
      if (!sourceRootOk(src)) return Promise.resolve(rec("skipped", "root"));
      var name = sanitizeName(item.name && typeof item.name === "string" ? item.name : baseName(src));
      var stem = name.slice(0, -EXT.length);
      var plain = DIR + "/" + name;
      var date = now(), ts = stamp(date), tries = 0;
      function cand(n) {                         // n=0 plain name; n=1 timestamp; n>=2 timestamp-N. Always <= MAX_NAME chars.
        if (n === 0) return plain;
        var suf = "_" + ts + (n > 1 ? "-" + n : "");
        return DIR + "/" + stem.slice(0, MAX_NAME - EXT.length - suf.length) + suf + EXT;
      }
      return exec("mkdir -p " + shq(DIR)).then(function (m) {
        if (m.code !== 0) return rec("warn", "mkdir");
        function step(n) {
          if (n > 6) return rec("warn", "exists");
          var target = cand(n);
          if (!pathOk(target) || !inDir(target, DIR)) return rec("warn", "exists");
          return probe(src, target).then(function (p) {
            if (!p) return rec("warn", "probe");
            if (p.src === "none") return rec("warn", "nosource");
            if (p.tgt !== "none" && p.tgt === p.src) return rec("reused", "", { target: target, size: p.src, copyName: baseName(target) });      // same size: reuse, never overwrite
            if (p.tgt !== "none") return step(n + 1);                                                                                                // same name, other size: next free name
            return exec("if [ -e " + shq(target) + " ]; then echo MDEXISTS; exit 9; fi; cp " + shq(src) + " " + shq(target) + " 2>&1", { timeout: COPY_TIMEOUT }).then(function (c) {
              if (c.code !== 0) {
                if (/MDEXISTS/.test(c.out)) return step(n + 1);            // appeared meanwhile: never overwrite, try the next name (nothing of ours to delete)
                return rmExact(target).then(function () { return rec("warn", "copy", { target: target }); });     // we created the (partial) target: remove exactly it
              }
              created[target] = true;
              return sizeOf(target).then(function (sz) {
                if (sz === null || sz !== p.src) return rmExact(target).then(function () { delete created[target]; return rec("warn", "verify", { target: target, size: sz }); });
                return rec("saved", "", { target: target, created: true, size: sz, copyName: baseName(target) });
              });
            });
          });
        }
        return step(0);
      });
    }
    return saver;
  }

  var api = { DIR: DIR, TMP_DIR: TMP_DIR, PICK_FILE: PICK_FILE, SETTING_KEY: SETTING_KEY, MAX_NAME: MAX_NAME,
    sanitizeName: sanitizeName, stamp: stamp, isInBackupDir: isInBackupDir, sourceRootOk: sourceRootOk, createSetting: createSetting, createSaver: createSaver };
  api.setting = createSetting();
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.MDSavedCopy = api;
})(typeof window !== "undefined" ? window : (typeof globalThis !== "undefined" ? globalThis : this));
