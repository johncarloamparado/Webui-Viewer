/* Modora English strings (MB1.5). GENERATED COPY of i18n/en.json (source of truth for translators).
 * Why a .js copy: fetch/XHR of a .json file is blocked from file:// pages, so strings are loaded as a script.
 * Keep both in sync: add every new key to en.json AND here (regenerate: see handoff "i18n workflow").
 * Registers into window.MD_STRINGS; load order relative to i18n.js does not matter.
 */
(window.MD_STRINGS = window.MD_STRINGS || {}).en = {
  "app.name": "Modora",
  "common.ok": "OK",
  "common.cancel": "Cancel",
  "common.close": "Close",
  "common.back": "Back",
  "common.retry": "Retry",
  "common.done": "Done",
  "common.copy": "Copy",
  "common.copied": "Copied",
  "common.search": "Search",
  "common.clear": "Clear",
  "common.undo": "Undo",
  "common.remove": "Remove",
  "common.enable": "Enable",
  "common.disable": "Disable",
  "state.loading": "Loading…",
  "state.empty": "Nothing here yet",
  "state.error": "Something went wrong",
  "state.cached": "Showing saved data",
  "state.unavailable": "Unavailable",
  "error.bridge": "Native bridge unavailable",
  "error.timeout": "Timed out",
  "error.failed": "Command failed (code {code})",
  "theme.dark": "Dark",
  "theme.light": "Light",
  "theme.system": "System",
  "lang.system": "System default",
  "lang.en": "English",
  "modules.count_one": "{n} module",
  "modules.count_other": "{n} modules"
};
