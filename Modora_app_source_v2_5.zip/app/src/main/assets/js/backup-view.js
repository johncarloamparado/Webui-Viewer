/* Modora backup + restore panel (MB5.3). Classic script. Mounted by js/profiles-view.js under the profile group: MDBackupView.mount(parentNode).
 * EXPORT: [Create backup] reads the current tuner configs (read-only) -> shows the JSON text + Copy / Share. Nothing is written anywhere.
 * RESTORE: paste text -> [Review restore...] validates it (strict, see js/backup.js) -> reads the device -> shows the same now -> new diff as profiles -> [Apply N changes].
 *   Writes happen ONLY through MDProfilesApply.apply (same text/commands as the tuner pages, stale-refusal, read-back). A rejected backup changes nothing.
 * The panel state lives at module level, so the Tools tab can rebuild (profile selection) without losing the pasted text or a running restore. All text via textContent.
 * Requires MDBackup, MDProfilesApply, MDProfilesReview (_ui), MDProfiles. Optional: MDI18n.
 */
(function () {
  "use strict";
  function t(k, fb, p) {
    try { if (window.MDI18n) { var s = window.MDI18n.t(k, p); if (s && s !== k) return s; } } catch (e) {}
    return fb.replace(/\{(\w+)\}/g, function (m, n) { return p && p[n] != null ? p[n] : m; });
  }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function btn(label, act, cls) { var b = el("button", "md-btn md-btn-sm" + (cls ? " " + cls : ""), label); b.type = "button"; b.setAttribute("data-bkp", act); return b; }
  function bridgeOk() { return !!(window.MD && window.MD.bridge && window.MD.bridge.available()); }
  function ui() { return window.MDProfilesReview && window.MDProfilesReview._ui; }
  function banner(tone, text, role) { var b = el("div", "md-banner md-banner-" + tone); b.setAttribute("role", role || "status"); var d = el("div", "md-banner-body"); d.appendChild(el("p", "md-banner-title", text)); b.appendChild(d); return b; }

  var ex = { state: "idle", res: null, err: "", note: "" };                                   /* export: idle | loading | ready | error */
  var rs = { state: "idle", draft: "", parsed: null, plan: null, result: null, err: null, note: "", selNote: "" };   /* restore: idle | loading | ready | applying | done | error */
  var host = null, focusNext = null;

  var REJ = {
    empty: ["bkp.rej_empty", "Paste a backup first."], toolarge: ["bkp.rej_toolarge", "That text is too large to be a Modora backup."],
    json: ["bkp.rej_json", "That is not valid backup text. Paste the whole backup, from the first { to the last }."], notobject: ["bkp.rej_notobject", "That is not a Modora backup."],
    notmodora: ["bkp.rej_notmodora", "That is not a Modora settings backup."], schema_missing: ["bkp.rej_schema_missing", "This backup has no version number."],
    schema_newer: ["bkp.rej_schema_newer", "This backup was made by a newer version of Modora (format {detail}). Update the app to restore it."],
    schema_unsupported: ["bkp.rej_schema_unsupported", "This backup format ({detail}) is not supported."], bad_section: ["bkp.rej_bad_section", "The {detail} part of this backup is damaged."],
    bad_value: ["bkp.rej_bad_value", "This backup contains an invalid value ({detail})."], bad_profile: ["bkp.rej_bad_profile", "The profile in this backup is invalid."],
    empty_backup: ["bkp.rej_empty_backup", "This backup contains no settings."], noschema: ["bkp.rej_noschema", "Restore could not load (required scripts failed)."]
  };
  function rejText(r) { var d = REJ[r.reason] || REJ.notmodora; return t(d[0], d[1], { detail: r.detail || "" }); }
  function secLabel(id) { var u = ui(); return u ? u.secName(id) : id; }
  function cEx(reason) {
    if (reason === "nobridge") return t("bkp.err_nobridge", "Open Modora inside the app to create a backup.");
    if (reason === "noroot") return t("bkp.err_noroot", "Could not reach root, so nothing was read.");
    if (reason === "nothing") return t("bkp.err_nothing", "Nothing to back up: no tuner module is installed and no profile is selected.");
    return t("bkp.err_generic", "Could not create the backup.");
  }

  /* ---------- export ---------- */
  function createBackup() {
    var B = window.MDBackup; if (!B || ex.state === "loading") return;
    ex = { state: "loading", res: null, err: "", note: "" }; focusNext = "ex"; draw();
    B.create().then(function (r) {
      if (ex.state !== "loading") return;
      if (r.ok) ex = { state: "ready", res: r, err: "", note: "" }; else ex = { state: "error", res: null, err: r.reason, note: "" };
      focusNext = "ex"; draw();
    });
  }
  function copyBackup() { var ok = window.MD && window.MD.bridge && window.MD.bridge.copy(ex.res.json); ex.note = ok ? t("bkp.copied", "Backup copied to the clipboard.") : t("bkp.copy_unavailable", "Copy is not available here. Select the text above and copy it by hand."); draw(); }
  function shareBackup() { var ok = window.MD && window.MD.bridge && window.MD.bridge.share(ex.res.json); ex.note = ok ? "" : t("bkp.share_unavailable", "Sharing is not available here. Select the text above and copy it by hand."); draw(); }
  function exportView(g) {
    g.appendChild(el("h3", "md-bkp-sub", t("bkp.e_title", "Create a backup")));
    if (ex.state === "idle" || ex.state === "error") {
      if (ex.state === "error") g.appendChild(banner("danger", cEx(ex.err), "alert"));
      var b = btn(t("bkp.create", "Create backup"), "create"); if (!bridgeOk()) b.disabled = true; g.appendChild(b);
      if (!bridgeOk()) g.appendChild(el("p", "md-prof-note", t("bkp.err_nobridge", "Open Modora inside the app to create a backup.")));
    } else if (ex.state === "loading") {
      var s = el("p", "md-prof-note", t("bkp.creating", "Reading your current settings…")); s.setAttribute("role", "status"); g.appendChild(s);
    } else {
      var r = ex.res, parts = r.included.map(secLabel); if (r.data.profile) parts.push(t("bkp.inc_profile", "Selected profile"));
      var h = el("p", "md-bkp-ok", t("bkp.ready", "Backup ready.") + " " + t("bkp.includes", "Includes: {list}", { list: parts.join(", ") })); h.setAttribute("role", "status"); h.tabIndex = -1; h.setAttribute("data-bkp-title", "ex"); g.appendChild(h);
      if (r.missing.length) g.appendChild(el("p", "md-prof-note", t("bkp.missing", "Not included (module not installed): {list}", { list: r.missing.map(secLabel).join(", ") })));
      if (r.skipped) g.appendChild(el("p", "md-prof-note", t("bkp.skipped", "{n} values in your current config were not valid and were left out.", { n: r.skipped })));
      var ta = el("textarea", "md-textarea md-bkp-text"); ta.readOnly = true; ta.value = r.json; ta.rows = 8; ta.spellcheck = false; ta.setAttribute("aria-label", t("bkp.text_label", "Backup text")); ta.setAttribute("data-bkp-ta", "out"); g.appendChild(ta);
      var bar = el("div", "md-diff-bar"); bar.appendChild(btn(t("bkp.copy", "Copy backup"), "copy", "md-btn-gradient")); bar.appendChild(btn(t("bkp.share", "Share…"), "share")); bar.appendChild(btn(t("common.close", "Close"), "exclose")); g.appendChild(bar);
      if (ex.note) { var n = el("p", "md-prof-note", ex.note); n.setAttribute("role", "status"); g.appendChild(n); }
    }
  }

  /* ---------- restore ---------- */
  function resetRestore(keepDraft) { rs = { state: "idle", draft: keepDraft ? rs.draft : "", parsed: null, plan: null, result: null, err: null, note: "", selNote: "" }; }
  function selChange() {                                    /* the one non-tuner part: remembering the profile selection (only when it exists in this version) */
    var P = window.MDProfiles, b = rs.parsed && rs.parsed.backup; if (!P || !b || !b.profile) return null;
    var p = P.get(b.profile); if (!p) return { unknown: b.profile };
    return { id: p.id, name: p.name, from: P.selected(), change: P.selected() !== p.id };
  }
  function startReview() {
    var B = window.MDBackup, A = window.MDProfilesApply, text = rs.draft;
    if (!B || !A || rs.state === "loading" || rs.state === "applying") return;
    var pr = B.parse(text);
    if (!pr.ok) { rs = { state: "error", draft: text, parsed: null, plan: null, result: null, err: { reason: pr.reason, detail: pr.detail }, note: "", selNote: "" }; focusNext = "title"; draw(); return; }
    rs = { state: "loading", draft: text, parsed: pr, plan: null, result: null, err: null, note: "", selNote: "" }; focusNext = "title"; draw();
    var prof = B.toProfile(pr.backup), go = (prof.rme50 || prof.anr) ? A.planCustom(prof) : Promise.resolve({ ok: true, profileId: "backup", name: "Backup", sections: [], changes: 0, reboot: false, sig: "[]" });
    go.then(function (pl) {
      if (rs.state !== "loading" || rs.parsed !== pr) return;
      if (pl.ok) rs.state = "ready"; else { rs.state = "error"; rs.err = { plan: pl.reason }; }
      rs.plan = pl; focusNext = "title"; draw();
    });
  }
  function totalChanges() { var s = selChange(); return rs.plan.changes + (s && s.change ? 1 : 0); }
  function finishSel(allOk) {                               /* remember the selection only when every tuner part was applied (or there was nothing to apply) */
    var s = selChange(), P = window.MDProfiles; if (!s || s.unknown || !s.change) return "";
    if (!allOk) return t("bkp.r_sel_kept", "The profile selection was not changed because not everything was applied.");
    var ok = P.select(s.id); return ok ? t("bkp.r_sel_set", "Selected profile set to {name}.", { name: s.name }) : "";
  }
  function doApply() {
    var A = window.MDProfilesApply;
    if (!A || rs.state !== "ready" || !rs.plan || !totalChanges()) return;
    var pl = rs.plan;
    if (!pl.changes) { rs.state = "done"; rs.result = { ok: true, sections: [], reboot: false }; rs.selNote = finishSel(true); focusNext = "title"; draw(); return; }
    rs.state = "applying"; rs.note = ""; focusNext = "title"; draw();
    A.apply(pl).then(function (r) {
      if (r.stale && r.plan && r.plan.ok) { rs.state = "ready"; rs.plan = r.plan; rs.note = t("papply.stale", "Your settings changed while you were reviewing. Check the updated changes below."); }
      else if (r.reason === "busy") { rs.state = "ready"; rs.note = t("papply.busy", "Another apply is still running."); }
      else if (r.sections) { rs.state = "done"; rs.result = r; rs.selNote = finishSel(!!r.ok); }
      else { rs.state = "error"; rs.err = { plan: r.reason || "error" }; }
      focusNext = "title"; draw();
    });
  }
  function cancelRestore() { if (rs.state === "loading" || rs.state === "applying") return; resetRestore(rs.state === "error"); focusNext = "ta"; draw(); }

  function restoreView(g) {
    g.appendChild(el("h3", "md-bkp-sub", t("bkp.r_title", "Restore from a backup")));
    if (rs.state === "idle" || rs.state === "error") {
      var lab = el("label", "md-label", t("bkp.r_label", "Paste a backup here")); lab.setAttribute("for", "bkp-in"); g.appendChild(lab);
      var ta = el("textarea", "md-textarea md-bkp-text"); ta.id = "bkp-in"; ta.rows = 6; ta.spellcheck = false; ta.value = rs.draft; ta.setAttribute("data-bkp-ta", "in"); ta.setAttribute("autocapitalize", "off"); ta.setAttribute("autocomplete", "off");
      if (rs.state === "error" && rs.err && rs.err.reason) { ta.classList.add("is-invalid"); ta.setAttribute("aria-invalid", "true"); }
      g.appendChild(ta);
      if (rs.state === "error") {
        var m = rs.err && rs.err.reason ? rejText(rs.err) + " " + t("bkp.nothing_changed", "Nothing was changed.") : ui() ? ui().errText(rs.err && rs.err.plan) : t("papply.err", "Could not read your current settings. Nothing was changed.");
        var bn = banner("danger", m, "alert"); bn.tabIndex = -1; bn.setAttribute("data-bkp-title", "1"); g.appendChild(bn);
      }
      g.appendChild(el("p", "md-prof-note", t("bkp.r_hint", "Nothing is changed until you review the changes and tap Apply.")));
      var bar = el("div", "md-diff-bar"), rv = btn(t("bkp.r_review", "Review restore…"), "review"); if (!bridgeOk() || !window.MDProfilesApply || !window.MDBackup) rv.disabled = true;
      bar.appendChild(rv); if (rs.draft) bar.appendChild(btn(t("common.clear", "Clear"), "rclear")); g.appendChild(bar);
      if (!bridgeOk()) g.appendChild(el("p", "md-prof-note", t("papply.nobridge", "Open Modora inside the app to review and apply profiles.")));
      return;
    }
    var card = el("section", "md-diff md-card"); card.setAttribute("aria-label", t("bkp.r_review_title", "Review restore"));
    var h = el("h4", "md-diff-title", t("bkp.r_review_title", "Review restore")); h.tabIndex = -1; h.setAttribute("data-bkp-title", "1"); card.appendChild(h);
    var b = rs.parsed && rs.parsed.backup;
    if (b) card.appendChild(el("p", "md-prof-note", b.created ? t("bkp.r_summary", "Backup from {when}", { when: b.created }) : t("bkp.r_summary_nodate", "Backup (no date)")));
    if (rs.parsed && rs.parsed.warnings.length) card.appendChild(el("p", "md-prof-note", t("bkp.r_warn_unknown", "{n} unknown entries in the backup were ignored.", { n: rs.parsed.warnings.length })));
    var bar2 = el("div", "md-diff-bar");
    if (rs.state === "loading" || rs.state === "applying") {
      var s0 = el("p", "md-prof-note", rs.state === "loading" ? t("papply.loading", "Reading your current settings…") : t("papply.applying", "Applying…")); s0.setAttribute("role", "status"); card.appendChild(s0);
    } else if (rs.state === "ready") {
      var u = ui(), pl = rs.plan, sc = selChange();
      if (rs.note) card.appendChild(banner("warn", rs.note));
      pl.sections.forEach(function (s) {
        card.appendChild(el("h5", "md-diff-sec", secLabel(s.id)));
        if (s.state === "module_missing") card.appendChild(el("p", "md-prof-note", t("papply.mod_missing", "The {section} module is not installed (apply.sh not found), so this part is skipped.", { section: secLabel(s.id) })));
        else if (u) card.appendChild(u.rowsView(s));
      });
      if (sc) {
        card.appendChild(el("h5", "md-diff-sec", t("bkp.r_profile", "Selected profile")));
        if (sc.unknown) card.appendChild(el("p", "md-prof-note", t("bkp.r_profile_unknown", "The profile \"{id}\" in this backup does not exist in this version, so the selection is not restored.", { id: sc.unknown })));
        else { var P = window.MDProfiles, fromP = sc.from && P.get(sc.from), li = el("div", "md-diff-row is-" + (sc.change ? "change" : "same")); li.appendChild(el("span", "md-diff-k", t("bkp.r_profile", "Selected profile")));
          var v = el("span", "md-diff-v"); if (sc.change) { v.appendChild(el("s", "", fromP ? fromP.name : t("prof.none", "No profile selected"))); v.appendChild(document.createTextNode(" → ")); v.appendChild(el("b", "", sc.name)); } else { v.appendChild(el("b", "", sc.name)); v.appendChild(el("em", "md-diff-tag", t("papply.same", "No change"))); }
          li.appendChild(v); card.appendChild(li); }
      }
      var n = totalChanges();
      if (!n) card.appendChild(el("p", "md-prof-note", t("bkp.r_nothing", "Nothing to change: your device already matches this backup, or the differing settings are skipped.")));
      else if (pl.reboot) card.appendChild(el("p", "md-prof-note", t("papply.reboot_note", "Settings tagged Reboot only take effect after you restart your device.")));
      var ap = btn(t("papply.apply", "Apply {n} changes", { n: n }), "apply", "md-btn-gradient"); ap.disabled = !n; bar2.appendChild(ap); bar2.appendChild(btn(t("common.cancel", "Cancel"), "cancel"));
    } else if (rs.state === "done") {
      var r = rs.result; card.appendChild(banner(r.ok ? "ok" : "warn", r.ok ? t("bkp.r_done_ok", "Backup restored.") : t("bkp.r_done_partial", "Not everything was restored. Details below.")));
      if (r.sections.length && ui()) { var ul = el("ul", "md-diff-res"); r.sections.forEach(function (x) { ul.appendChild(el("li", "is-" + x.state, ui().resText(x))); }); card.appendChild(ul); }
      if (rs.selNote) card.appendChild(el("p", "md-prof-note", rs.selNote));
      if (r.reboot) card.appendChild(el("p", "md-prof-note", t("papply.reboot_needed", "Restart your device for the Reboot-tagged settings to take effect.")));
      bar2.appendChild(btn(t("papply.done", "Done"), "cancel"));
    }
    if (bar2.childNodes.length) card.appendChild(bar2);
    g.appendChild(card);
  }

  function draw() {
    if (!host) return;
    var active = document.activeElement, keepFocus = active && active.getAttribute && active.getAttribute("data-bkp-ta") === "in" && host.contains(active);
    host.textContent = "";
    exportView(host); host.appendChild(el("hr", "md-bkp-sep")); restoreView(host);
    if (focusNext) {
      var f = focusNext === "ex" ? host.querySelector('[data-bkp-title="ex"]') || host.querySelector('[data-bkp="create"]') : focusNext === "ta" ? host.querySelector('[data-bkp-ta="in"]') : host.querySelector('[data-bkp-title="1"]');
      focusNext = null; if (f) try { f.focus(); } catch (e) {}
    } else if (keepFocus) { var ta = host.querySelector('[data-bkp-ta="in"]'); if (ta) try { ta.focus(); } catch (e) {} }
  }

  function mount(parent) {
    var g = el("section", "md-set-group md-bkp"); g.appendChild(el("h2", "", t("bkp.title", "Backup & restore")));
    g.appendChild(el("p", "md-prof-note", t("bkp.note", "Back up your tuner settings (60Hz & SF, ANR limiter) and your selected profile as text you can copy or share. Restoring shows exactly what would change before anything is written. Backups contain no passwords or personal data.")));
    host = el("div", "md-bkp-body");
    host.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-bkp]") : null; if (!b || b.disabled || !host.contains(b)) return;
      var a = b.getAttribute("data-bkp");
      if (a === "create") createBackup(); else if (a === "copy") copyBackup(); else if (a === "share") shareBackup();
      else if (a === "exclose") { ex = { state: "idle", res: null, err: "", note: "" }; focusNext = "ex"; draw(); }
      else if (a === "review") startReview(); else if (a === "apply") doApply(); else if (a === "cancel") cancelRestore();
      else if (a === "rclear") { rs.draft = ""; rs.state = "idle"; rs.err = null; focusNext = "ta"; draw(); }
    });
    host.addEventListener("input", function (e) { var ta = e.target; if (ta && ta.getAttribute && ta.getAttribute("data-bkp-ta") === "in") rs.draft = ta.value; });
    g.appendChild(host); parent.appendChild(g); draw(); return g;
  }
  window.MDBackupView = { mount: mount, state: function () { return { export: ex.state, restore: rs.state }; } };
})();
