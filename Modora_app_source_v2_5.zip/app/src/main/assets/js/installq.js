/* Modora install queue model + sequential install engine (MBFIX.7 / MINI 2A). Classic script (<script defer>), no modules, NO DOM,
 * no direct native-bridge access: every command runs through an injected runner, so Node tests drive it with a fake bridge.
 * Not wired into home.html's UI in 2A: the sheet still installs one selected zip via its own installZip(). Mini 2B/2C connect it.
 * No saved-copy logic lives here (Mini 2B).
 *
 * API  (window.MDInstallQ; also module.exports under Node for tests)
 *   createQueue(options?) -> queue                        options: {max (default 10, never above MAX_ITEMS), T(key, fallback, vars)}
 *     add({path, name?, size?, ver?, source?: "scan"|"browse"|"paste", picked?: bool}) -> {ok:true, item}
 *                                                      | {ok:false, reason, key, fb, msg}   reason: invalid|dup|full|pickbusy|locked
 *     toggle(meta) -> {ok, selected:bool, item?, ...}  scan-list tap: removes the path if queued, else adds it (same failures as add)
 *     remove(idOrPath) -> bool        clear() -> number removed        has(path) -> bool       get(idOrPath) -> item|null
 *     items() -> item[] (copies, in queue order)      size()        validList() -> items that may run now (status queued|notrun, path re-validated)
 *     counts() -> {total, queued, running, installed, failed, skipped, notrun}
 *     canPick() -> false while a picked item still owns the fixed PICK_FILE (Browse must not overwrite it)
 *     lock(bool) / locked      the engine locks the queue while a run is active (add/remove/clear then return locked)
 *     cleanupList() -> [{id, dir}]   app-owned picked copies that are safe to delete (items not queued/running); metadata only, nothing is deleted here
 *   createEngine(options) -> engine
 *     options: {queue, runJob(cmd, {timeout,maxOut,onOutput}) -> {promise, cancel()}   (default: window.MD.sh.job)
 *               exec(cmd) -> Promise<{code,out}>    fallback used only when runJob is missing (mirrors the sheet's shc())
 *               buildCmd(path) -> string            default: installCmd (byte-identical to home.html's installCmd)
 *               timeout (default INSTALL_TIMEOUT), maxOut (default 100000), T, log(text), onItem(item, phase), onEnd(summary),
 *               beforeItem(item) -> Promise<{save?, log?}|void>   MINI 2B hook, awaited BEFORE the item's install command (e.g. saved-copy cp).
 *                                   Its errors are swallowed (install proceeds); result.save is stored on the item, result.log is logged.
 *               afterItem(item, outcome)   awaited after the item's status is final: outcome installed|failed|notrun (e.g. delete a new copy).
 *                                   Never runs an install command; not called for items that never reached beforeItem.}
 *     run(opts?) -> Promise<summary>         opts.statuses (default ["queued","notrun"]), opts.ids (optional id filter); NEVER rejects; one run at a time; strictly sequential
 *     retryFailed() -> Promise<summary>      runs ONLY the items whose status is "failed"
 *     cancel() -> bool                       cancels the active item (job.cancel(), the existing semantics) and runs NO further command
 *     running -> bool
 *   Per run: each item logs a header  "[i/n] name"  then the path and the "Installing..." progress line, then its raw output and an outcome line.
 *   Item statuses: queued | running | installed | failed | skipped | notrun. A cancelled active item is "failed" (reason "cancelled": it may be
 *   partly installed); every later item becomes "notrun". "skipped" = never executed because its path no longer validates.
 *   onEnd(summary) fires EXACTLY ONCE per run, after the last item. summary.refresh is true when >=1 item installed in this run: that is the ONE place
 *   the UI may refresh the module list / show the reboot hint. Nothing per item triggers a refresh.
 *   summary: {ran:[id], installed, failed, skipped, notrun, cancelled:bool, refresh:bool, results:[{id,path,name,status,state,code,reason}], counts}
 *
 * Safety: this file never builds a command from a path except through buildCmd (single-quoting with MD.shq/shq). Paths are validated here
 * with the same rules as the sheet's zipProblem(): no control chars/NUL, no "..", must end in .zip, must be under /sdcard, /storage or /data.
 */
(function (root) {
  "use strict";
  var MAX_ITEMS = 10;
  var INSTALL_TIMEOUT = 10 * 60 * 1000;                      // same value as home.html; the sheet's constant is unchanged
  var PICK_DIR = "/data/local/tmp/modora_install", PICK_FILE = PICK_DIR + "/module.zip";   // same as MainActivity (fixed native path)
  var KEY = {
    dup: "install.q_dup", full: "install.q_full", pickbusy: "install.q_pickbusy", locked: "install.q_locked",
    installed: "install.q_out_installed", failed: "install.q_out_failed", skipped: "install.q_out_skipped", notrun: "install.q_out_notrun"
  };
  var FB = {
    dup: "That zip is already in the list.", full: "The list is full (max {max} zips).",
    pickbusy: "A picked file is already waiting. Install or remove it before picking another.", locked: "Wait for the install to finish first.",
    installed: "Installed", failed: "Failed", skipped: "Skipped", notrun: "Not run"
  };
  var VALID_FOR_RUN = { queued: 1, notrun: 1 };

  function defT(key, fb, vars) {
    var s = fb == null ? key : String(fb);
    if (vars) for (var k in vars) if (Object.prototype.hasOwnProperty.call(vars, k)) s = s.split("{" + k + "}").join(String(vars[k]));
    return s;
  }
  function shq(v) {
    if (v === null || v === undefined) throw new TypeError("shq: null/undefined value");
    var s = String(v);
    if (s.indexOf("\u0000") !== -1) throw new TypeError("shq: NUL byte not allowed");
    return "'" + s.replace(/'/g, "'\\''") + "'";
  }
  function quoter() { return (root.MD && typeof root.MD.shq === "function") ? root.MD.shq : shq; }

  /* The install command: fixed text + a single-quoted path. COPIED BYTE-FOR-BYTE from home.html installCmd() (tests compare the two). */
  function installCmd(path) {
    return 'ZIP=' + quoter()(path) + '; ' +
      'if command -v ksud >/dev/null 2>&1; then ksud module install "$ZIP" 2>&1; ' +
      'elif command -v magisk >/dev/null 2>&1; then magisk --install-module "$ZIP" 2>&1; ' +
      'elif [ -x /data/adb/ksud ]; then /data/adb/ksud module install "$ZIP" 2>&1; ' +
      'elif [ -x /data/adb/magisk/magisk ]; then /data/adb/magisk/magisk --install-module "$ZIP" 2>&1; ' +
      'else echo "No ksud/magisk found"; exit 1; fi';
  }

  /* Same checks and messages as home.html zipProblem(), applied BEFORE normalising. Returns null when acceptable, else {k, fb}. */
  function pathProblem(path) {
    path = (typeof path === "string" ? path : "").trim();
    if (!path) return { k: "install.v_blank", fb: "Choose a zip or enter its path first." };
    if (/[\u0000-\u001f\u007f]/.test(path)) return { k: "install.v_chars", fb: "The path has a line break or another control character." };
    if (/(^|\/)\.\.(\/|$)/.test(path)) return { k: "install.v_dots", fb: 'The path must not contain "..".' };
    if (!/\.zip$/i.test(path)) return { k: "install.v_ext", fb: "The file must end in .zip." };
    if (!(path.indexOf("/sdcard/") === 0 || path.indexOf("/storage/emulated/0/") === 0 ||
          path === PICK_FILE || path.indexOf("/data/local/tmp/modora_queue/") === 0)) {
      return { k: "install.v_root", fb: "Use /sdcard, /storage/emulated/0, or a Modora-picked ZIP path." };
    }
    return null;
  }
  /* Exact-match key for de-duplication: trim, collapse "//", drop "/./". Case is kept (Android paths are case-sensitive). Not a symlink resolver. */
  function normalizePath(path) {
    var p = String(path == null ? "" : path).trim();
    p = p.replace(/\/{2,}/g, "/");
    while (p.indexOf("/./") !== -1) p = p.replace("/./", "/");
    return p;
  }
  function baseName(path) { var i = path.lastIndexOf("/"); return i < 0 ? path : path.slice(i + 1); }

  function copyItem(it) { var o = {}, k; for (k in it) if (Object.prototype.hasOwnProperty.call(it, k)) o[k] = it[k]; if (it.cleanup) o.cleanup = { dir: it.cleanup.dir }; if (it.save) { o.save = {}; for (k in it.save) o.save[k] = it.save[k]; } return o; }

  function createQueue(options) {
    options = options || {};
    var T = typeof options.T === "function" ? options.T : defT;
    var max = Math.min(MAX_ITEMS, Math.max(1, Math.floor(Number(options.max)) || MAX_ITEMS));
    var list = [], seq = 0, isLocked = false;

    function fail(reason, key, fb, vars, extra) {
      var r = { ok: false, reason: reason, key: key, fb: defT(key, fb, vars) };
      r.msg = T(key, fb, vars);
      if (extra) for (var k in extra) r[k] = extra[k];
      return r;
    }
    function find(idOrPath) {
      var n = normalizePath(idOrPath), i;
      for (i = 0; i < list.length; i++) if (list[i].id === idOrPath || list[i].path === n) return i;
      return -1;
    }
    var q = {
      max: max,
      get locked() { return isLocked; },
      lock: function (v) { isLocked = !!v; },
      add: function (meta) {
        meta = meta || {};
        if (isLocked) return fail("locked", KEY.locked, FB.locked);
        var raw = typeof meta.path === "string" ? meta.path : "", pr = pathProblem(raw);
        if (pr) return fail("invalid", pr.k, pr.fb, null, { problem: pr });
        var path = normalizePath(raw);
        if (list.some(function (x) { return x.path === path; })) return fail("dup", KEY.dup, FB.dup);
        var picked = !!meta.picked || path === PICK_FILE;
        if (picked && !q.canPick()) return fail("pickbusy", KEY.pickbusy, FB.pickbusy);   // would double-own the fixed PICK_FILE
        if (list.length >= max) return fail("full", KEY.full, FB.full, { max: max });
        var src = meta.source === "scan" || meta.source === "browse" || meta.source === "paste" ? meta.source : (picked ? "browse" : "paste");
        var size = Number(meta.size);
        var item = {
          id: "q" + (++seq), path: path,
          name: typeof meta.name === "string" && meta.name ? meta.name : baseName(path),
          ver: typeof meta.ver === "string" ? meta.ver : "",
          size: isFinite(size) && size >= 0 ? size : null,
          source: src,
          owner: picked ? "app" : "user",                      // "app" = Modora made this copy (picker temp file); "user" = never touched by cleanup
          cleanup: picked ? { dir: PICK_DIR } : null,
          status: "queued", state: "", code: null, reason: "", save: null     // save: saved-copy record set by the 2B beforeItem hook
        };
        list.push(item);
        return { ok: true, item: copyItem(item) };
      },
      toggle: function (meta) {
        if (isLocked) return fail("locked", KEY.locked, FB.locked, null, { selected: false });
        var p = normalizePath(meta && meta.path), at = find(p);
        if (at >= 0) { list.splice(at, 1); return { ok: true, selected: false }; }
        var r = q.add(meta); r.selected = !!r.ok; return r;
      },
      remove: function (idOrPath) {
        if (isLocked) return false;
        var at = find(idOrPath); if (at < 0) return false;
        list.splice(at, 1); return true;
      },
      clear: function () { if (isLocked) return 0; var n = list.length; list = []; return n; },
      has: function (path) { var n = normalizePath(path); return list.some(function (x) { return x.path === n; }); },
      get: function (idOrPath) { var at = find(idOrPath); return at < 0 ? null : copyItem(list[at]); },
      items: function () { return list.map(copyItem); },
      size: function () { return list.length; },
      validList: function () { return list.filter(function (x) { return VALID_FOR_RUN[x.status] === 1 && !pathProblem(x.path); }).map(copyItem); },
      counts: function () {
        var c = { total: list.length, queued: 0, running: 0, installed: 0, failed: 0, skipped: 0, notrun: 0 };
        list.forEach(function (x) { if (c[x.status] !== undefined) c[x.status]++; });
        return c;
      },
      canPick: function () { return !list.some(function (x) { return x.cleanup && x.path === PICK_FILE; }); },
      cleanupList: function () {
        return list.filter(function (x) { return x.owner === "app" && x.cleanup && x.cleanup.dir === PICK_DIR && x.status !== "queued" && x.status !== "running" && x.status !== "notrun"; })
          .map(function (x) { return { id: x.id, dir: x.cleanup.dir }; });
      },
      _raw: function (idOrPath) { var at = find(idOrPath); return at < 0 ? null : list[at]; }     // engine-only: live item
    };
    return q;
  }

  function createEngine(options) {
    options = options || {};
    var q = options.queue || createQueue(options);
    var T = typeof options.T === "function" ? options.T : defT;
    var buildCmd = typeof options.buildCmd === "function" ? options.buildCmd : installCmd;
    var timeout = options.timeout > 0 ? options.timeout : INSTALL_TIMEOUT;
    var maxOut = options.maxOut > 0 ? options.maxOut : 100000;
    var logf = typeof options.log === "function" ? options.log : function () {};
    var active = null, cancelled = false, running = false;

    function say(s) { try { logf(s); } catch (e) {} }
    function note(item, phase) { if (typeof options.onItem === "function") { try { options.onItem(q.get(item.id), phase); } catch (e) {} } }
    function hook(name, it, outcome) {          /* optional async hook; NEVER rejects, never blocks the queue on an error */
      var f = options[name];
      if (typeof f !== "function") return Promise.resolve(null);
      try { return Promise.resolve(f(q.get(it.id), outcome)).then(function (v) { return v || null; }, function () { return null; }); }
      catch (e) { return Promise.resolve(null); }
    }
    function runner() {
      if (typeof options.runJob === "function") return options.runJob;
      var sh = root.MD && root.MD.sh;
      return sh && typeof sh.job === "function" ? sh.job : null;
    }
    function runOne(cmd) {          /* -> Promise<{state, code, out, err, truncated}>; NEVER rejects */
      var rj = runner();
      try {
        if (rj) {
          var job = rj(cmd, { timeout: timeout, maxOut: maxOut, onOutput: function (chunk) { if (chunk) say(chunk); } });
          active = job;
          return Promise.resolve(job.promise).then(function (j) { active = null; return { state: j.state, code: j.code, out: j.out || "", err: j.err || "", truncated: !!j.truncated, streamed: true }; },
            function (e) { active = null; return { state: "error", code: -1, out: "", err: String(e && e.message || e), streamed: false }; });
        }
        if (typeof options.exec === "function") {
          return Promise.resolve(options.exec(cmd)).then(function (o) { o = o || {}; var c = typeof o.code === "number" ? o.code : -1; return { state: c === 0 ? "done" : "failed", code: c, out: o.out || "", err: "", streamed: false }; },
            function (e) { return { state: "error", code: -1, out: "", err: String(e && e.message || e), streamed: false }; });
        }
      } catch (e) { active = null; return Promise.resolve({ state: "error", code: -1, out: "", err: String(e && e.message || e), streamed: false }); }
      return Promise.resolve({ state: "error", code: -5, out: "", err: "native bridge unavailable", streamed: false });
    }
    function outcomeLine(item, r) {
      if (r.state === "done") return T("install.exit_ok", "Finished (exit 0).");
      if (r.state === "cancelled") return T("install.cancelled", "Install cancelled. The module may be partly installed; refresh the list.");
      if (r.state === "timeout") return T("install.timeout", "Install stopped: it ran longer than {min} minutes.", { min: timeout / 60000 });
      if (r.state === "error") return T("install.state_error", "Could not run or monitor the install ({err}).", { err: r.err || r.code });
      return T("install.exit_bad", "Install command failed (exit {code}).", { code: r.code });
    }
    function summarize(ran) {
      var s = { ran: ran.slice(), installed: 0, failed: 0, skipped: 0, notrun: 0, cancelled: cancelled, refresh: false, results: [], counts: q.counts() };
      q.items().forEach(function (it) {
        s.results.push({ id: it.id, path: it.path, name: it.name, status: it.status, state: it.state, code: it.code, reason: it.reason, save: it.save || null });
        if (ran.indexOf(it.id) >= 0) { if (s[it.status] !== undefined) s[it.status]++; }
      });
      s.refresh = s.installed > 0;
      return s;
    }

    var engine = {
      get running() { return running; },
      queue: q,
      run: function (opts) {
        if (running) return Promise.resolve(null);
        running = true; cancelled = false; q.lock(true);
        var want = (opts && opts.statuses) || ["queued", "notrun"], ran = [];
        var ids = opts && opts.ids;
        var todo = q.items().filter(function (x) { return want.indexOf(x.status) >= 0 && (!ids || ids.indexOf(x.id) >= 0); });
        var i = 0, total = todo.length;
        function finish() {
          running = false; active = null; q.lock(false);
          var s = summarize(ran);
          if (typeof options.onEnd === "function") { try { options.onEnd(s); } catch (e) {} }   // the ONE end-of-queue action
          return s;
        }
        function next() {
          if (i >= todo.length) return finish();
          var it = q._raw(todo[i].id), n = i + 1; i++;
          if (!it) return next();
          ran.push(it.id);
          if (cancelled) { it.status = "notrun"; it.state = ""; it.reason = "cancelled"; note(it, "end"); return next(); }   // no command after a cancel
          var pr = pathProblem(it.path);
          if (pr) { it.status = "skipped"; it.reason = "invalid"; say("[" + n + "/" + total + "] " + it.name + "\n" + T("install.skipped_reason", "Skipped: {reason}", { reason: T(pr.k, pr.fb) }) + "\n"); note(it, "end"); return next(); }
          it.status = "running"; it.state = ""; it.code = null; it.reason = ""; note(it, "start");
          say("[" + n + "/" + total + "] " + it.name + "\n" + T("install.installing", "Installing…") + "\n" + it.path + "\n");
          return hook("beforeItem", it).then(function (h) {
            if (h && h.save) it.save = h.save;
            if (h && h.log) say(String(h.log) + (/\n$/.test(String(h.log)) ? "" : "\n"));
            if (cancelled) {                                   // cancelled while the hook ran (e.g. copying): the install command never starts
              it.status = "notrun"; it.state = ""; it.reason = "cancelled"; note(it, "end");
              return hook("afterItem", it, "notrun").then(next);
            }
            var cmd;
            try { cmd = buildCmd(it.path); } catch (e) { cmd = null; }
            var p = cmd ? runOne(cmd) : Promise.resolve({ state: "error", code: -4, out: "", err: "invalid command", streamed: false });
            return p.then(function (r) {
              if (!r.streamed && r.out) say(r.out + (/\n$/.test(r.out) ? "" : "\n"));
              else if (!r.streamed && r.state !== "error") say(T("install.nooutput", "(no output)") + "\n");
              if (r.truncated) say(T("install.truncated", "(earlier output was trimmed)") + "\n");
              say(outcomeLine(it, r) + "\n");
              it.state = r.state; it.code = typeof r.code === "number" ? r.code : null;
              if (r.state === "done") { it.status = "installed"; it.reason = ""; }
              else { it.status = "failed"; it.reason = r.state === "cancelled" ? "cancelled" : r.state === "timeout" ? "timeout" : r.state === "error" ? "error" : "exit"; }
              return hook("afterItem", it, it.status).then(function (a) { if (a && a.save) it.save = a.save; note(it, "end"); return next(); });
            });
          });
        }
        if (!todo.length) return Promise.resolve(finish());
        return next();
      },
      retryFailed: function () {
        if (running) return Promise.resolve(null);
        var ids = [];
        q.items().forEach(function (x) { if (x.status === "failed") { var it = q._raw(x.id); it.status = "queued"; it.state = ""; it.code = null; it.reason = ""; ids.push(x.id); } });
        return engine.run({ statuses: ["queued"], ids: ids });     // only the items that had failed; installed/skipped/other queued items are untouched
      },
      cancel: function () {
        if (!running || cancelled) return false;
        cancelled = true;
        if (active && typeof active.cancel === "function") { try { active.cancel(); } catch (e) {} }
        return true;
      },
      outcomeLabel: function (status) { return T(KEY[status] || "", FB[status] || status); }
    };
    return engine;
  }

  var api = { MAX_ITEMS: MAX_ITEMS, INSTALL_TIMEOUT: INSTALL_TIMEOUT, PICK_DIR: PICK_DIR, PICK_FILE: PICK_FILE, KEYS: KEY,
    installCmd: installCmd, pathProblem: pathProblem, normalizePath: normalizePath, createQueue: createQueue, createEngine: createEngine };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.MDInstallQ = api;
})(typeof window !== "undefined" ? window : (typeof globalThis !== "undefined" ? globalThis : this));
