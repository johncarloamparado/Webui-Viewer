/* Modora live stats strip + sparklines (MB6.2). Classic script. Mounts into <div id="stats-strip"> on the Deck view.
 * Sampling runs ONLY while: the Deck view is the current route, the page is visible, the user has not paused it, and the bridge exists.
 * One sample every 3 s (single-flight, never overlapping). After 3 failed samples in a row it stops and says why, with a Retry button.
 * Values come only from MDStats (real measurements). Unreadable values show "unavailable" - never a fake 0. All text via textContent;
 * SVG built with createElementNS. Requires MDStats (js/stats.js). Optional: MDI18n, MDRouter.
 */
(function () {
  "use strict";
  var NS = "http://www.w3.org/2000/svg", EVERY = 3000, MAXPTS = 30, MAXFAIL = 3;
  function t(k, fb, p) {
    try { if (window.MDI18n) { var s = window.MDI18n.t(k, p); if (s && s !== k) return s; } } catch (e) {}
    return fb.replace(/\{(\w+)\}/g, function (m, n) { return p && p[n] != null ? p[n] : m; });
  }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }

  var host = null, tiles = {}, note = null, pauseBtn = null, retryBtn = null;
  var hist = { cpu: [], mem: [], temp: [] }, prevCpu = null, last = null;
  var paused = false, running = false, inflight = false, timer = 0, seq = 0, fails = 0, failReason = "", stopped = false;

  function onDeck() {
    try { var c = window.MDRouter && window.MDRouter.current(); return !c || c.name === "deck"; } catch (e) { return true; }
  }
  function shouldRun() {
    return !!host && !paused && !stopped && onDeck() && document.visibilityState !== "hidden" && !!(window.MD && window.MD.bridge && window.MD.bridge.available());
  }

  /* ---------- drawing ---------- */
  function spark(svg, vals, fixed) {
    while (svg.firstChild) svg.removeChild(svg.firstChild);
    var pts = vals.filter(function (v) { return v !== null; });
    if (pts.length < 2) return false;
    var lo = 0, hi = 100;
    if (!fixed) { lo = Math.min.apply(null, pts); hi = Math.max.apply(null, pts); if (hi - lo < 5) { var mid = (hi + lo) / 2; lo = mid - 2.5; hi = mid + 2.5; } }
    var W = 100, H = 28, n = Math.max(vals.length, 2), seg = [], segs = [];   // the line spans the full width and fills in as samples arrive (oldest left, newest right)
    vals.forEach(function (v, i) {
      if (v === null) { if (seg.length) segs.push(seg); seg = []; return; }
      var x = i * (W / (n - 1)), y = H - 2 - ((v - lo) / (hi - lo)) * (H - 4);
      seg.push(x.toFixed(1) + "," + y.toFixed(1));
    });
    if (seg.length) segs.push(seg);
    segs.forEach(function (s) {
      if (s.length < 2) return;
      var p = document.createElementNS(NS, "polyline"); p.setAttribute("points", s.join(" ")); p.setAttribute("class", "md-spark-line"); svg.appendChild(p);
    });
    return true;
  }
  function fmtGb(kb) { return (kb / 1048576).toFixed(1); }

  function build() {
    host.textContent = "";
    host.setAttribute("role", "group"); host.setAttribute("aria-label", t("stats.title", "Live stats"));
    var head = el("div", "md-stats-head");
    head.appendChild(el("span", "md-stats-title", t("stats.title", "Live stats")));
    note = el("span", "md-stats-note", ""); head.appendChild(note);
    pauseBtn = el("button", "md-btn md-btn-sm", t("stats.pause", "Pause")); pauseBtn.type = "button"; pauseBtn.setAttribute("aria-pressed", "false");
    pauseBtn.addEventListener("click", function () { paused = !paused; if (!paused) { stopped = false; fails = 0; } update(); sync(); });
    head.appendChild(pauseBtn);
    host.appendChild(head);
    var row = el("div", "md-stats-row");
    [["cpu", t("stats.cpu", "CPU")], ["mem", t("stats.mem", "RAM")], ["temp", t("stats.batt", "Battery")]].forEach(function (d) {
      var box = el("div", "md-stat"), v = el("div", "md-stat-v", "—"), s = el("div", "md-stat-s", ""), svg = document.createElementNS(NS, "svg");
      svg.setAttribute("viewBox", "0 0 100 28"); svg.setAttribute("class", "md-spark"); svg.setAttribute("preserveAspectRatio", "none"); svg.setAttribute("aria-hidden", "true");
      box.appendChild(el("div", "md-stat-k", d[1])); box.appendChild(v); box.appendChild(s); box.appendChild(svg);
      row.appendChild(box); tiles[d[0]] = { box: box, v: v, s: s, svg: svg };
    });
    host.appendChild(row);
    retryBtn = el("button", "md-btn md-btn-sm md-stats-retry", t("common.retry", "Retry")); retryBtn.type = "button"; retryBtn.hidden = true;
    retryBtn.addEventListener("click", function () { stopped = false; fails = 0; paused = false; update(); sync(); });
    host.appendChild(retryBtn);
  }

  function setTile(k, value, sub, fixed, label) {
    var x = tiles[k]; if (!x) return;
    x.v.textContent = value; x.s.textContent = sub;
    x.box.classList.toggle("is-na", value === "—");
    var has = spark(x.svg, hist[k], fixed);
    x.box.setAttribute("role", "group");
    x.box.setAttribute("aria-label", label + ": " + (value === "—" ? t("stats.unavailable", "unavailable") : value) + (sub ? ", " + sub : ""));
    x.svg.style.visibility = has ? "visible" : "hidden";
  }

  function update() {
    if (!host || !tiles.cpu) return;
    pauseBtn.textContent = paused ? t("stats.resume", "Resume") : t("stats.pause", "Pause");
    pauseBtn.setAttribute("aria-pressed", paused ? "true" : "false");
    retryBtn.hidden = !stopped;
    var d = last, NA = t("stats.unavailable", "unavailable");
    if (stopped) {
      note.textContent = t("stats.stopped", "Stopped: {why}", { why: reasonText(failReason) });
    } else if (paused) note.textContent = t("stats.paused", "Paused");
    else if (!shouldRun() && !d) note.textContent = "";
    else note.textContent = t("stats.every", "every {n} s", { n: EVERY / 1000 });
    var cpu = d && d.cpu !== undefined ? d.cpuPct : null;
    host.classList.toggle("is-stale", !running);              // values shown while paused / on another tab are the LAST reading: dimmed
    if (!d) {
      var br = !!(window.MD && window.MD.bridge && window.MD.bridge.available());
      setTile("cpu", "—", br ? (running ? t("stats.measuring", "measuring…") : "") : NA, true, t("stats.cpu", "CPU"));
      setTile("mem", "—", br ? "" : NA, true, t("stats.mem", "RAM")); setTile("temp", "—", br ? "" : NA, false, t("stats.batt", "Battery")); return;
    }
    if (!d.raw.cpu) setTile("cpu", "—", NA, true, t("stats.cpu", "CPU"));
    else if (cpu === null) setTile("cpu", "—", t("stats.measuring", "measuring…"), true, t("stats.cpu", "CPU"));
    else setTile("cpu", Math.round(cpu) + "%", t("stats.cpu_sub", "all cores"), true, t("stats.cpu", "CPU"));
    var mp = window.MDStats.memPct(d.raw.mem);
    if (mp === null) setTile("mem", "—", NA, true, t("stats.mem", "RAM"));
    else setTile("mem", Math.round(mp) + "%", t("stats.mem_sub", "{used} of {total} GB used", { used: fmtGb(d.raw.mem.totalKb - d.raw.mem.availKb), total: fmtGb(d.raw.mem.totalKb) }), true, t("stats.mem", "RAM"));
    var b = d.raw.batt;
    if (!b) setTile("temp", "—", NA, false, t("stats.batt", "Battery"));
    else if (b.tempC === null) setTile("temp", "—", b.pct !== null ? t("stats.batt_pct_only", "temperature {na}, charge {p}%", { na: NA, p: b.pct }) : NA, false, t("stats.batt", "Battery"));
    else setTile("temp", b.tempC.toFixed(1) + " °C", b.pct !== null ? t("stats.batt_sub", "battery, charge {p}%", { p: b.pct }) : t("stats.batt_sub0", "battery temperature"), false, t("stats.batt", "Battery"));
  }

  function reasonText(r) {
    return { nobridge: t("stats.r_nobridge", "open this from the Modora app"), timeout: t("stats.r_timeout", "the read timed out"),
      incomplete: t("stats.r_incomplete", "the read was incomplete"), failed: t("stats.r_failed", "could not read (is root allowed for Modora?)") }[r] || t("stats.r_failed", "could not read (is root allowed for Modora?)");
  }

  /* ---------- sampler ---------- */
  function tick(mySeq) {
    if (mySeq !== seq || inflight) return;
    inflight = true;
    window.MDStats.sample().then(function (r) {
      inflight = false;
      if (mySeq !== seq) return;                               // stopped/restarted meanwhile: drop the result
      if (r.ok) {
        fails = 0;
        var c = window.MDStats.cpuPct(prevCpu, r.data.cpu);
        prevCpu = r.data.cpu;
        window.MDStats.push(hist.cpu, c, MAXPTS); window.MDStats.push(hist.mem, window.MDStats.memPct(r.data.mem), MAXPTS);
        window.MDStats.push(hist.temp, r.data.batt && r.data.batt.tempC !== null ? r.data.batt.tempC : null, MAXPTS);
        last = { raw: r.data, cpuPct: c, cpu: c };
      } else if (++fails >= MAXFAIL) {
        failReason = r.reason; stopped = true; running = false; clearTimeout(timer); seq++; prevCpu = null; update(); return;
      }
      update();
      timer = setTimeout(function () { tick(mySeq); }, EVERY);
    });
  }
  function start() {
    if (running) return;
    running = true; prevCpu = null; seq++;
    var s = seq; tick(s);
  }
  function stop() {
    if (!running && !timer) return;
    running = false; clearTimeout(timer); timer = 0; seq++; prevCpu = null;   // a later resume starts a fresh CPU delta (no stale gap)
    window.MDStats.push(hist.cpu, null, MAXPTS); window.MDStats.push(hist.mem, null, MAXPTS); window.MDStats.push(hist.temp, null, MAXPTS);
  }
  function sync() { if (shouldRun()) start(); else stop(); update(); }

  function init() {
    host = document.getElementById("stats-strip");
    if (!host || !window.MDStats) return;
    build(); update();
    document.addEventListener("visibilitychange", sync);
    if (window.MDRouter) window.MDRouter.onChange(sync);
    setTimeout(sync, 0);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();

  window.MDStatsView = { sync: sync, state: function () { return { running: running, paused: paused, stopped: stopped, fails: fails }; } };
})();
