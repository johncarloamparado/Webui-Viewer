/* Modora settings store (MB1.5). Classic script (<script defer>), no modules.
 * Typed key/value store over localStorage ("md." prefix) with validation, defaults, change events and an
 * in-memory fallback when storage is unavailable/throws. Keys must be define()d (typos fail loudly, not silently).
 * COMPAT: key "theme" is stored at localStorage "md.theme" as the RAW string dark|light|system, exactly as js/theme.js
 * reads/writes it. When window.MDTheme exists, get/set for "theme" go through MDTheme so the page updates live.
 * Predefined keys: theme (dark|light|system, default dark), lang (system | language code, default system).
 * API: MDStore.define(name,{def,validate,raw,hookGet,hookSet}) -> bool (false if already defined / bad name)
 *      .get(name) .set(name,value) -> bool accepted (valid)  .reset(name) .has(name) .keys() .all()
 *      .onChange(name, fn(newVal, oldVal)) -> unsubscribe   .persistent() -> false once any write fell back to memory
 * Non-raw values are JSON encoded. Invalid/unreadable stored values read back as the default.
 */
(function () {
  "use strict";
  var PREFIX = "md.", NAME_RE = /^[A-Za-z][A-Za-z0-9_.-]*$/;
  var defs = {}, mem = {}, subs = {}, persist = true;

  function has(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
  function ls() { try { return window.localStorage || null; } catch (e) { return null; } }
  function same(a, b) { return a === b || JSON.stringify(a) === JSON.stringify(b); }

  function readRaw(name) {
    if (has(mem, name)) return mem[name];                  // a failed write wins over an older stored value
    var s = ls(); if (!s) return null;
    try { return s.getItem(PREFIX + name); } catch (e) { return null; }
  }
  function writeRaw(name, raw) {                           // true when it reached localStorage
    var s = ls();
    if (s) { try { s.setItem(PREFIX + name, raw); delete mem[name]; return true; } catch (e) {} }
    mem[name] = raw; persist = false; return false;
  }
  function clearRaw(name) {
    delete mem[name];
    var s = ls(); if (s) { try { s.removeItem(PREFIX + name); } catch (e) {} }
  }

  function decode(d, raw) {
    if (raw === null || raw === undefined) return d.def;
    var v = raw;
    if (!d.raw) { try { v = JSON.parse(raw); } catch (e) { return d.def; } }
    return d.validate(v) ? v : d.def;
  }

  function define(name, d) {
    if (typeof name !== "string" || !NAME_RE.test(name) || has(defs, name) || !d) return false;
    defs[name] = {
      def: d.def, raw: !!d.raw,
      validate: typeof d.validate === "function" ? d.validate : function () { return true; },
      hookGet: typeof d.hookGet === "function" ? d.hookGet : null,
      hookSet: typeof d.hookSet === "function" ? d.hookSet : null
    };
    return true;
  }

  function get(name) {
    if (!has(defs, name)) return undefined;
    var d = defs[name];
    if (d.hookGet) { var h; try { h = d.hookGet(); } catch (e) { h = undefined; } if (h !== undefined && d.validate(h)) return h; }
    return decode(d, readRaw(name));
  }

  function notify(name, nv, ov) {
    var l = (subs[name] || []).slice();
    for (var i = 0; i < l.length; i++) { try { l[i](nv, ov); } catch (e) { /* listener errors must not break the store */ } }
  }

  function set(name, value) {
    if (!has(defs, name)) return false;
    var d = defs[name];
    if (!d.validate(value)) return false;
    var old = get(name), handled = false;
    if (d.hookSet) {
      var r; try { r = d.hookSet(value); } catch (e) { r = undefined; }
      if (r !== undefined) { handled = true; if (r === false) persist = false; }
    }
    if (!handled) writeRaw(name, d.raw ? String(value) : JSON.stringify(value));
    var nv = get(name);
    if (!same(nv, old)) notify(name, nv, old);
    return true;
  }

  function reset(name) {
    if (!has(defs, name)) return false;
    var old = get(name), d = defs[name];
    clearRaw(name);
    if (d.hookSet) { try { d.hookSet(d.def); } catch (e) {} }
    var nv = get(name);
    if (!same(nv, old)) notify(name, nv, old);
    return true;
  }

  function onChange(name, fn) {
    if (!has(defs, name) || typeof fn !== "function") return function () {};
    (subs[name] = subs[name] || []).push(fn);
    return function () { var l = subs[name] || [], i = l.indexOf(fn); if (i > -1) l.splice(i, 1); };
  }

  window.MDStore = {
    define: define, get: get, set: set, reset: reset, onChange: onChange,
    has: function (n) { return has(defs, n); },
    keys: function () { return Object.keys(defs); },
    all: function () { var o = {}; for (var k in defs) if (has(defs, k)) o[k] = get(k); return o; },
    persistent: function () { return persist; }
  };

  var THEMES = ["dark", "light", "system"];
  define("theme", {
    def: "dark", raw: true,
    validate: function (v) { return THEMES.indexOf(v) > -1; },
    hookGet: function () { return window.MDTheme ? window.MDTheme.get() : undefined; },
    hookSet: function (v) { return window.MDTheme ? window.MDTheme.set(v) : undefined; }
  });
  define("lang", {
    def: "system", raw: true,
    validate: function (v) { return v === "system" || (typeof v === "string" && /^[a-z]{2,3}(-[A-Za-z0-9]{2,8})*$/.test(v)); }
  });
})();
