/* Modora action page logic (MB3.1) - classic script. Loaded by action.html AFTER icons/i18n/subpage (all defer, in order).
 * Command logic is unchanged from v2.4/MB2.x: same validation, same ksu.exec command string, same callback contract,
 * same output text ("<out><err>" + "\n\nexit <code>"). Changes vs the legacy inline script:
 *  - the Run button now works (the old inline onclick="run()" could not see run() inside its IIFE, so only the auto-run worked);
 *  - ids made only of dots ("." / "..") are rejected (they would leave /data/adb/modules);
 *  - listeners instead of inline handlers; status/labels via i18n with identical English text.
 */
(function () {
  "use strict";
  var id = new URLSearchParams(location.search).get("id") || "";
  var o = document.getElementById("o");
  var st = document.getElementById("st");
  var btn = document.getElementById("btn");
  var backBtn = document.getElementById("back");
  var P = window.MDPage;

  function T(k, f, p) {
    if (P) return P.t(k, f, p);
    return String(f).replace(/\{(\w+)\}/g, function (m, n) { return p && p[n] != null ? p[n] : m; });
  }
  function setSt(key, fallback, tone, params) {
    st.textContent = T(key, fallback, params);
    if (P) P.tone(st, tone);
  }
  function validId() { return /^[A-Za-z0-9._-]+$/.test(id) && !/^\.+$/.test(id); }

  document.getElementById("id").textContent = id || T("action.none", "(none)");
  if (P) {
    backBtn.insertAdjacentHTML("afterbegin", P.icon("chevron-left"));
    btn.insertAdjacentHTML("afterbegin", P.icon("terminal"));
  }
  setSt("action.ready", "Ready", "info");
  o.textContent = T("action.hint", "Tap Run to execute action.sh");

  function run() {
    if (btn.disabled) return;
    if (typeof ksu === "undefined" || !validId()) {
      o.textContent = T("action.invalid", "Invalid module or no root bridge.");
      setSt("action.error", "Error", "danger");
      return;
    }
    btn.disabled = true;
    setSt("action.running", "Running…", "info");
    o.textContent = "Running action.sh …\n";
    var n = "cb" + Date.now();
    window[n] = function (c, out, err) {
      delete window[n];
      var text = ((out || "") + (err || "")).trim() || T("action.nooutput", "(finished with no output)");
      o.textContent = text + "\n\nexit " + c;
      if (c === 0) setSt("action.finished", "✓ Finished", "ok");
      else setSt("action.exit", "Exit code {code}", "danger", { code: c });
      btn.disabled = false;
    };
    ksu.exec("cd '/data/adb/modules/" + id + "' && sh ./action.sh 2>&1", "{}", n);
  }

  btn.addEventListener("click", run);
  backBtn.addEventListener("click", function () { if (P) P.back(); else history.back(); });
  if (id) run();
})();
