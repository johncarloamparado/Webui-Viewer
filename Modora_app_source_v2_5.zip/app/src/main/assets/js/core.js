/* Modora core helpers (MB1.4). Classic script (<script defer>), no modules.
 * Creates/extends window.MD (never replaces it: the native back hook MD.onBack lives there).
 * DOM helpers never use innerHTML and refuse inline handlers / javascript: URLs.
 * API: MD.$, MD.$$, MD.el(tag, props, ...children), MD.on(target, type, fn, opts) -> off,
 *      MD.esc(s), MD.debounce(fn, ms), MD.sleep(ms), MD.clamp(n, lo, hi), MD.json(str, fallback),
 *      MD.uid(prefix)
 * el props: class, id, text, dataset{}, attrs{}, aria{}, on{event: fn}, style (string), plus
 *      value/checked/disabled/hidden/title/type/placeholder/href/src as direct props.
 */
(function () {
  "use strict";
  var MD = (window.MD = window.MD || {});
  var seq = 0;

  MD.$ = function (sel, root) { return (root || document).querySelector(sel); };
  MD.$$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  MD.esc = function (s) {
    return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  };

  function badUrl(v) { return /^\s*(javascript|data|vbscript):/i.test(String(v)); }
  function setAttr(node, name, val) {
    if (/^on/i.test(name)) throw new Error("MD.el: inline handler attribute '" + name + "' not allowed; use props.on");
    if ((name === "href" || name === "src" || name === "xlink:href") && badUrl(val)) throw new Error("MD.el: unsafe URL in " + name);
    if (val === false || val == null) node.removeAttribute(name); else node.setAttribute(name, val === true ? "" : String(val));
  }
  function addChild(node, c) {
    if (c == null || c === false) return;
    if (Array.isArray(c)) { c.forEach(function (x) { addChild(node, x); }); return; }
    node.appendChild(c && c.nodeType ? c : document.createTextNode(String(c)));
  }

  MD.el = function (tag, props) {
    var node = document.createElement(tag), p = props || {}, k;
    for (k in p) {
      if (!Object.prototype.hasOwnProperty.call(p, k)) continue;
      var v = p[k];
      if (k === "class") node.className = v;
      else if (k === "text") node.textContent = v;
      else if (k === "html" || k === "innerHTML" || k === "outerHTML") throw new Error("MD.el: '" + k + "' is not supported (use text/children)");
      else if (k === "dataset") for (var d in v) node.dataset[d] = v[d];
      else if (k === "aria") for (var a in v) setAttr(node, "aria-" + a, v[a]);
      else if (k === "attrs") for (var n in v) setAttr(node, n, v[n]);
      else if (k === "on") for (var e in v) node.addEventListener(e, v[e]);
      else if (k === "style") node.setAttribute("style", String(v));
      else if (k === "value" || k === "checked" || k === "disabled" || k === "hidden") node[k] = v;
      else setAttr(node, k, v);
    }
    for (var i = 2; i < arguments.length; i++) addChild(node, arguments[i]);
    return node;
  };

  MD.on = function (target, type, fn, opts) {
    target.addEventListener(type, fn, opts);
    return function () { target.removeEventListener(type, fn, opts); };
  };

  MD.debounce = function (fn, ms) {
    var t = 0;
    function d() { var a = arguments, self = this; clearTimeout(t); t = setTimeout(function () { t = 0; fn.apply(self, a); }, ms); }
    d.cancel = function () { clearTimeout(t); t = 0; };
    return d;
  };
  MD.sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  MD.clamp = function (n, lo, hi) { n = Number(n); if (!isFinite(n)) return lo; return Math.min(hi, Math.max(lo, n)); };
  MD.json = function (s, fallback) { try { return JSON.parse(s); } catch (e) { return fallback; } };
  MD.uid = function (prefix) { return (prefix || "md") + "-" + Date.now().toString(36) + "-" + (++seq).toString(36); };
})();
