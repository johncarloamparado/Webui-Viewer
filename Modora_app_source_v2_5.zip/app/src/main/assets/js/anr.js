/* Modora ANR tuner page logic (MB3.3) - classic script, loaded at the end of anr.html.
 * Everything below is the legacy v2.4/MB2.x script moved out of the HTML UNCHANGED, except:
 *  - inline onclick handlers (generated and static) replaced by data-* attributes + the listeners at the bottom;
 *  - the internal constant `MD` (mode table) renamed MODES so it can never collide with window.MD (core.js/bridge.js/router.js);
 *  - the generated markup uses the new .md-* class names (same data, same order).
 * Commands, config keys, config text, defaults, presets, texts and status/log parsing are untouched
 * (verified against the original page with a fake bridge: identical ksu.exec call sequences and DOM text). */
const D='/data/adb/anr_dialog_limiter',CF=D+'/config.conf',MOD='/data/adb/modules/anr_dialog_limiter',LG='/data/local/tmp/anr_dialog_limiter.log';
let cfg={MODE:'limit',LIMIT:'3',WINDOW_MIN:'10',TIMEOUT_MULT:'2'},live={};
const MODES=[['show','Stock','always show'],['limit','Limit','show N times'],['hide','Hide','never show']];
const MX={show:'Android default. The popup appears every time an app freezes.',limit:'Recommended. Shows the popup up to your limit, then hides it until things calm down.',hide:'Never shows ANR or crash popups for any app.'};
const PRE=[{n:'🛡 Recommended',d:'Show 3×, then hide. 2× timeout',c:{MODE:'limit',LIMIT:'3',WINDOW_MIN:'10',TIMEOUT_MULT:'2'}},
{n:'🌿 Gentle',d:'Show 5×, stock timeout',c:{MODE:'limit',LIMIT:'5',WINDOW_MIN:'5',TIMEOUT_MULT:'1'}},
{n:'🤫 Silent',d:'Never show, 3× timeout',c:{MODE:'hide',LIMIT:'3',WINDOW_MIN:'10',TIMEOUT_MULT:'3'}},
{n:'↩️ Stock',d:'Android defaults',c:{MODE:'show',LIMIT:'3',WINDOW_MIN:'10',TIMEOUT_MULT:'1'}}];
const $=s=>document.querySelector(s),has=typeof ksu!=='undefined';
function sh(c){return new Promise(r=>{const n='cb'+Date.now()+Math.random().toString(36).slice(2);window[n]=(e,o,x)=>{delete window[n];r({out:o||'',err:x||''})};try{ksu.exec(c,'{}',n)}catch(e){delete window[n];r({out:'',err:String(e)})}})}
function toast(m){const t=$('#toast');t.textContent=m;t.style.opacity=1;setTimeout(()=>t.style.opacity=0,2000)}
function step(k,d,a,b){cfg[k]=String(Math.min(b,Math.max(a,+cfg[k]+d)));render()}
function preset(i){Object.assign(cfg,PRE[i].c);render();toast(PRE[i].n+' loaded. Press Save & apply')}
function render(){
$('#pre').innerHTML=PRE.map((p,i)=>`<button type="button" class="md-card md-card-interactive md-preset" data-preset="${i}"><b>${p.n}</b><span>${p.d}</span></button>`).join('');
$('#mode').innerHTML=MODES.map(m=>`<button type="button" class="md-hz${cfg.MODE==m[0]?' on':''}" data-mode="${m[0]}" aria-pressed="${cfg.MODE==m[0]}">${m[1]}<small>${m[2]}</small></button>`).join('');
$('#mx').textContent=MX[cfg.MODE];$('#lim').style.display=cfg.MODE=='limit'?'block':'none';
$('#vL').textContent=cfg.LIMIT;$('#vW').textContent=cfg.WINDOW_MIN;
const t=+cfg.TIMEOUT_MULT;
$('#tm').innerHTML=[1,2,3,4].map(n=>`<button type="button" class="md-hz${t==n?' on':''}" data-tm="${n}" aria-pressed="${t==n}">${n}×<small>${5*n} sec</small></button>`).join('');
$('#bars').innerHTML=[1,2,3,4].map(n=>`<span class="md-bar${n<=t?' on':''}"></span>`).join('');
$('#tx').textContent='A frozen app gets '+5*t+' seconds before Android declares an ANR (stock is 5). More time lets a short lag spike pass without any popup.'+(t>1?' This is the best fix for "lagged once, then worked again".':'');
const a=+live.mult||1;$('#tw').textContent=a!==t?'⚠ Active now: '+a+'×. Selected '+t+'× takes effect after a reboot.':'';}
function parse(o){const r={};o.split('\n').forEach(l=>{const i=l.indexOf('=');if(i>0)r[l.slice(0,i)]=l.slice(i+1).trim()});return r}
async function status(){const r=parse((await sh(`echo "hide=$(settings get global hide_error_dialogs)"; echo "mult=$(getprop ro.hw_timeout_multiplier)"; echo "w=$(pgrep -f 'anr_dialog_limiter/watcher[.]sh' | head -n1)"; echo "st=$(cat ${D}/state 2>/dev/null)"`)).out);
live=r;const c=(r.st||'0').split(' ')[0]||'0';
$('#s1').textContent=r.hide==='1'?'🔕 Hidden':'🔔 Allowed';$('#s2').textContent=cfg.MODE==='limit'?c+' / '+cfg.LIMIT:'—';
$('#s3').textContent=cfg.MODE!=='limit'?'Not needed':(r.w?'✅ Running':'⏸ Stopped');$('#s4').textContent=(+r.mult||1)+'× ('+5*(+r.mult||1)+'s)';render()}
async function logs(){const r=await sh(`tail -n 12 ${LG} 2>/dev/null`);$('#lg').textContent=r.out||'(no ANR events yet)'}
function refresh(){status();logs()}
async function resetNow(){if(!has)return;await sh(`echo "0 $(date +%s)" > ${D}/state; settings put global hide_error_dialogs 0`);toast('Counter reset');refresh()}
async function save(){if(!has)return toast('No root bridge');
const b=Object.entries(cfg).map(([k,v])=>k+'='+v).join('\n');
await sh(`mkdir -p ${D}; printf '%s\\n' '${b}' > ${CF}; sh ${MOD}/apply.sh`);toast('Saved & applied. Reboot if you changed the timeout');setTimeout(refresh,1200)}
async function load(){const r=parse((await sh(`cat ${CF} 2>/dev/null`)).out);for(const k in cfg)if(/^[a-z0-9]+$/.test(r[k]||''))cfg[k]=r[k];render();refresh()}
$('#pre').addEventListener('click',e=>{const b=e.target.closest('button[data-preset]');if(b)preset(+b.dataset.preset)});
$('#mode').addEventListener('click',e=>{const b=e.target.closest('button[data-mode]');if(b){cfg.MODE=b.dataset.mode;render()}});
$('#tm').addEventListener('click',e=>{const b=e.target.closest('button[data-tm]');if(b){cfg.TIMEOUT_MULT=b.dataset.tm;render()}});
document.querySelectorAll('button[data-step]').forEach(b=>b.addEventListener('click',()=>step(b.dataset.step,+b.dataset.d,+b.dataset.a,+b.dataset.b)));
$('#bReset').addEventListener('click',()=>resetNow());
$('#bRefresh').addEventListener('click',()=>refresh());
$('#bSave').addEventListener('click',()=>save());

render();if(!has)$('#warn').style.display='block';else load();
