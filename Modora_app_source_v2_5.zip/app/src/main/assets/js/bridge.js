/* Modora bridge helpers (MB1.4). Classic script (<script defer>), no modules. Independent of core.js.
 * Wraps the REAL native bridge (window.ksu, see MainActivity.Bridge). Verified native API used here:
 *   ksu.exec(cmd, optsJson, callbackName)  -> later calls  window[callbackName](code, stdout, stderr)
 *     opts: {cwd (must match [\w./@~+-]+, else native SILENTLY ignores it), timeout (ms; native kills su, code -2)}
 *     callbackName must match [A-Za-z_$][A-Za-z0-9_$.]*  ;  commands run as  su -c <cmd>
 *   ksu.toast/copy/share/vibrate(<=200ms)/appInfo/sysAccent/openExternal/fullScreen
 *   (ksu.spawn does NOT exist in the current bridge; polling jobs are used instead - see MB4.4.)
 *
 * API
 *   shq(v)                 POSIX single-quote a VALUE for use inside a command. Throws on null/undefined/NUL.
 *   sh(cmd, {cwd, timeout, watchdog}) -> Promise<{ok, code, out, err, timedOut}>   NEVER rejects.
 *       codes: native exit code; -1 native/bridge error; -2 timeout (native); -3 no callback within
 *       timeout+watchdog grace (JS); -4 invalid arguments; -5 bridge unavailable.
 *       cmd is shell code. Build it from fixed text and shq(value) for every dynamic value.
 *   sh.job(cmd, {cwd, timeout, interval, maxOut, onOutput(chunk, all), onState(state)})
 *       -> {id, state, promise, cancel()}; promise resolves (never rejects) with
 *       {id, state, ok, code, out, truncated, err}; state: running|done|failed|cancelled|timeout|error
 *       Runs cmd in the background under sh.jobDir/<id>/ and polls with short sh() calls.
 *   MD.bridge: available(), has(name), appInfo(), toast(m), copy(t)->bool, share(t)->bool,
 *       vibrate(ms)->bool, sysAccent()->"#RRGGBB"|"", openExternal(url)->bool (http/https only), fullScreen(bool)
 * Aliases window.sh / window.shq are created only if those names are free.
 */
(function () {
  "use strict";
  var MD = (window.MD = window.MD || {});
  var seq = 0;
  var CWD_RE = /^[\w.\/@~+-]+$/;               // identical to MainActivity's cwd check
  var DIR_RE = /^\/[A-Za-z0-9._\/@~+-]+$/;     // absolute, no quotes/spaces/$
  var NOOP = function () {};

  function nat() { try { return window.ksu || null; } catch (e) { return null; } }
  function has(name) { var k = nat(); return !!(k && typeof k[name] === "function"); }

  function shq(v) {
    if (v === null || v === undefined) throw new TypeError("shq: null/undefined value");
    var s = String(v);
    if (s.indexOf("\u0000") !== -1) throw new TypeError("shq: NUL byte not allowed");
    return "'" + s.replace(/'/g, "'\\''") + "'";
  }

  function result(code, out, err) {
    return { ok: code === 0, code: code, out: out == null ? "" : String(out), err: err == null ? "" : String(err), timedOut: code === -2 || code === -3 };
  }

  function sh(cmd, opts) {
    opts = opts || {};
    return new Promise(function (resolve) {
      var done = false, wd = 0, name = "";
      function fin(r) { if (done) return; done = true; clearTimeout(wd); resolve(r); }
      if (typeof cmd !== "string" || !cmd.trim() || cmd.indexOf("\u0000") !== -1) return fin(result(-4, "", "invalid command"));
      if (opts.cwd != null && (typeof opts.cwd !== "string" || !CWD_RE.test(opts.cwd))) return fin(result(-4, "", "invalid cwd"));
      var tmo = opts.timeout == null ? 0 : Number(opts.timeout);
      if (!isFinite(tmo) || tmo < 0) return fin(result(-4, "", "invalid timeout"));
      tmo = Math.floor(tmo);
      if (!has("exec")) return fin(result(-5, "", "native bridge unavailable"));

      name = "__mdcb" + (++seq) + "_" + Date.now().toString(36);
      window[name] = function (code, out, err) {
        try { delete window[name]; } catch (e) { window[name] = NOOP; }
        fin(result(typeof code === "number" ? code : -1, out, err));
      };
      var o = {};
      if (opts.cwd) o.cwd = opts.cwd;
      if (tmo > 0) o.timeout = tmo;
      try { nat().exec(cmd, JSON.stringify(o), name); }
      catch (e) { try { delete window[name]; } catch (e2) {} return fin(result(-1, "", String(e))); }

      if (tmo > 0) {
        var grace = opts.watchdog == null ? 3000 : Math.max(0, Number(opts.watchdog) || 0);
        wd = setTimeout(function () {
          window[name] = NOOP;   // a late native callback must not throw ReferenceError
          fin(result(-3, "", "no response from native bridge"));
        }, tmo + grace);
      }
    });
  }

  // ---------------- polling job runner ----------------
  sh.jobDir = "/data/local/tmp/modora_jobs";

  sh.job = function (cmd, o) {
    o = o || {};
    var id = Date.now().toString(36) + "-" + (++seq).toString(36);
    var job = { id: id, state: "running", promise: null, cancel: NOOP };
    var lines = 1, all = "", truncated = false, fails = 0, cancelReq = false, finished = false, timer = 0, totalTimer = 0;
    var maxOut = o.maxOut > 0 ? o.maxOut : 200000;
    var interval = Math.max(200, Number(o.interval) || 700);

    function emitState() { if (typeof o.onState === "function") { try { o.onState(job.state); } catch (e) {} } }

    job.promise = new Promise(function (resolve) {
      function end(state, code, err) {
        if (finished) return; finished = true;
        clearTimeout(timer); clearTimeout(totalTimer);
        job.state = state; emitState();
        resolve({ id: id, state: state, ok: state === "done", code: code, out: all, truncated: truncated, err: err || "" });
        if (dir) sh("rm -rf " + dir, { timeout: 8000 });   // best-effort cleanup; result ignored
      }
      var dir = "";
      if (typeof cmd !== "string" || !cmd.trim() || cmd.indexOf("\u0000") !== -1) return end("error", -4, "invalid command");
      if (o.cwd != null && (typeof o.cwd !== "string" || o.cwd.indexOf("\u0000") !== -1 || !o.cwd)) return end("error", -4, "invalid cwd");
      if (!DIR_RE.test(sh.jobDir) || sh.jobDir.indexOf("..") !== -1) return end("error", -4, "invalid job dir");
      if (!has("exec")) return end("error", -5, "native bridge unavailable");
      dir = sh.jobDir + "/" + id;

      var script = (o.cwd ? "cd " + shq(o.cwd) + " || exit 1\n" : "") + cmd + "\n";
      var start =
        "mkdir -p " + dir + " && printf '%s\\n' " + shq(script) + " > " + dir + "/cmd.sh && : > " + dir + "/out && " +
        "rm -f " + dir + "/rc " + dir + "/pid && " +
        "N=; command -v nohup >/dev/null 2>&1 && N=nohup; " +
        "( $N sh -c 'echo $$ > " + dir + "/pid; exec sh " + dir + "/cmd.sh' > " + dir + "/out 2>&1 < /dev/null; " +
        "echo $? > " + dir + "/rc ) > /dev/null 2>&1 &";

      function killCmd() {
        // capture children first, kill the parent (so the script cannot continue), then the children
        return "if [ -f " + dir + "/pid ]; then P=$(cat " + dir + "/pid); K=$(pgrep -P $P 2>/dev/null); " +
          "kill $P 2>/dev/null; [ -n \"$K\" ] && kill $K 2>/dev/null; fi; ";
      }
      function pollCmd() {
        return (cancelReq ? killCmd() : "") +
          "[ -d " + dir + " ] || { echo GONE; exit 0; }; " +
          "if [ -f " + dir + "/rc ]; then echo \"RC:$(cat " + dir + "/rc)\"; else echo RC:; fi; " +
          "tail -n +" + lines + " " + dir + "/out 2>/dev/null";
      }

      function append(text) {
        if (!text) return;
        all += text;
        if (all.length > maxOut) { all = all.slice(all.length - maxOut); truncated = true; }
        if (typeof o.onOutput === "function") { try { o.onOutput(text, all); } catch (e) {} }
      }

      function poll() {
        if (finished) return;
        sh(pollCmd(), { timeout: 8000 }).then(function (r) {
          if (finished) return;
          var nl = r.ok ? r.out.indexOf("\n") : -1;
          var head = nl < 0 ? "" : r.out.slice(0, nl);
          if (!r.ok || (head !== "GONE" && head.indexOf("RC:") !== 0)) {
            if (++fails >= 3) return end("error", r.code, r.err || "poll failed");
            timer = setTimeout(poll, interval); return;
          }
          fails = 0;
          if (head === "GONE") return end(cancelReq ? job.state : "error", -1, "job files disappeared");
          var rc = head.slice(3), chunk = r.out.slice(nl + 1);
          if (rc === "") {                                   // still running: only consume complete lines
            var last = chunk.lastIndexOf("\n");
            if (last >= 0) { var part = chunk.slice(0, last + 1); lines += part.split("\n").length - 1; append(part); }
            timer = setTimeout(poll, interval);
          } else {                                           // finished: rc is written after the process exited
            append(chunk);
            var code = parseInt(rc, 10); if (isNaN(code)) code = -1;
            end(job.state === "timeout" ? "timeout" : cancelReq ? "cancelled" : code === 0 ? "done" : "failed", code, "");
          }
        });
      }

      job.cancel = function (why) {
        if (finished || cancelReq) return;
        cancelReq = true;
        if (why === "timeout") job.state = "timeout";
        sh(killCmd() + "true", { timeout: 8000 });
        // if the process cannot be killed, stop waiting after a grace period
        setTimeout(function () { end(why === "timeout" ? "timeout" : "cancelled", -3, "stopped waiting; process may still run"); }, 5000);
      };
      if (o.timeout > 0) totalTimer = setTimeout(function () { job.cancel("timeout"); }, Number(o.timeout));

      emitState();
      sh(start, { timeout: 10000 }).then(function (r) {
        if (finished) return;
        if (!r.ok) return end("error", r.code, r.err || "could not start job");
        poll();
      });
    });
    return job;
  };

  // ---------------- safe wrappers for the other native methods ----------------
  var appInfoCache;
  MD.bridge = {
    available: function () { return has("exec"); },
    has: has,
    appInfo: function () {
      if (appInfoCache !== undefined) return appInfoCache;
      try { appInfoCache = has("appInfo") ? JSON.parse(nat().appInfo()) : null; } catch (e) { appInfoCache = null; }
      return appInfoCache;
    },
    toast: function (m) { try { if (has("toast")) nat().toast(String(m)); } catch (e) {} },
    copy: function (t) { try { if (has("copy")) { nat().copy(String(t)); return true; } } catch (e) {} return false; },
    share: function (t) { try { if (has("share")) { nat().share(String(t)); return true; } } catch (e) {} return false; },
    vibrate: function (ms) {
      ms = Math.round(Number(ms));
      if (!(ms > 0)) return false;
      try { if (has("vibrate")) { nat().vibrate(Math.min(200, ms)); return true; } } catch (e) {}
      return false;
    },
    sysAccent: function () {
      try { var a = has("sysAccent") ? String(nat().sysAccent() || "") : ""; return /^#[0-9A-Fa-f]{6}$/.test(a) ? a : ""; }
      catch (e) { return ""; }
    },
    openExternal: function (u) {
      u = String(u);
      if (!/^https?:\/\//i.test(u)) return false;
      try { if (has("openExternal")) { nat().openExternal(u); return true; } } catch (e) {}
      return false;
    },
    fullScreen: function (f) { try { if (has("fullScreen")) nat().fullScreen(!!f); } catch (e) {} }
  };

  MD.sh = sh; MD.shq = shq;
  if (typeof window.sh === "undefined") window.sh = sh;
  if (typeof window.shq === "undefined") window.shq = shq;
})();
