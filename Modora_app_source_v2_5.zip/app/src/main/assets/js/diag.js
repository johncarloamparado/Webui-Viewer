/* Modora diagnostics + log reader (MB5.4). Classic script, no modules. READ-ONLY: every command here is fixed text (the only dynamic parts are
 * integers picked from a whitelist); nothing is written, installed or changed on the device. Requires js/bridge.js (MD.sh). Optional: MD.bridge.
 *
 * ROOT HONESTY RULE: the app only ever says "Root access confirmed" when the root shell's own output is COMPLETE (start marker "@u<uid>" AND end marker "@@end")
 * and `id -u` printed 0, i.e. the same proof js/scan.js uses. Root-manager "evidence" (KernelSU / Magisk / APatch files or binaries) is only reported as
 * "found", never as proof of root and never as "your device is rooted". No fingerprint/serial/IMEI/accounts are collected.
 *
 * API
 *   MDDiag.collect() -> Promise<{status, reason?, code?, err?, uid?, data?}> NEVER rejects.
 *        status: "ok" (uid 0, complete) | "noroot" (complete but uid != 0; data holds device info only) | "error" (reason: timeout|bridge|nooutput|incomplete) | "nobridge"
 *        data: {device:{...}, selinux, kernel, managers:[{id, evidence[], version}], modulesDir, modules:[{id, on, removing}], modulesIgnored, tuners:{rme50, anr}}
 *   MDDiag.parse(out) -> {marker, complete, uid, data}      (pure; used by collect and tests)
 *   MDDiag.report(res, opts) -> string                        (plain text; English only on purpose: it is meant for support/bug reports)
 *   MDDiag.logs.SOURCES / LINES / run(srcId, n) -> Promise<{ok, state, text, lines, cut, code?, err?}>   state: ok|empty|failed|timeout|nobridge|invalid
 *   MDDiag.logs.filter(text, q) -> {text, lines}              (case-insensitive substring, client side only, never reaches a shell)
 *   MDDiag.clean(s, n)                                        (strip control chars, cap length)
 */
(function () {
  "use strict";
  var MD = (window.MD = window.MD || {});
  var ID_RE = /^[A-Za-z0-9._-]+$/, TIMEOUT = 20000, MAXMODS = 200, MAXCHARS = 100000;

  function clean(s, n) { return String(s == null ? "" : s).replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, n || 120); }

  var SCRIPT = [
    'echo "@u$(id -u)"',
    'echo "K|selinux|$(getenforce 2>/dev/null)"',
    'echo "K|kernel|$(uname -r 2>/dev/null)"',
    'for p in ro.product.manufacturer ro.product.model ro.product.device ro.build.version.release ro.build.version.sdk ro.build.version.security_patch ro.product.cpu.abi; do echo "K|$p|$(getprop $p 2>/dev/null)"; done',
    'if [ -d /data/adb/modules ]; then echo "K|modules_dir|1"; else echo "K|modules_dir|0"; fi',
    '[ -d /data/adb/ksu ] && echo "E|ksu|folder /data/adb/ksu"',
    'KS=$(command -v ksud 2>/dev/null); [ -z "$KS" ] && [ -x /data/adb/ksud ] && KS=/data/adb/ksud',
    'if [ -n "$KS" ]; then echo "E|ksu|program $KS"; echo "V|ksu|$("$KS" -V 2>/dev/null | head -n 1)"; fi',
    '[ -d /data/adb/magisk ] && echo "E|magisk|folder /data/adb/magisk"',
    'MG=$(command -v magisk 2>/dev/null)',
    'if [ -n "$MG" ]; then echo "E|magisk|program $MG"; echo "V|magisk|$("$MG" -v 2>/dev/null | head -n 1)"; fi',
    '[ -d /data/adb/ap ] && echo "E|apatch|folder /data/adb/ap"',
    'AP=$(command -v apd 2>/dev/null); [ -z "$AP" ] && [ -x /data/adb/apd ] && AP=/data/adb/apd',
    '[ -n "$AP" ] && echo "E|apatch|program $AP"',
    'for d in /data/adb/modules/*/; do',
    '  [ -d "$d" ] || continue',
    '  id=$(basename "$d"); e=1; r=0',
    '  [ -f "$d/disable" ] && e=0',
    '  [ -f "$d/remove" ] && r=1',
    '  echo "M|$id|$e|$r"',
    'done',
    'if [ -f /data/adb/modules/rme50_60hz_sf_fix/apply.sh ]; then echo "T|rme50|1"; else echo "T|rme50|0"; fi',
    'if [ -f /data/adb/modules/anr_dialog_limiter/apply.sh ]; then echo "T|anr|1"; else echo "T|anr|0"; fi',
    'echo "@@end"'
  ].join("\n");

  var DEV_KEYS = { "ro.product.manufacturer": "manufacturer", "ro.product.model": "model", "ro.product.device": "device", "ro.build.version.release": "android",
    "ro.build.version.sdk": "sdk", "ro.build.version.security_patch": "patch", "ro.product.cpu.abi": "abi" };
  var MGR_ORDER = ["ksu", "magisk", "apatch"];

  function parse(out) {
    var r = { marker: false, complete: false, uid: "", data: { device: {}, selinux: "", kernel: "", managers: [], modulesDir: null, modules: [], modulesIgnored: 0, tuners: { rme50: null, anr: null } } };
    var d = r.data, mg = {}, seen = {};
    String(out == null ? "" : out).split("\n").forEach(function (l) {
      if (l.indexOf("@u") === 0) { r.marker = true; r.uid = l.slice(2).trim(); return; }
      if (l.indexOf("@@end") === 0) { r.complete = true; return; }
      var f = l.split("|"), k = f[0];
      if (k === "K" && f.length >= 3) {
        var v = clean(f.slice(2).join("|"), 80);
        if (f[1] === "selinux") d.selinux = v; else if (f[1] === "kernel") d.kernel = v;
        else if (f[1] === "modules_dir") d.modulesDir = v === "1";
        else if (DEV_KEYS[f[1]]) d.device[DEV_KEYS[f[1]]] = v;
      } else if ((k === "E" || k === "V") && f.length >= 3 && MGR_ORDER.indexOf(f[1]) >= 0) {
        var m = mg[f[1]] || (mg[f[1]] = { id: f[1], evidence: [], version: "" });
        if (k === "E") { if (m.evidence.length < 4) m.evidence.push(clean(f.slice(2).join("|"), 100)); } else m.version = clean(f.slice(2).join("|"), 80);
      } else if (k === "M" && f.length >= 4) {
        if (!ID_RE.test(f[1]) || f[1].length > 120 || seen[f[1]]) { d.modulesIgnored++; return; }
        seen[f[1]] = 1; if (d.modules.length < MAXMODS) d.modules.push({ id: f[1], on: f[2] === "1", removing: f[3] === "1" }); else d.modulesIgnored++;
      } else if (k === "T" && f.length >= 3 && (f[1] === "rme50" || f[1] === "anr")) d.tuners[f[1]] = f[2] === "1";
    });
    MGR_ORDER.forEach(function (id) { if (mg[id]) d.managers.push(mg[id]); });
    return r;
  }

  function collect() {
    return new Promise(function (resolve) {
      var fail = function (status, reason, code, err) { resolve({ status: status, reason: reason, code: code, err: clean(err, 160) }); };
      if (!MD.sh || !MD.bridge || !MD.bridge.available()) return fail("nobridge", "nobridge", -5, "");
      MD.sh(SCRIPT, { timeout: TIMEOUT }).then(function (r) {
        if (r.code === -2 || r.code === -3) return fail("error", "timeout", r.code, r.err);
        if (r.code === -1 || r.code === -4 || r.code === -5) return fail("error", "bridge", r.code, r.err);
        var p = parse(r.out);
        if (!p.marker) return fail("error", "nooutput", r.code, r.err);
        if (!p.complete) return fail("error", "incomplete", r.code, r.err);
        if (p.uid !== "0") return resolve({ status: "noroot", uid: clean(p.uid, 12), code: r.code, data: { device: p.data.device, selinux: p.data.selinux, kernel: p.data.kernel, managers: [], modulesDir: null, modules: [], modulesIgnored: 0, tuners: { rme50: null, anr: null } } });
        resolve({ status: "ok", uid: "0", code: r.code, data: p.data });
      }, function () { fail("error", "bridge", -1, ""); });
    });
  }

  var MGR_NAME = { ksu: "KernelSU", magisk: "Magisk", apatch: "APatch" };
  var CAPS = ["exec", "copy", "share", "toast", "vibrate", "appInfo", "sysAccent", "openExternal", "pickZip", "rootShellInfo", "webrootCacheInfo", "setBars"];

  function report(res, opts) {
    opts = opts || {};
    var L = [], B = MD.bridge, info = null, d = res && res.data, yn = function (b) { return b == null ? "unknown" : b ? "yes" : "no"; };
    try { info = B && B.appInfo ? B.appInfo() : null; } catch (e) {}
    L.push("Modora diagnostics", "Created: " + (opts.created || new Date().toISOString()));
    L.push("App: " + (info && info.versionName ? "Modora " + clean(info.versionName, 20) + " (" + clean(info.versionCode, 10) + "), package " + clean(info.package, 60) : "unknown (not running inside the app)"));
    if (info && info.sdk != null) L.push("Android SDK (app): " + clean(info.sdk, 6) + ", locale " + clean(info.locale, 20));
    var wv = /Chrome\/[\d.]+/.exec(typeof navigator !== "undefined" ? navigator.userAgent || "" : ""); L.push("WebView: " + (wv ? wv[0] : "unknown"));
    L.push("Native bridge: " + CAPS.map(function (c) { return c + "=" + (B && B.has && B.has(c) ? "yes" : "no"); }).join(" "));
    L.push("");
    if (!res) { L.push("Device checks: not run"); return L.join("\n"); }
    if (res.status === "ok") L.push("Root shell: CONFIRMED (the shell reported uid 0 and its output was complete)");
    else if (res.status === "noroot") L.push("Root shell: NOT confirmed (the shell reported uid " + (res.uid || "?") + ", not 0). Root-only checks below were skipped.");
    else if (res.status === "nobridge") L.push("Root shell: NOT checked (native bridge unavailable)");
    else L.push("Root shell: NOT confirmed (" + res.reason + (res.code != null ? ", exit code " + res.code : "") + (res.err ? ", " + res.err : "") + ")");
    if (d) {
      var v = d.device || {};
      L.push("", "Device: " + [v.manufacturer, v.model, v.device && "(" + v.device + ")"].filter(Boolean).join(" ") + (v.abi ? ", " + v.abi : ""));
      L.push("Android: " + (v.android || "unknown") + (v.sdk ? " (SDK " + v.sdk + ")" : "") + (v.patch ? ", security patch " + v.patch : ""));
      L.push("Kernel: " + (d.kernel || "unknown"), "SELinux: " + (d.selinux || "unknown"));
      if (res.status === "ok") {
        L.push("", "Root manager files (file check only; this is not proof of root):");
        if (!d.managers.length) L.push("  none recognised");
        d.managers.forEach(function (m) { L.push("  " + MGR_NAME[m.id] + ": found - " + m.evidence.join("; ") + (m.version ? " - reports: " + m.version : "")); });
        var off = d.modules.filter(function (m) { return !m.on; }).length;
        L.push("", "Modules folder readable: " + yn(d.modulesDir), "Modules: " + d.modules.length + " (" + off + " disabled)" + (d.modulesIgnored ? ", " + d.modulesIgnored + " not listed" : ""));
        d.modules.forEach(function (m) { L.push("  " + m.id + (m.on ? "" : " [disabled]") + (m.removing ? " [pending removal]" : "")); });
        L.push("Tuner modules installed: 60Hz & SF=" + yn(d.tuners.rme50) + ", ANR limiter=" + yn(d.tuners.anr));
      }
    }
    return L.join("\n");
  }

  /* ---------------- logs ---------------- */
  var LINES = [100, 300, 1000];
  var WRAP = function (cmd) { return "O=$(" + cmd + " 2>&1); R=$?; if [ $R -ne 0 ]; then printf '%s\\n' \"$O\" | head -n 3 >&2; exit $R; fi; "; };
  var SOURCES = {
    system: { label: "System log (logcat)", cmd: function (n) { return WRAP("logcat -d -t " + n) + "printf '%s\\n' \"$O\""; } },
    modora: { label: "Modora entries only (logcat)", cmd: function (n) { return WRAP("logcat -d -t 3000") + "printf '%s\\n' \"$O\" | grep -F -e 'com.custom.tweaks' -e 'Modora' | tail -n " + n + "; true"; } },
    kernel: { label: "Kernel log (dmesg)", cmd: function (n) { return WRAP("dmesg") + "printf '%s\\n' \"$O\" | tail -n " + n; } }
  };
  function cleanLog(s) {
    s = String(s == null ? "" : s).replace(/\r/g, "").replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "");
    var cut = false; if (s.length > MAXCHARS) { s = s.slice(s.length - MAXCHARS); var i = s.indexOf("\n"); if (i >= 0) s = s.slice(i + 1); cut = true; }
    return { text: s.replace(/\n+$/, ""), cut: cut };
  }
  function lineCount(s) { return s ? s.split("\n").length : 0; }
  function runLogs(src, n) {
    return new Promise(function (resolve) {
      var bad = function (state) { resolve({ ok: false, state: state, text: "", lines: 0, cut: false }); };
      if (!Object.prototype.hasOwnProperty.call(SOURCES, src) || LINES.indexOf(n) < 0) return bad("invalid");
      if (!MD.sh || !MD.bridge || !MD.bridge.available()) return bad("nobridge");
      MD.sh(SOURCES[src].cmd(n), { timeout: TIMEOUT }).then(function (r) {
        if (r.code === -2 || r.code === -3) return resolve({ ok: false, state: "timeout", text: "", lines: 0, cut: false, code: r.code });
        if (!r.ok) return resolve({ ok: false, state: "failed", text: "", lines: 0, cut: false, code: r.code, err: clean(r.err, 160) });
        var c = cleanLog(r.out);
        resolve({ ok: true, state: c.text ? "ok" : "empty", text: c.text, lines: lineCount(c.text), cut: c.cut, code: r.code });
      }, function () { bad("failed"); });
    });
  }
  function filter(text, q) {
    q = String(q == null ? "" : q).trim().toLowerCase();
    if (!q) return { text: text, lines: lineCount(text) };
    var keep = String(text).split("\n").filter(function (l) { return l.toLowerCase().indexOf(q) >= 0; });
    return { text: keep.join("\n"), lines: keep.length };
  }

  window.MDDiag = { collect: collect, parse: parse, report: report, clean: clean, _script: SCRIPT,
    logs: { SOURCES: SOURCES, LINES: LINES, run: runLogs, filter: filter, MAXCHARS: MAXCHARS } };
})();
