/* Modora i18n (MB1.5). Classic script (<script defer>), no modules. English is the always-present fallback.
 * Strings live in window.MD_STRINGS[lang] (js/i18n.<lang>.js, generated from i18n/<lang>.json; fetch of JSON is
 * blocked on file:// so a script copy is used). "en" and "fil" (Filipino, MB8.2) exist.
 * Language pref ("system" or a registered code) is persisted through MDStore key "lang" when store.js is loaded; without
 * store.js (home/action pages today) it is kept in localStorage "md.lang" as the same RAW string MDStore would write (MB8.2).
 * Device language "tl" (old Android code for Tagalog) is treated as "fil".
 * API: MDI18n.t(key, params) -> string (plain text, never HTML). Fallback: current lang -> en -> the key itself.
 *        {name} placeholders from params; params.n selects key_one/key_other/... (Intl.PluralRules, else n==1).
 *      .apply(root) fills [data-i18n] (textContent) and [data-i18n-attr="title:key;aria-label:key"] (whitelisted attrs)
 *      .lang() resolved code, .pref(), .setLang(pref) -> bool, .available() -> codes, .onChange(fn(lang,pref)) -> off
 *      .missing() -> keys that fell back or were absent (QA aid), .register(lang, dict)
 */
(function () {
  "use strict";
  var ATTRS = ["title", "placeholder", "aria-label", "alt"];
  var RTL = ["ar", "he", "fa", "ur"];
  var strings = (window.MD_STRINGS = window.MD_STRINGS || {});
  var ALIAS = { tl: "fil" };
  var memPref = "system", memSet = false, knownN = 0, cur = "en", listeners = [], miss = [], missSet = {};

  function has(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
  function store() { return window.MDStore && window.MDStore.has("lang") ? window.MDStore : null; }
  function available() { return Object.keys(strings); }
  function canon(code) {                                   // case-insensitive match against registered codes
    code = String(code || "").toLowerCase();
    var a = available();
    for (var i = 0; i < a.length; i++) if (a[i].toLowerCase() === code) return a[i];
    return "";
  }
  function lsGet() { try { return window.localStorage ? window.localStorage.getItem("md.lang") : null; } catch (e) { return null; } }
  function lsSet(v) { try { window.localStorage.setItem("md.lang", v); return true; } catch (e) { return false; } }
  function pref() {
    var s = store(), p = s ? s.get("lang") : (memSet ? memPref : (lsGet() || "system"));
    return p === "system" || canon(p) ? p : "system";
  }

  function deviceTags() {
    var tags = [];
    try { var i = window.MD && window.MD.bridge && window.MD.bridge.appInfo(); if (i && i.locale) tags.push(i.locale); } catch (e) {}
    try {
      if (navigator.languages) for (var k = 0; k < navigator.languages.length; k++) tags.push(navigator.languages[k]);
      else if (navigator.language) tags.push(navigator.language);
    } catch (e) {}
    return tags;
  }
  function detect() {
    var tags = deviceTags();
    for (var i = 0; i < tags.length; i++) {
      var full = canon(tags[i]); if (full) return full;
      var b0 = String(tags[i]).split("-")[0].toLowerCase(), base = canon(has(ALIAS, b0) ? ALIAS[b0] : b0); if (base) return base;
    }
    return "en";
  }
  function resolve() { var p = pref(); return p === "system" ? detect() : canon(p) || "en"; }

  function note(key) {
    if (missSet[key] || miss.length >= 200) return;
    missSet[key] = 1; miss.push(key);
  }
  function plural(n, lang) {
    try { if (window.Intl && Intl.PluralRules) return new Intl.PluralRules(lang).select(n); } catch (e) {}
    return n === 1 ? "one" : "other";
  }
  function lookup(dict, key) { return dict && has(dict, key) && typeof dict[key] === "string" ? dict[key] : null; }

  // MB8.2: i18n.<lang>.js files assign window.MD_STRINGS.<lang> directly (no register() call), and they may load after this
  // file. Re-resolve the language whenever the set of registered languages has changed (cheap: 2-3 keys), so a saved or
  // device-detected "fil" takes effect as soon as its strings exist, even for views built before DOMContentLoaded.
  function sync() { var n = Object.keys(strings).length; if (n !== knownN) { knownN = n; refresh(false); } }

  function t(key, params) {
    sync();
    key = String(key); params = params || {};
    var chain = [strings[cur], strings.en], keys = [key];
    if (typeof params.n === "number" && isFinite(params.n)) keys = [key + "_" + plural(params.n, cur), key + "_other", key];
    var s = null, depth = -1;
    for (var d = 0; d < chain.length && s === null; d++)
      for (var k = 0; k < keys.length && s === null; k++) { s = lookup(chain[d], keys[k]); if (s !== null) depth = d; }
    if (s === null) { note(key); return key; }
    if (depth > 0 && cur !== "en") note(key);
    return s.replace(/\{(\w+)\}/g, function (m, name) {
      if (has(params, name) && params[name] != null) return String(params[name]);
      note("param:" + key + ":" + name); return m;
    });
  }

  function apply(root) {
    root = root || document;
    var i, els = root.querySelectorAll("[data-i18n]");
    for (i = 0; i < els.length; i++) els[i].textContent = t(els[i].getAttribute("data-i18n"));
    els = root.querySelectorAll("[data-i18n-attr]");
    for (i = 0; i < els.length; i++) {
      var pairs = els[i].getAttribute("data-i18n-attr").split(";");
      for (var j = 0; j < pairs.length; j++) {
        var c = pairs[j].indexOf(":"); if (c < 1) continue;
        var attr = pairs[j].slice(0, c).trim(), k = pairs[j].slice(c + 1).trim();
        if (ATTRS.indexOf(attr) > -1 && k) els[i].setAttribute(attr, t(k));
      }
    }
  }

  function refresh(fire) {
    var prev = cur; cur = resolve();
    try {
      var de = document.documentElement;
      de.setAttribute("lang", cur);
      de.setAttribute("dir", RTL.indexOf(cur.split("-")[0].toLowerCase()) > -1 ? "rtl" : "ltr");
    } catch (e) {}
    if (fire || prev !== cur) {
      apply(document);
      for (var i = 0; i < listeners.length; i++) { try { listeners[i](cur, pref()); } catch (e) {} }
    }
  }

  function setLang(p) {
    if (p !== "system" && !canon(p)) return false;
    p = p === "system" ? p : canon(p);
    var s = store();
    if (s) { if (!s.set("lang", p)) return false; } else { memPref = p; memSet = true; lsSet(p); }   // lsSet failing is fine: memPref still holds it for this page
    refresh(true);
    return true;
  }

  window.MDI18n = {
    t: t, apply: apply, setLang: setLang, available: available,
    lang: function () { sync(); return cur; },
    pref: pref,
    register: function (lang, dict) {
      if (typeof lang !== "string" || !/^[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8})*$/.test(lang) || !dict || typeof dict !== "object") return false;
      strings[lang] = dict; knownN = Object.keys(strings).length;
      refresh(false);
      if (canon(lang) === cur || lang.toLowerCase() === "en") apply(document);   // strings for what is on screen just arrived
      return true;
    },
    onChange: function (fn) {
      if (typeof fn !== "function") return function () {};
      listeners.push(fn);
      return function () { var i = listeners.indexOf(fn); if (i > -1) listeners.splice(i, 1); };
    },
    // Re-checked lazily: strings files may register after a key was first noted, so stale entries are dropped here.
    missing: function () {
      return miss.filter(function (k) {
        return k.indexOf("param:") === 0 || (lookup(strings[cur], k) === null && lookup(strings[cur], k + "_other") === null);
      });
    }
  };

  cur = resolve(); knownN = Object.keys(strings).length;
  // Deferred scripts run in document order, so en/other string files may arrive after this file: register() re-applies,
  // and DOMContentLoaded applies once more for pages whose strings are registered by later inline code.
  function boot() { refresh(true); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else { boot(); if (document.readyState !== "complete") document.addEventListener("DOMContentLoaded", function () { apply(document); }); }
})();
