/* Modora install-sheet ZIP list rendering (MBFIX.6 / MINI 1C). Classic script (<script defer>), no modules.
 * Pure DOM helpers for the "Zips found" and "Other zips" rows. File names and module names are untrusted: DOM APIs / textContent only, never innerHTML.
 * API (window.MDZipView):  moduleTitle(m, T) -> string        "Name vVersion" | "Name (version unknown)" | "Unnamed module" fallback
 *                          fill(box, items, kind, o)           o: {T, fmtSize, empty (text for an empty list), selected (path)}; kind "module" | "other"
 *                          mark(box, paths)                    marks one path or an array of queued paths
 * Rows are <button class="row" data-zip="PATH">; taps toggle paths in the install queue via home.html. */
(function (root) {
  "use strict";
  function moduleTitle(m, T) {
    var name = m && m.nameKnown !== false && m.name ? m.name : "", ver = m && m.ver ? String(m.ver).replace(/^[vV](?=\d)/, "") : "";
    if (!name) name = T("install.mod_noname", "Unnamed module");
    return ver ? T("install.mod_title", "{name} v{ver}", { name: name, ver: ver }) : T("install.mod_title_nover", "{name} (version unknown)", { name: name });
  }
  function base(p) { return String(p).slice(String(p).lastIndexOf("/") + 1); }
  function row(it, kind, o) {
    var b = document.createElement("button"), check = document.createElement("span"), mid = document.createElement("div"), t = document.createElement("b"), s = document.createElement("small");
    b.type = "button"; b.className = "row"; b.dataset.zip = it.path; b.setAttribute("aria-pressed", "false");
    check.className = "ins-check"; check.setAttribute("aria-hidden", "true"); check.textContent = "□";
    t.textContent = kind === "module" ? moduleTitle(it, o.T) : base(it.path);
    s.textContent = (kind === "module" ? base(it.path) : it.path) + " · " + o.fmtSize(it.size || 0);
    mid.className = "mid"; mid.appendChild(t); mid.appendChild(s);
    b.appendChild(check); b.appendChild(mid);
    var p = String(it.path || "");
    if (o.savedLabel && (/^\/sdcard\/Modora\/zips\//.test(p) || /^\/storage\/emulated\/0\/Modora\/zips\//.test(p))) {
      var tag = document.createElement("span"); tag.className = "ins-saved-tag"; tag.textContent = o.savedLabel; b.appendChild(tag);
    }
    return b;
  }
  function fill(box, items, kind, o) {
    box.textContent = "";
    if (!items.length) { var p = document.createElement("p"); p.className = "empty"; p.textContent = o.empty || ""; box.appendChild(p); return; }
    items.forEach(function (it) { box.appendChild(row(it, kind, o)); });
  }
  function mark(box, selected) {
    var rows = box.querySelectorAll("button.row"), i, multi = Array.isArray(selected);
    for (i = 0; i < rows.length; i++) {
      var on = multi ? selected.indexOf(rows[i].dataset.zip) !== -1 : !!selected && rows[i].dataset.zip === selected;
      if (on) rows[i].setAttribute("aria-current", "true"); else rows[i].removeAttribute("aria-current");
      rows[i].setAttribute("aria-pressed", on ? "true" : "false");
      var c = rows[i].querySelector(".ins-check"); if (c) c.textContent = on ? "☑" : "□";
    }
  }
  root.MDZipView = { moduleTitle: moduleTitle, fill: fill, mark: mark };
})(window);
