/* Modora system accent (MB6.3b). Classic script (<script defer>), no modules. Reads the Android system accent through MD.bridge.sysAccent()
 * (ksu.sysAccent: Android 12+ system_accent1_500, "" when unsupported) and applies it to the --md-accent* tokens with GUARANTEED readability:
 *   fill     (--md-accent)       adjusted until >= 3:1 against the page background (UI component contrast)
 *   text     (--md-accent-text)  adjusted until >= 4.5:1 against the surface colour
 *   on-accent ink                chosen between dark ink and white (the better worst-case over both gradient ends)
 *   accent-2 (gradient end)      a lighter (dark theme) / darker (light theme) variant of the fill
 * Nothing is applied when the preference is "default", when sysAccent() is missing/invalid, or when the page has no colour tokens: the CSS defaults stay (safe fallback).
 * Preference: localStorage "md.accent" = "system" | "default" (default "system"), memory fallback if storage throws.
 * Colours are applied as inline custom properties on <html> (removed again for "default"); legacy home.html vars --ac/--ac2 follow too.
 * API: MDAccent.status() -> {pref, available, sys, active, applied:{accent,accent2,text,soft,onAccent}|null}
 *      MDAccent.setPref("system"|"default") -> bool    MDAccent.apply() -> bool (true = custom colours are applied)
 *      MDAccent.compute(hex, theme, bgHex, surfaceHex) -> {accent,accent2,text,soft,onAccent}|null   (pure; theme "dark"|"light")
 *      MDAccent.contrast(hexA, hexB) -> number    MDAccent.onChange(fn) -> unsubscribe
 */
(function () {
  "use strict";
  var KEY = "md.accent", PROPS = ["--md-accent", "--md-accent-2", "--md-accent-text", "--md-accent-soft", "--md-on-accent", "--ac", "--ac2"];
  var INK = "#04112b", WHITE = "#ffffff", memVal = null, applied = null, subs = [];
  var FALLBACK = { dark: { bg: "#060b1c", surface: "#0e1730" }, light: { bg: "#f4f7fd", surface: "#ffffff" } };

  function ls() { try { return window.localStorage || null; } catch (e) { return null; } }
  function B() { try { return window.MD && window.MD.bridge ? window.MD.bridge : null; } catch (e) { return null; } }

  function rgb(h) { var m = /^#([0-9a-f]{6})$/i.exec(String(h || "").trim()); if (!m) return null; var n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function hex(c) { return "#" + c.map(function (v) { v = Math.max(0, Math.min(255, Math.round(v))); return (v < 16 ? "0" : "") + v.toString(16); }).join(""); }
  function lin(v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }
  function lum(c) { return 0.2126 * lin(c[0]) + 0.7152 * lin(c[1]) + 0.0722 * lin(c[2]); }
  function contrast(a, b) {
    var x = rgb(a), y = rgb(b); if (!x || !y) return 0;
    var l1 = lum(x), l2 = lum(y); if (l1 < l2) { var t = l1; l1 = l2; l2 = t; }
    return (l1 + 0.05) / (l2 + 0.05);
  }
  function mix(c, to, p) { return [c[0] + (to[0] - c[0]) * p, c[1] + (to[1] - c[1]) * p, c[2] + (to[2] - c[2]) * p]; }
  function push(c, toward, bg, min) {                     // step towards white/black until contrast with bg >= min
    var cur = c, i = 0;
    while (contrast(hex(cur), bg) < min && i < 40) { cur = mix(cur, toward, 0.05); i++; }
    return cur;
  }

  function compute(h, theme, bgHex, surfHex) {
    var a = rgb(h); if (!a) return null;
    var light = theme === "light", fb = FALLBACK[light ? "light" : "dark"];
    var bg = rgb(bgHex) ? bgHex : fb.bg, surf = rgb(surfHex) ? surfHex : fb.surface;
    var toward = light ? [0, 0, 0] : [255, 255, 255];
    var fill = push(a, toward, bg, 3);
    var text = push(fill, toward, surf, 4.5);
    var f = hex(fill);
    var cands = [INK, WHITE, "#000000"], ink = cands[0];                // ink on the fill: best of the brand ink / white; pure black only if both fall below 4.5:1
    cands.forEach(function (c) { if (contrast(c, f) > contrast(ink, f)) ink = c; });
    if (contrast(INK, f) >= 4.5 || contrast(WHITE, f) >= 4.5) ink = contrast(INK, f) >= contrast(WHITE, f) ? INK : WHITE;
    var p = 0.35, a2 = mix(fill, toward, p);                             // gradient end: shrink the shift until the same ink stays >= 4.5:1 on it
    while (p > 0.01 && contrast(ink, hex(a2)) < 4.5) { p -= 0.05; a2 = mix(fill, toward, Math.max(0, p)); }
    if (contrast(ink, hex(a2)) < 4.5) a2 = fill;
    return { accent: f, accent2: hex(a2), text: hex(text), soft: "rgba(" + Math.round(fill[0]) + ", " + Math.round(fill[1]) + ", " + Math.round(fill[2]) + ", " + (light ? ".12" : ".16") + ")", onAccent: ink };
  }

  function pref() {
    var v = memVal, s = ls();
    if (v === null && s) { try { v = s.getItem(KEY); } catch (e) { v = null; } }
    return v === "default" ? "default" : "system";
  }
  function sys() { var b = B(); try { return b && typeof b.sysAccent === "function" ? (b.sysAccent() || "") : ""; } catch (e) { return ""; } }
  function cssHex(root, name) { try { var v = getComputedStyle(root).getPropertyValue(name).trim(); return rgb(v) ? v : ""; } catch (e) { return ""; } }

  function clear(root) { PROPS.forEach(function (p) { try { root.style.removeProperty(p); } catch (e) {} }); applied = null; }

  function apply() {
    var root = document.documentElement;
    if (!root) return false;
    var hx = pref() === "system" ? sys() : "";
    if (!hx || !rgb(hx)) { clear(root); return false; }
    var theme = root.getAttribute("data-theme") === "light" ? "light" : "dark";
    var c = compute(hx, theme, cssHex(root, "--md-bg"), cssHex(root, "--md-surface"));
    if (!c) { clear(root); return false; }
    var st = root.style;
    st.setProperty("--md-accent", c.accent); st.setProperty("--md-accent-2", c.accent2); st.setProperty("--md-accent-text", c.text);
    st.setProperty("--md-accent-soft", c.soft); st.setProperty("--md-on-accent", c.onAccent);
    st.setProperty("--ac", c.accent); st.setProperty("--ac2", c.accent2);
    applied = c; return true;
  }

  function fire() { subs.slice().forEach(function (f) { try { f(); } catch (e) {} }); }
  function setPref(p) {
    if (p !== "system" && p !== "default") return false;
    var s = ls(), stored = false;
    if (s) { try { s.setItem(KEY, p); stored = true; memVal = null; } catch (e) {} }
    if (!stored) memVal = p;
    apply(); fire(); return true;
  }
  function status() { var h = sys(); return { pref: pref(), available: !!rgb(h), sys: rgb(h) ? h : "", active: !!applied, applied: applied }; }

  window.MDAccent = { compute: compute, contrast: contrast, apply: apply, setPref: setPref, status: status,
    onChange: function (fn) { if (typeof fn !== "function") return function () {}; subs.push(fn); return function () { var i = subs.indexOf(fn); if (i > -1) subs.splice(i, 1); }; },
    _reset: function () { memVal = null; applied = null; } };

  function init() {
    apply();
    try { if (window.MDTheme && window.MDTheme.onChange) window.MDTheme.onChange(function () { apply(); fire(); }); } catch (e) {}
    try { document.addEventListener("visibilitychange", function () { if (!document.hidden) { var was = applied && applied.accent; apply(); if ((applied && applied.accent) !== was) fire(); } }); } catch (e) {}
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
