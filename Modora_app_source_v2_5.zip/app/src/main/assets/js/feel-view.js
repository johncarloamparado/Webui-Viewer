/* Modora Settings rows for accent + haptics (MB6.3b). Classic script (<script defer>), no modules. All text via textContent.
 * HONESTY RULE: a control is interactive only when it can really work. No system accent reported -> the "System" option is disabled and says why.
 * No vibration bridge -> the haptics switch and Test button are disabled and say why.
 *   MDFeelView.accentRow()   -> <div class="md-set-row md-feel"> (or null when MDAccent is missing)
 *   MDFeelView.hapticsRow()  -> <div class="md-set-row md-feel"> (or null when MDHaptics is missing)
 * Rows redraw themselves after each change.
 */
(function () {
  "use strict";
  function T(k, fb, p) {
    try { if (window.MDI18n) { var s = window.MDI18n.t(k, p); if (s && s !== k) return s; } } catch (e) {}
    return fb.replace(/\{(\w+)\}/g, function (m, n) { return p && p[n] != null ? p[n] : m; });
  }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function toast(m) {
    var e = document.getElementById("toast"); if (!e) return;
    e.textContent = m; e.style.opacity = "1"; e.style.pointerEvents = "none";
    clearTimeout(toast.tm); toast.tm = setTimeout(function () { e.style.opacity = "0"; }, 2200);
  }

  function accentRow() {
    if (!window.MDAccent) return null;
    var row = el("div", "md-set-row md-feel md-feel-col");
    function paint() {
      row.textContent = "";
      var st = window.MDAccent.status();
      var main = el("div", "md-set-main");
      main.appendChild(el("b", "", T("settings.accent", "Accent colour")));
      var sub = !st.available ? T("accent.sys_unavailable", "System colours are not reported by this device (needs Android 12 or newer), so the default blue is used.")
        : st.pref === "system" ? T("accent.sub_system", "Uses your Android wallpaper colour ({hex}), adjusted so text stays readable.", { hex: st.sys })
        : T("accent.sub_default", "Modora's own blue.");
      main.appendChild(el("small", "", sub));
      var seg = el("div", "md-seg"); seg.setAttribute("role", "group"); seg.setAttribute("aria-label", T("accent.choose_aria", "Accent colour"));
      [["system", T("accent.system", "System")], ["default", T("accent.default", "Default blue")]].forEach(function (o) {
        var b = el("button", "md-seg-b", o[1]); b.type = "button"; b.dataset.accent = o[0];
        var on = o[0] === "default" ? (st.pref === "default" || !st.available) : (st.pref === "system" && st.available);
        b.setAttribute("aria-pressed", on ? "true" : "false");
        if (o[0] === "system" && !st.available) { b.disabled = true; b.setAttribute("aria-disabled", "true"); }
        b.addEventListener("click", function () { if (!b.disabled) window.MDAccent.setPref(o[0]); });
        seg.appendChild(b);
      });
      var top = el("div", "md-feel-top");
      top.appendChild(main);
      if (st.active && st.applied) {
        var sw = el("span", "md-feel-swatch"); sw.style.background = st.applied.accent; sw.setAttribute("role", "img");
        sw.setAttribute("aria-label", T("accent.swatch_aria", "Current accent {hex}", { hex: st.applied.accent }));
        top.appendChild(sw);
      }
      row.appendChild(top); row.appendChild(seg);
    }
    paint(); window.MDAccent.onChange(paint);
    return row;
  }

  function hapticsRow() {
    if (!window.MDHaptics) return null;
    var row = el("div", "md-set-row md-feel md-feel-col");
    function paint() {
      row.textContent = "";
      var av = window.MDHaptics.available();
      var top = el("div", "md-feel-top"), main = el("div", "md-set-main");
      main.appendChild(el("b", "", T("haptics.title", "Haptic feedback")));
      main.appendChild(el("small", "", av ? T("haptics.sub", "A short buzz after a verified module toggle, a deck reorder, or when you confirm a power action.")
        : T("haptics.unavailable", "Not available here: open Modora from the app (no vibration bridge).")));
      var sw = el("label", "sw"), inp = el("input"); inp.type = "checkbox"; inp.checked = av && window.MDHaptics.pref(); inp.disabled = !av;
      inp.setAttribute("aria-label", T("haptics.title", "Haptic feedback"));
      inp.addEventListener("change", function () { window.MDHaptics.setPref(inp.checked); });
      sw.appendChild(inp); sw.appendChild(document.createElement("i"));
      top.appendChild(main); top.appendChild(sw); row.appendChild(top);
      if (av) {
        var t = el("button", "md-btn md-btn-sm", T("haptics.test", "Test")); t.type = "button";
        t.addEventListener("click", function () { toast(window.MDHaptics.test() ? T("haptics.tested", "Buzzed") : T("haptics.test_failed", "Could not vibrate")); });
        row.appendChild(t);
        row.appendChild(el("small", "md-feel-note", T("haptics.note", "Android can still block vibration (Do Not Disturb, or touch vibration turned off in system settings).")));
      }
    }
    paint(); window.MDHaptics.onChange(paint);
    return row;
  }

  window.MDFeelView = { accentRow: accentRow, hapticsRow: hapticsRow };
})();
