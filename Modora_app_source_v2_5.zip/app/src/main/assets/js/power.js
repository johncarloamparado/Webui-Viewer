/* Modora power menu (MB4.3). Classic script (<script defer>), no modules, no inline handlers.
 * Four actions only: Reboot, Reboot to recovery, Reboot to bootloader, Power off. Every command is FIXED text (no user input is ever put
 * into a command). Nothing runs until the user taps the red confirm button in a confirmation dialog; Cancel / Esc / outside tap / Android
 * back / route change all close without running anything. Results are reported from the real exit code:
 *   sent      exit 0     "command accepted" (the device should go down now; we cannot see it happen)
 *   failed    exit != 0  shows the first line of stderr
 *   noanswer  -2/-3     no reply in time (a reboot kills the shell, so this can also mean "it is restarting") - said as such
 *   nobridge  -5/-4     root bridge missing
 * After "sent" a 20 s lock stops a second command; if the app is still alive after it, the user is told the device did not restart.
 * API: MDPower.open()  .ask(id)  .run(id)->Promise<{state,code,err}>  .cmd(id)  .actions()  .busy()  .close()
 *      MDPower.warn = fn -> string (extra warning line shown in the confirm dialog, e.g. an install is running)
 *      MDPower.notify = fn(message) (optional toast hook)
 */
(function () {
  "use strict";
  var MD = (window.MD = window.MD || {});
  var RUN_TIMEOUT = 8000, LOCK_MS = 20000;
  var ACTIONS = [
    { id: "reboot",     icon: "refresh", cmd: "sync; reboot || svc power reboot" },
    { id: "recovery",   icon: "undo",    cmd: "sync; reboot recovery" },
    { id: "bootloader", icon: "cpu",     cmd: "sync; reboot bootloader" },
    { id: "poweroff",   icon: "power",   cmd: "sync; reboot -p || svc power shutdown", danger: true }
  ];
  var TEXT = {
    reboot:     ["Reboot", "Restart Android normally.", "Reboot the device?", "The device restarts now. Apps close and unsaved work is lost.", "Reboot now"],
    recovery:   ["Reboot to recovery", "Restart into the recovery menu.", "Reboot to recovery?", "The device restarts into recovery mode. Use the recovery menu to continue; choose reboot there to return to Android.", "Reboot to recovery"],
    bootloader: ["Reboot to bootloader", "Restart into fastboot / bootloader.", "Reboot to bootloader?", "The device restarts into the bootloader (fastboot) screen. It stays there until you choose an option with the hardware buttons or a computer.", "Reboot to bootloader"],
    poweroff:   ["Power off", "Shut the device down.", "Power off the device?", "The device shuts down completely. You will need to press the power button to turn it on again.", "Power off now"]
  };
  var menuEl = null, confEl = null, removeMenu = null, removeConf = null, openerMenu = null, openerConf = null;
  var running = false, lockUntil = 0, lockTimer = 0, current = null, sentOnce = false;

  function T(k, fb, p) {
    try { if (window.MDI18n) { var s = window.MDI18n.t(k, p); if (s && s !== k) return s; } } catch (e) {}
    return String(fb).replace(/\{(\w+)\}/g, function (m, n) { return p && p[n] != null ? p[n] : m; });
  }
  function find(id) { for (var i = 0; i < ACTIONS.length; i++) if (ACTIONS[i].id === id) return ACTIONS[i]; return null; }
  function cmd(id) { var a = typeof id === "string" ? find(id) : null; return a ? a.cmd : null; }
  function label(id) { return T("power." + id, TEXT[id][0]); }
  function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }
  function icon(name) { var s = document.createElement("span"); s.className = "md-pw-ico"; s.setAttribute("aria-hidden", "true"); if (window.MDIcons) s.innerHTML = window.MDIcons.svg(name); return s; }
  function notify(m) { try { if (typeof MDPower.notify === "function") MDPower.notify(m); } catch (e) {} }
  function pushOverlay(fn) { return window.MDRouter && window.MDRouter.pushOverlay ? window.MDRouter.pushOverlay(fn) : null; }

  /* ---------- run (the ONLY place a power command executes) ---------- */
  function classify(r) {
    if (!r) return { state: "failed", code: -1, err: "" };
    if (r.code === 0) return { state: "sent", code: 0, err: "" };
    if (r.code === -5 || r.code === -4) return { state: "nobridge", code: r.code, err: "" };
    if (r.code === -2 || r.code === -3 || r.timedOut) return { state: "noanswer", code: r.code, err: "" };
    return { state: "failed", code: r.code, err: String((r.err || r.out || "")).split("\n")[0].slice(0, 160) };
  }
  function run(id) {
    var c = cmd(id);
    if (!c) return Promise.resolve({ state: "invalid", code: -4, err: "" });
    if (running || Date.now() < lockUntil) return Promise.resolve({ state: "busy", code: 0, err: "" });
    if (!MD.sh) return Promise.resolve({ state: "nobridge", code: -5, err: "" });
    running = true;
    return MD.sh(c, { timeout: RUN_TIMEOUT }).then(function (r) {
      var out = classify(r);
      running = false;
      if (out.state === "sent" || out.state === "noanswer") {
        lockUntil = Date.now() + LOCK_MS; sentOnce = true;
        clearTimeout(lockTimer);
        lockTimer = setTimeout(function () {            /* still alive after the lock: the device did NOT restart */
          sentOnce = false;
          var m = T("power.not_restarted", "The device did not restart. The command was sent but nothing happened; try again, or use the hardware buttons.");
          if (confEl && !confEl.hidden && current) setStatus(m, "warn", true); else notify(m);
        }, LOCK_MS);
      }
      return out;
    }, function () { running = false; return { state: "failed", code: -1, err: "" }; });
  }

  /* ---------- confirmation dialog ---------- */
  function setStatus(msg, tone, canClose) {
    if (!confEl) return;
    var s = confEl.querySelector(".md-pw-status");
    s.textContent = msg || ""; s.hidden = !msg; s.setAttribute("data-tone", tone || "info");
    if (canClose) { confEl.querySelector("[data-pw-cancel]").disabled = false; }
  }
  function statusFor(out, id) {
    var n = label(id);
    if (out.state === "sent") return [T("power.sent", "Command sent. The device should restart in a moment."), "ok"];
    if (out.state === "noanswer") return [T("power.noanswer", "No reply from the device. It may be restarting now. If this app is still open after a few seconds, the command did not complete."), "warn"];
    if (out.state === "nobridge") return [T("power.nobridge", "No root access is available from this screen, so nothing was done."), "danger"];
    if (out.state === "busy") return [T("power.busy", "A power command was just sent. Please wait."), "warn"];
    return [T("power.failed", "{name} failed (exit {code}).", { name: n, code: out.code }) + (out.err ? " " + out.err : ""), "danger"];
  }
  function buildConfirm() {
    var root = el("div", "md-pw md-pw-center"); root.hidden = true; root.setAttribute("role", "alertdialog"); root.setAttribute("aria-modal", "true");
    root.setAttribute("aria-labelledby", "pw-conf-t"); root.setAttribute("aria-describedby", "pw-conf-d");
    var card = el("div", "md-pw-card");
    var t = el("h2", "md-pw-title"); t.id = "pw-conf-t";
    var d = el("p", "md-pw-desc"); d.id = "pw-conf-d";
    var w = el("p", "md-pw-warn"); w.hidden = true; w.className = "md-pw-warn";
    var s = el("p", "md-pw-status"); s.setAttribute("role", "status"); s.setAttribute("aria-live", "polite"); s.hidden = true;
    var row = el("div", "md-pw-actions");
    var cancel = el("button", "md-btn"); cancel.type = "button"; cancel.setAttribute("data-pw-cancel", "1");
    var ok = el("button", "md-btn md-btn-danger"); ok.type = "button"; ok.setAttribute("data-pw-ok", "1");
    row.appendChild(cancel); row.appendChild(ok);
    card.appendChild(t); card.appendChild(d); card.appendChild(w); card.appendChild(s); card.appendChild(row); root.appendChild(card);
    root.addEventListener("click", function (e) { if (e.target === root) closeConfirm(); });
    cancel.addEventListener("click", function () { closeConfirm(); });
    ok.addEventListener("click", function () { confirmed(); });
    root.addEventListener("keydown", trap);
    document.body.appendChild(root);
    return root;
  }
  function trap(e) {
    if (e.key !== "Tab") return;
    var root = e.currentTarget, f = [].slice.call(root.querySelectorAll("button:not([disabled]):not([hidden])"));
    if (!f.length) { e.preventDefault(); return; }
    var first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }
  function ask(id) {
    if (!find(id)) return false;
    if (!confEl) confEl = buildConfirm();
    if (running) return false;
    current = id;
    var tx = TEXT[id], extra = "";
    try { if (typeof MDPower.warn === "function") extra = MDPower.warn(id) || ""; } catch (e) {}
    confEl.querySelector(".md-pw-title").textContent = T("power." + id + "_q", tx[2]);
    confEl.querySelector(".md-pw-desc").textContent = T("power." + id + "_d", tx[3]);
    var w = confEl.querySelector(".md-pw-warn"); w.textContent = extra; w.hidden = !extra;
    var ok = confEl.querySelector("[data-pw-ok]"), cancel = confEl.querySelector("[data-pw-cancel]");
    ok.textContent = T("power." + id + "_ok", tx[4]); ok.hidden = false; ok.disabled = false;
    cancel.textContent = T("common.cancel", "Cancel"); cancel.disabled = false;
    setStatus("", "info");
    var locked = Date.now() < lockUntil && sentOnce;
    if (locked) { ok.disabled = true; setStatus(T("power.busy", "A power command was just sent. Please wait."), "warn"); }
    openerConf = document.activeElement;
    confEl.hidden = false;
    if (!removeConf) removeConf = pushOverlay(function () { closeConfirm(); });
    cancel.focus();                                  /* safe default: Cancel has focus, never the red button */
    return true;
  }
  function closeConfirm() {
    if (!confEl || confEl.hidden) return;
    if (running) return;                             /* a command is being sent: back/Esc are ignored for at most a few seconds */
    confEl.hidden = true; current = null;
    if (removeConf) { removeConf(); removeConf = null; }
    if (openerConf && openerConf.focus && document.contains(openerConf)) { try { openerConf.focus(); } catch (e) {} }
    openerConf = null;
  }
  function confirmed() {
    var id = current;
    if (!id || running || !confEl || confEl.hidden) return;
    var ok = confEl.querySelector("[data-pw-ok]"), cancel = confEl.querySelector("[data-pw-cancel]");
    ok.disabled = true; cancel.disabled = true;
    if (window.MDHaptics) window.MDHaptics.confirm();   // MB6.3b: confirm tap
    setStatus(T("power.sending", "Sending command…"), "info");
    run(id).then(function (out) {
      var m = statusFor(out, id);
      if (out.state === "sent" || out.state === "noanswer") ok.hidden = true; else ok.disabled = false;
      cancel.textContent = T("common.close", "Close");
      setStatus(m[0], m[1], true);
      cancel.focus();
    });
  }

  /* ---------- power menu (list of the four actions) ---------- */
  function buildMenu() {
    var root = el("div", "md-pw md-pw-sheet"); root.hidden = true; root.setAttribute("role", "dialog"); root.setAttribute("aria-modal", "true"); root.setAttribute("aria-labelledby", "pw-menu-t");
    var card = el("div", "md-pw-card");
    var h = el("div", "md-pw-head"); var t = el("h2", "md-pw-title", T("power.title", "Power")); t.id = "pw-menu-t";
    var x = el("button", "md-btn md-btn-sm md-btn-ghost", T("common.close", "Close")); x.type = "button"; x.setAttribute("data-pw-close", "1");
    h.appendChild(t); h.appendChild(x);
    var note = el("p", "md-pw-note", T("power.note", "Each action asks for confirmation first. Needs root.")); note.setAttribute("data-pw-note", "1");
    var list = el("div", "md-pw-list");
    ACTIONS.forEach(function (a) {
      var b = el("button", "md-pw-item" + (a.danger ? " is-danger" : "")); b.type = "button"; b.setAttribute("data-pw", a.id);
      var txt = el("span", "md-pw-txt"); txt.appendChild(el("b", "", label(a.id))); txt.appendChild(el("small", "", T("power." + a.id + "_s", TEXT[a.id][1])));
      b.appendChild(icon(a.icon)); b.appendChild(txt); list.appendChild(b);
    });
    card.appendChild(h); card.appendChild(note); card.appendChild(list); root.appendChild(card);
    root.addEventListener("click", function (e) {
      if (e.target === root) { close(); return; }
      var b = e.target.closest ? e.target.closest("button") : null;
      if (!b || !root.contains(b)) return;
      if (b.hasAttribute("data-pw-close")) close();
      else if (b.getAttribute("data-pw")) ask(b.getAttribute("data-pw"));
    });
    root.addEventListener("keydown", trap);
    document.body.appendChild(root);
    return root;
  }
  function open() {
    if (!menuEl) menuEl = buildMenu();
    if (!menuEl.hidden) return true;
    openerMenu = document.activeElement;
    menuEl.hidden = false;
    if (!removeMenu) removeMenu = pushOverlay(function () { close(); });
    var f = menuEl.querySelector("[data-pw]"); if (f) f.focus();
    return true;
  }
  function close() {                                  /* closes the confirm dialog first (if open), then the menu */
    if (confEl && !confEl.hidden) { closeConfirm(); if (!confEl.hidden) return; }
    if (!menuEl || menuEl.hidden) return;
    menuEl.hidden = true;
    if (removeMenu) { removeMenu(); removeMenu = null; }
    if (openerMenu && openerMenu.focus && document.contains(openerMenu)) { try { openerMenu.focus(); } catch (e) {} }
    openerMenu = null;
  }
  function closeAll() { if (confEl && !confEl.hidden && !running) closeConfirm(); if (menuEl && !menuEl.hidden) close(); }

  var MDPower = (window.MDPower = {
    open: open, ask: ask, run: run, cmd: cmd, close: closeAll, warn: null, notify: null,
    actions: function () { return ACTIONS.map(function (a) { return a.id; }); },
    busy: function () { return running || Date.now() < lockUntil; }
  });
})();
