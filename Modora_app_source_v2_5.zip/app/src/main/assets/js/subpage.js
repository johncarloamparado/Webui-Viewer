/* Modora shared sub-page helpers (MB3.1) - classic script, no modules.
 * For the restyled legacy sub-pages (action.html now; rme50.html/anr.html later). No dependency on core.js/bridge.js.
 * API: window.MDPage {
 *   back()                      Back button: history.back(); if the page is the first entry (pinned shortcut) or history does not move, go to home.html.
 *   t(key, fallback, params)    MDI18n text if available and the key exists, else the English fallback (never shows a raw key).
 *   icon(name)                  inline <svg> markup from MDIcons, "" when unavailable.
 *   tone(el, tone)              set an .md-badge tone: "info" | "ok" | "danger" | "warn" | "accent" | "" (neutral).
 * }
 */
(function () {
  "use strict";
  var TONES = ["info", "ok", "danger", "warn", "accent"];

  function t(key, fallback, params) {
    try {
      if (window.MDI18n) {
        var s = window.MDI18n.t(key, params);
        if (typeof s === "string" && s && s !== key) return s;
      }
    } catch (e) {}
    var out = String(fallback == null ? "" : fallback);
    if (params) out = out.replace(/\{(\w+)\}/g, function (m, k) { return params[k] != null ? String(params[k]) : m; });
    return out;
  }

  function icon(name) {
    try { return window.MDIcons ? window.MDIcons.svg(name) : ""; } catch (e) { return ""; }
  }

  function tone(el, name) {
    if (!el || !el.classList) return;
    for (var i = 0; i < TONES.length; i++) el.classList.remove("md-badge-" + TONES[i]);
    if (TONES.indexOf(name) >= 0) el.classList.add("md-badge-" + name);
  }

  function home() { try { location.replace("home.html"); } catch (e) { location.href = "home.html"; } }

  // Is there a real earlier page of this app in the session history? The Navigation API (Chromium 102+, so WebView too) knows;
  // history.length can also count an initial about:blank entry (MB3.4: Back from a pinned-shortcut page then went to a blank page).
  function hasPrev() {
    try {
      var n = window.navigation;
      if (n && n.currentEntry && typeof n.currentEntry.index === "number") return n.currentEntry.index > 0;
    } catch (e) {}
    return history.length > 1;
  }

  function back() {
    if (hasPrev()) {
      history.back();
      // If history did not actually move (the entry count can include the initial entry), land on the deck instead of doing nothing.
      setTimeout(home, 700);
    } else {
      home();
    }
  }

  window.MDPage = { back: back, t: t, icon: icon, tone: tone };
})();
