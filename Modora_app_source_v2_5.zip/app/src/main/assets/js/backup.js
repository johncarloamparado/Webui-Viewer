/* Modora settings backup + restore logic (MB5.3). Classic script (<script defer>), no modules. Requires js/profiles.js (MDProfiles.SCHEMA) and js/profiles-apply.js (readCurrent).
 * A backup is plain JSON text the person copies/shares and later pastes back. It holds ONLY settings the app already supports (no secrets, no device ids, no paths):
 *   {"app":"Modora","type":"settings-backup","schema":1,"created":"<ISO time>","appVersion":"2.5","profile":"<id>|null","rme50":{KEY:"value"},"anr":{KEY:"value"}}
 * create()  -> Promise<{ok, reason?, json, data, included[], missing[], skipped}>  reads the CURRENT tuner configs read-only; values that fail the schema are left out (counted in `skipped`).
 * parse(t)  -> {ok:true, backup:{profile, rme50?, anr?, created, appVersion}, warnings[]} | {ok:false, reason, detail?}  STRICT: an invalid value rejects the whole backup; unknown keys are dropped with a warning.
 * toProfile(backup) -> profile-shaped object for MDProfilesApply.planCustom (restore goes through the same preview + apply path as profiles; nothing is written here).
 * Reject reasons: empty | toolarge | json | notobject | notmodora | schema_missing | schema_newer | schema_unsupported | bad_section | bad_value | bad_profile | empty_backup.
 * NEVER throws, NEVER writes to the device or storage.
 */
(function () {
  "use strict";
  var SCHEMA_V = 1, MAX = 20000, ID_RE = /^[a-z0-9_-]{1,32}$/, SECS = ["rme50", "anr"], TOP = { app: 1, type: 1, schema: 1, created: 1, appVersion: 1, profile: 1, rme50: 1, anr: 1 };
  var has = function (o, k) { return Object.prototype.hasOwnProperty.call(o, k); };
  function rules() { var P = window.MDProfiles; return P && P.SCHEMA ? P.SCHEMA : null; }
  function clean(v, n) { return typeof v === "string" ? v.replace(/[\u0000-\u001f\u007f]/g, "").trim().slice(0, n) : ""; }

  function parse(text) {
    var R = rules(), warnings = [];
    if (!R) return { ok: false, reason: "noschema" };
    if (typeof text !== "string") return { ok: false, reason: "empty" };
    var t = text.replace(/^\uFEFF/, "").trim();
    if (!t) return { ok: false, reason: "empty" };
    if (t.length > MAX) return { ok: false, reason: "toolarge" };
    var d; try { d = JSON.parse(t); } catch (e) { return { ok: false, reason: "json" }; }
    if (!d || typeof d !== "object" || Array.isArray(d)) return { ok: false, reason: "notobject" };
    if (d.app !== "Modora" || d.type !== "settings-backup") return { ok: false, reason: "notmodora" };
    if (typeof d.schema !== "number" || !isFinite(d.schema) || Math.floor(d.schema) !== d.schema) return { ok: false, reason: "schema_missing" };
    if (d.schema > SCHEMA_V) return { ok: false, reason: "schema_newer", detail: String(d.schema) };
    if (d.schema !== SCHEMA_V) return { ok: false, reason: "schema_unsupported", detail: String(d.schema) };
    Object.keys(d).forEach(function (k) { if (!has(TOP, k)) warnings.push({ code: "unknown_key", detail: clean(k, 20) }); });
    var out = { profile: null, created: "", appVersion: "" };
    if (d.profile != null) {
      if (typeof d.profile !== "string" || !ID_RE.test(d.profile)) return { ok: false, reason: "bad_profile" };
      out.profile = d.profile;
    }
    out.created = clean(d.created, 40); out.appVersion = clean(d.appVersion, 20);
    var n = 0, i, bad = null;
    SECS.forEach(function (sec) {
      if (bad || d[sec] == null) return;
      var raw = d[sec];
      if (typeof raw !== "object" || Array.isArray(raw)) { bad = { reason: "bad_section", detail: sec }; return; }
      var o = {}, c = 0;
      Object.keys(raw).forEach(function (k) {
        if (bad) return;
        if (!has(R[sec], k)) { warnings.push({ code: "unknown_key", detail: sec + "." + clean(k, 20) }); return; }
        var v = typeof raw[k] === "number" ? String(raw[k]) : raw[k], ok = typeof v === "string" ? R[sec][k](v) : null;
        if (ok === null) { bad = { reason: "bad_value", detail: sec + "." + k }; return; }
        o[k] = ok; c++;
      });
      if (bad) return;
      if (c) { out[sec] = o; n += c; } else warnings.push({ code: "empty_section", detail: sec });
    });
    if (bad) return { ok: false, reason: bad.reason, detail: bad.detail };
    if (!n && !out.profile) return { ok: false, reason: "empty_backup" };
    return { ok: true, backup: out, warnings: warnings };
  }

  function toProfile(b) {
    var p = { id: "backup", name: "Backup" };
    SECS.forEach(function (s) { if (b && b[s]) p[s] = b[s]; });
    return p;
  }

  function create() {
    return new Promise(function (resolve) {
      var A = window.MDProfilesApply, R = rules();
      if (!A || !A.readCurrent || !R) return resolve({ ok: false, reason: "noscripts" });
      A.readCurrent().then(function (r) {
        if (!r.ok) return resolve({ ok: false, reason: r.reason });
        var data = { app: "Modora", type: "settings-backup", schema: SCHEMA_V, created: new Date().toISOString(), appVersion: "", profile: null }, included = [], skipped = 0;
        try { var info = window.MD && window.MD.bridge && window.MD.bridge.appInfo ? window.MD.bridge.appInfo() : null; if (info && typeof info.versionName === "string") data.appVersion = clean(info.versionName, 20); } catch (e) {}
        try { var sel = window.MDProfiles && window.MDProfiles.selected(); if (sel) data.profile = sel; } catch (e) {}
        SECS.forEach(function (sec) {
          if (!r.cfg[sec]) return;
          var o = {}, c = 0;
          Object.keys(r.cfg[sec]).forEach(function (k) {
            if (!has(R[sec], k)) return;
            var v = R[sec][k](String(r.cfg[sec][k]));
            if (v === null) { skipped++; return; }
            o[k] = v; c++;
          });
          if (c) { data[sec] = o; included.push(sec); }
        });
        if (!included.length && !data.profile) return resolve({ ok: false, reason: "nothing", missing: r.missing });
        var json = JSON.stringify(data, null, 2), chk = parse(json);          /* a backup must always be readable by our own parser */
        if (!chk.ok) return resolve({ ok: false, reason: "selfcheck" });
        resolve({ ok: true, json: json, data: data, included: included, missing: r.missing, skipped: skipped });
      }, function () { resolve({ ok: false, reason: "error" }); });
    });
  }

  window.MDBackup = { create: create, parse: parse, toProfile: toProfile, SCHEMA_VERSION: SCHEMA_V, MAX_BYTES: MAX };
})();
