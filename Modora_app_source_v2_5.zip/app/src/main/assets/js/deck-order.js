/* Modora deck reorder (MB6.1). Classic script (<script defer>), no modules.
 * The deck order IS the order of the ids in the favourites file (/data/adb/moddeck/favs); nothing else stores it.
 *
 * Pure helpers (no DOM, unit-testable):
 *   MDDeckOrder.move(order, id, dir)      dir -1 (earlier) | +1 (later) -> new array, or null if impossible (unknown id / already at the edge)
 *   MDDeckOrder.moveTo(order, id, index)  put id at index (0..len-1) -> new array, or null if unknown id / same place / bad index
 *   MDDeckOrder.sameOrder(a, b)           true when both lists have the same ids in the same order
 * Drag controller (touch + mouse + pen, via pointer events on a drag handle only, so scrolling and taps are never hijacked):
 *   MDDeckOrder.attach(grid, opts)  -> {destroy()}
 *     opts.canReorder()          -> bool   (false: handles do nothing)
 *     opts.getOrder()            -> array of ids currently on the deck, in deck order
 *     opts.onCommit(id, toIndex) called once on drop when the position really changed
 *     Tiles are  .tile[data-t=ID]  and the handle is  [data-mvh=ID]  inside the tile.
 *   Escape or pointercancel cancels the drag and changes nothing. A tile that disappears mid-drag (rescan) cancels the drag.
 * MBFIX.1: while dragging, the other tiles slide to show the new order (live preview); dropping commits exactly the previewed place.
 * Keyboard / button fallback is handled by the page (data-mv="ID|-1" or "ID|1"); the handle also accepts the arrow keys.
 */
(function () {
  "use strict";

  function idx(a, id) { return Array.isArray(a) ? a.indexOf(id) : -1; }

  function moveTo(order, id, to) {
    var from = idx(order, id);
    if (from < 0 || typeof to !== "number" || to !== Math.floor(to) || to < 0 || to >= order.length || to === from) return null;
    var out = order.slice();
    out.splice(from, 1);
    out.splice(to, 0, id);
    return out;
  }
  function move(order, id, dir) {
    var from = idx(order, id);
    if (from < 0 || (dir !== -1 && dir !== 1)) return null;
    return moveTo(order, id, from + dir);
  }
  function sameOrder(a, b) {
    if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false;
    for (var i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
    return true;
  }

  function attach(grid, opts) {
    var drag = null, scrollTimer = 0;
    var EDGE = 64, STEP = 14;

    function tiles() { return Array.prototype.slice.call(grid.querySelectorAll(".tile[data-t]")); }

    function clearMarks() {
      tiles().forEach(function (t) { t.classList.remove("md-drop-target"); });
    }
    function finish() {
      clearInterval(scrollTimer); scrollTimer = 0;
      document.removeEventListener("keydown", onKey, true);
      if (drag) {
        try { if (drag.handle.releasePointerCapture) drag.handle.releasePointerCapture(drag.pid); } catch (e) {}
        drag.tile.classList.remove("md-dragging");
        drag.tile.style.transform = "";
        drag.tile.style.zIndex = "";
        grid.classList.remove("md-sorting");
      }
      tiles().forEach(function (t) { if (t !== (drag && drag.tile)) t.style.transform = ""; });   // MBFIX.1: drop the live-preview shifts
      clearMarks();
      drag = null;
    }
    // MBFIX.1 live preview: the other tiles slide (CSS transition) into the places they will have if the dragged tile is dropped now.
    // Hit-testing uses the rectangles measured at drag start (page coordinates), never the shifted tiles, so the preview cannot jitter.
    function measure(order, dragId) {
      var map = {}, slots = [];
      tiles().forEach(function (t) { map[t.getAttribute("data-t")] = t; });
      var sx = window.pageXOffset, sy = window.pageYOffset;
      order.forEach(function (id, k) {
        var t = map[id], r = t ? t.getBoundingClientRect() : null;
        slots[k] = r ? { id: id, tile: t, l: r.left + sx, t: r.top + sy, r: r.right + sx, b: r.bottom + sy } : null;
      });
      return slots;
    }
    function preview(to) {
      var slots = drag.slots, order = drag.order;
      var next = (to == null) ? order : (moveTo(order, drag.id, to) || order);
      slots.forEach(function (s0, k) {
        if (!s0 || s0.id === drag.id) return;
        var nk = next.indexOf(s0.id), s1 = nk >= 0 ? slots[nk] : null;
        var dx = s1 ? s1.l - s0.l : 0, dy = s1 ? s1.t - s0.t : 0;
        s0.tile.style.transform = (dx || dy) ? "translate(" + dx + "px," + dy + "px)" : "";
      });
    }
    function layout() {                                      // follow the finger, also while the page scrolls
      if (!drag) return;
      var dx = drag.x - drag.sx;
      var dy = (drag.y + window.pageYOffset) - (drag.sy + drag.sp);
      drag.tile.style.transform = "translate(" + dx + "px," + dy + "px) scale(1.04)";
      var px = drag.x + window.pageXOffset, py = drag.y + window.pageYOffset, hit = null, best = Infinity;
      drag.slots.forEach(function (s0, k) {
        if (!s0 || s0.id === drag.id) return;
        if (px >= s0.l && px <= s0.r && py >= s0.t && py <= s0.b) {
          var d = Math.abs(px - (s0.l + s0.r) / 2) + Math.abs(py - (s0.t + s0.b) / 2);
          if (d < best) { best = d; hit = k; }
        }
      });
      var own = drag.slots[drag.from];
      var overOwn = own && px >= own.l && px <= own.r && py >= own.t && py <= own.b;
      var to = drag.to;
      if (hit != null) to = hit; else if (overOwn) to = null;   // in a gap between tiles: keep the last previewed place (what you see is what you drop)
      if (to !== drag.to || !drag.previewed) {
        drag.to = to; drag.previewed = true; preview(to);
        if (window.MDHaptics && window.MDHaptics.tap) { try { window.MDHaptics.tap(); } catch (e) {} }   // tiny tick when the slot changes (respects the haptics setting)
      }
    }
    function autoScroll() {
      if (!drag) return;
      var h = window.innerHeight || document.documentElement.clientHeight;
      var dy = 0;
      if (drag.y < EDGE) dy = -STEP; else if (drag.y > h - EDGE) dy = STEP;
      if (dy) { window.scrollBy(0, dy); layout(); }
    }

    function onDown(e) {
      var h = e.target.closest && e.target.closest("[data-mvh]");
      if (!h || !grid.contains(h) || drag) return;
      if (e.pointerType === "mouse" && e.button !== 0) return;
      if (!opts.canReorder()) return;
      var tile = h.closest(".tile[data-t]");
      if (!tile) return;
      var id = h.getAttribute("data-mvh");
      if (opts.getOrder().indexOf(id) < 0) return;
      e.preventDefault();
      var order0 = opts.getOrder();
      drag = { id: id, tile: tile, handle: h, pid: e.pointerId, sx: e.clientX, sy: e.clientY, sp: window.pageYOffset, x: e.clientX, y: e.clientY, to: null,
               order: order0, from: order0.indexOf(id), slots: measure(order0, id), previewed: true };
      try { h.setPointerCapture(e.pointerId); } catch (err) {}
      tile.classList.add("md-dragging");
      tile.style.zIndex = "5";
      grid.classList.add("md-sorting");
      document.addEventListener("keydown", onKey, true);
      scrollTimer = setInterval(autoScroll, 30);
    }
    function onMove(e) {
      if (!drag || e.pointerId !== drag.pid) return;
      drag.x = e.clientX; drag.y = e.clientY;
      if (!drag.tile.isConnected) { finish(); return; }
      layout();
    }
    function onUp(e) {
      if (!drag || e.pointerId !== drag.pid) return;
      var d = drag;
      var ok = d.tile.isConnected;
      finish();
      if (ok && d.to != null) opts.onCommit(d.id, d.to);
    }
    function onCancel(e) { if (drag && e.pointerId === drag.pid) finish(); }
    function onKey(e) {
      if (drag && e.key === "Escape") { e.preventDefault(); e.stopPropagation(); finish(); }
    }
    function onHandleKey(e) {                                // keyboard on the handle: arrows move the tile one place
      var h = e.target.closest && e.target.closest("[data-mvh]");
      if (!h || drag || !opts.canReorder()) return;
      var dir = (e.key === "ArrowLeft" || e.key === "ArrowUp") ? -1 : (e.key === "ArrowRight" || e.key === "ArrowDown") ? 1 : 0;
      if (!dir) return;
      e.preventDefault();
      var id = h.getAttribute("data-mvh"), order = opts.getOrder(), to = idx(order, id) + dir;
      if (to >= 0 && to < order.length) opts.onCommit(id, to);
    }

    grid.addEventListener("pointerdown", onDown);
    grid.addEventListener("pointermove", onMove);
    grid.addEventListener("pointerup", onUp);
    grid.addEventListener("pointercancel", onCancel);
    grid.addEventListener("keydown", onHandleKey);
    return {
      destroy: function () {
        finish();
        grid.removeEventListener("pointerdown", onDown); grid.removeEventListener("pointermove", onMove);
        grid.removeEventListener("pointerup", onUp); grid.removeEventListener("pointercancel", onCancel);
        grid.removeEventListener("keydown", onHandleKey);
      },
      active: function () { return !!drag; }
    };
  }

  window.MDDeckOrder = { move: move, moveTo: moveTo, sameOrder: sameOrder, attach: attach };
})();
