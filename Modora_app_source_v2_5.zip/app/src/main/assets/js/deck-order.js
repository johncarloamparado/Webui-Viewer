/* Modora deck reorder (MB6.1). Classic script (<script defer>), no modules.
 * The deck order IS the order of the ids in the favourites file (/data/adb/moddeck/favs); nothing else stores it.
 *
 * Pure helpers (no DOM, unit-testable):
 *   MDDeckOrder.move(order, id, dir)      dir -1 (earlier) | +1 (later) -> new array, or null if impossible (unknown id / already at the edge)
 *   MDDeckOrder.moveTo(order, id, index)  put id at index (0..len-1) -> new array, or null if unknown id / same place / bad index
 *   MDDeckOrder.sameOrder(a, b)           true when both lists have the same ids in the same order
 * Drag controller (touch + mouse + pen, via pointer events on a drag handle only, so scrolling and taps are never hijacked):
 *   MDDeckOrder.attach(grid, opts)  -> {destroy()}
 *     opts.canReorder()          -> bool   (false: handles do nothing)
 *     opts.getOrder()            -> array of ids currently on the deck, in deck order
 *     opts.onCommit(id, toIndex) called once on drop when the position really changed
 *     Tiles are  .tile[data-t=ID]  and the handle is  [data-mvh=ID]  inside the tile.
 *   Escape or pointercancel cancels the drag and changes nothing. A tile that disappears mid-drag (rescan) cancels the drag.
 * Keyboard / button fallback is handled by the page (data-mv="ID|-1" or "ID|1"); the handle also accepts the arrow keys.
 */
(function () {
  "use strict";

  function idx(a, id) { return Array.isArray(a) ? a.indexOf(id) : -1; }

  function moveTo(order, id, to) {
    var from = idx(order, id);
    if (from < 0 || typeof to !== "number" || to !== Math.floor(to) || to < 0 || to >= order.length || to === from) return null;
    var out = order.slice();
    out.splice(from, 1);
    out.splice(to, 0, id);
    return out;
  }
  function move(order, id, dir) {
    var from = idx(order, id);
    if (from < 0 || (dir !== -1 && dir !== 1)) return null;
    return moveTo(order, id, from + dir);
  }
  function sameOrder(a, b) {
    if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false;
    for (var i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
    return true;
  }

  function attach(grid, opts) {
    var drag = null, scrollTimer = 0;
    var EDGE = 64, STEP = 14;

    function tiles() { return Array.prototype.slice.call(grid.querySelectorAll(".tile[data-t]")); }

    function clearMarks() {
      tiles().forEach(function (t) { t.classList.remove("md-drop-target"); });
    }
    function finish() {
      clearInterval(scrollTimer); scrollTimer = 0;
      document.removeEventListener("keydown", onKey, true);
      if (drag) {
        try { if (drag.handle.releasePointerCapture) drag.handle.releasePointerCapture(drag.pid); } catch (e) {}
        drag.tile.classList.remove("md-dragging");
        drag.tile.style.transform = "";
        drag.tile.style.zIndex = "";
        grid.classList.remove("md-sorting");
      }
      clearMarks();
      drag = null;
    }
    function layout() {                                      // follow the finger, also while the page scrolls
      if (!drag) return;
      var dx = drag.x - drag.sx;
      var dy = (drag.y + window.pageYOffset) - (drag.sy + drag.sp);
      drag.tile.style.transform = "translate(" + dx + "px," + dy + "px)";
      var target = null, best = Infinity;
      var order = opts.getOrder();
      tiles().forEach(function (t) {
        t.classList.remove("md-drop-target");
        if (t === drag.tile) return;
        var r = t.getBoundingClientRect();
        if (drag.x >= r.left && drag.x <= r.right && drag.y >= r.top && drag.y <= r.bottom) {
          var d = Math.abs(drag.x - (r.left + r.width / 2)) + Math.abs(drag.y - (r.top + r.height / 2));
          if (d < best) { best = d; target = t; }
        }
      });
      drag.to = null;
      if (target) {
        var ti = order.indexOf(target.getAttribute("data-t"));
        if (ti >= 0) { drag.to = ti; target.classList.add("md-drop-target"); }
      }
    }
    function autoScroll() {
      if (!drag) return;
      var h = window.innerHeight || document.documentElement.clientHeight;
      var dy = 0;
      if (drag.y < EDGE) dy = -STEP; else if (drag.y > h - EDGE) dy = STEP;
      if (dy) { window.scrollBy(0, dy); layout(); }
    }

    function onDown(e) {
      var h = e.target.closest && e.target.closest("[data-mvh]");
      if (!h || !grid.contains(h) || drag) return;
      if (e.pointerType === "mouse" && e.button !== 0) return;
      if (!opts.canReorder()) return;
      var tile = h.closest(".tile[data-t]");
      if (!tile) return;
      var id = h.getAttribute("data-mvh");
      if (opts.getOrder().indexOf(id) < 0) return;
      e.preventDefault();
      drag = { id: id, tile: tile, handle: h, pid: e.pointerId, sx: e.clientX, sy: e.clientY, sp: window.pageYOffset, x: e.clientX, y: e.clientY, to: null };
      try { h.setPointerCapture(e.pointerId); } catch (err) {}
      tile.classList.add("md-dragging");
      tile.style.zIndex = "5";
      grid.classList.add("md-sorting");
      document.addEventListener("keydown", onKey, true);
      scrollTimer = setInterval(autoScroll, 30);
    }
    function onMove(e) {
      if (!drag || e.pointerId !== drag.pid) return;
      drag.x = e.clientX; drag.y = e.clientY;
      if (!drag.tile.isConnected) { finish(); return; }
      layout();
    }
    function onUp(e) {
      if (!drag || e.pointerId !== drag.pid) return;
      var d = drag;
      var ok = d.tile.isConnected;
      finish();
      if (ok && d.to != null) opts.onCommit(d.id, d.to);
    }
    function onCancel(e) { if (drag && e.pointerId === drag.pid) finish(); }
    function onKey(e) {
      if (drag && e.key === "Escape") { e.preventDefault(); e.stopPropagation(); finish(); }
    }
    function onHandleKey(e) {                                // keyboard on the handle: arrows move the tile one place
      var h = e.target.closest && e.target.closest("[data-mvh]");
      if (!h || drag || !opts.canReorder()) return;
      var dir = (e.key === "ArrowLeft" || e.key === "ArrowUp") ? -1 : (e.key === "ArrowRight" || e.key === "ArrowDown") ? 1 : 0;
      if (!dir) return;
      e.preventDefault();
      var id = h.getAttribute("data-mvh"), order = opts.getOrder(), to = idx(order, id) + dir;
      if (to >= 0 && to < order.length) opts.onCommit(id, to);
    }

    grid.addEventListener("pointerdown", onDown);
    grid.addEventListener("pointermove", onMove);
    grid.addEventListener("pointerup", onUp);
    grid.addEventListener("pointercancel", onCancel);
    grid.addEventListener("keydown", onHandleKey);
    return {
      destroy: function () {
        finish();
        grid.removeEventListener("pointerdown", onDown); grid.removeEventListener("pointermove", onMove);
        grid.removeEventListener("pointerup", onUp); grid.removeEventListener("pointercancel", onCancel);
        grid.removeEventListener("keydown", onHandleKey);
      },
      active: function () { return !!drag; }
    };
  }

  window.MDDeckOrder = { move: move, moveTo: moveTo, sameOrder: sameOrder, attach: attach };
})();
