/* Modora router (MB1.5). Classic script (<script defer>), no modules, NO history/hash API
 * (pushState is unreliable on file:// and the native back would then navigate the WebView).
 * Views are elements  <section class="md-view" data-view="deck"> (see css/views.css); the router toggles .is-active.
 * BACK CONTRACT with MainActivity.onBackPressed(): native evaluates (window.MD && MD.onBack && MD.onBack()) === true.
 *   init() installs MD.onBack. It returns true ONLY when it handled the press (closed an overlay or popped a route);
 *   it returns false at the root (native then does goBack/finish) and never throws.
 * Order on back: top overlay -> previous route -> false.
 * API: MDRouter.init({home, fallback}) -> bool ready        .go(name,{params,replace}) -> bool
 *      .tab(name) -> bool  (top-level switch: stack becomes [home, name] so back returns to home, then exits)
 *      .back() -> bool     .current() -> {name, params}|null   .stack() -> names   .has(name)
 *      .pushOverlay(closeFn) -> remove()   (sheets/dialogs; back/Escape call closeFn; remove() is idempotent)
 *      .closeTop() -> bool (Escape handler)   .onChange(fn({name,params,from,action})) -> off
 * Unknown route names fall back to options.fallback (else home); params are plain data and are never evaluated.
 */
(function () {
  "use strict";
  var MD = (window.MD = window.MD || {});
  var NAME_RE = /^[A-Za-z][A-Za-z0-9_-]*$/, MAX = 20;
  var views = {}, stack = [], overlays = [], listeners = [];
  var home = "", fallback = "", ready = false, prevBack = null, keyBound = false;

  function has(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
  function top() { return stack.length ? stack[stack.length - 1] : null; }

  function emit(entry, from, action) {
    for (var i = 0; i < listeners.length; i++) {
      try { listeners[i]({ name: entry.name, params: entry.params, from: from, action: action }); } catch (e) {}
    }
  }

  function show(entry, previous) {
    if (previous && has(views, previous.name)) previous.scroll = window.pageYOffset || 0;
    for (var n in views) if (has(views, n)) views[n].classList.toggle("is-active", n === entry.name);
    var v = views[entry.name];
    if (!v.hasAttribute("tabindex")) v.setAttribute("tabindex", "-1");
    try { v.focus({ preventScroll: true }); } catch (e) {}
    try { window.scrollTo(0, entry.scroll || 0); } catch (e) {}
  }

  function resolveName(name) {
    if (typeof name === "string" && has(views, name)) return name;
    if (has(views, fallback)) return fallback;
    if (has(views, home)) return home;
    return "";
  }

  function go(name, o) {
    if (!ready) return false;
    o = o || {};
    var n = resolveName(name); if (!n) return false;
    var cur = top(), params = o.params == null ? null : o.params;
    if (cur && cur.name === n) { cur.params = params; emit(cur, n, "replace"); return true; }
    var entry = { name: n, params: params, scroll: 0 };
    if (o.replace && stack.length) stack[stack.length - 1] = entry;
    else { stack.push(entry); if (stack.length > MAX) stack.splice(1, 1); }   // keep the root entry
    show(entry, cur); emit(entry, cur ? cur.name : "", o.replace ? "replace" : "go");
    return true;
  }

  function tab(name) {
    if (!ready) return false;
    var n = resolveName(name); if (!n) return false;
    var cur = top(); if (cur && cur.name === n && stack.length <= 2) return true;
    var root = has(views, home) ? { name: home, params: null, scroll: 0 } : null;
    var entry = { name: n, params: null, scroll: 0 };
    stack = root && n !== home ? [root, entry] : [entry];
    show(entry, cur); emit(entry, cur ? cur.name : "", "tab");
    return true;
  }

  function closeTop() {
    if (!overlays.length) return false;
    var o = overlays.pop();
    try { o.close(); } catch (e) {}
    return true;
  }

  function back() {
    if (closeTop()) return true;
    if (ready && stack.length > 1) {
      var from = stack.pop(), entry = top();
      show(entry, from); emit(entry, from.name, "back");
      return true;
    }
    return false;
  }

  function onBack() {
    try { if (back()) return true; } catch (e) {}
    try { if (prevBack && prevBack() === true) return true; } catch (e) {}
    return false;
  }

  function init(o) {
    o = o || {};
    views = {}; stack = [];
    var nodes = document.querySelectorAll(".md-view[data-view]");
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i].getAttribute("data-view");
      if (NAME_RE.test(n) && !has(views, n)) views[n] = nodes[i];
    }
    var names = Object.keys(views);
    home = typeof o.home === "string" && has(views, o.home) ? o.home : (names[0] || "");
    fallback = typeof o.fallback === "string" && has(views, o.fallback) ? o.fallback : home;
    ready = names.length > 0;
    if (MD.onBack !== onBack) { prevBack = typeof MD.onBack === "function" ? MD.onBack : null; MD.onBack = onBack; }
    if (!keyBound) {
      keyBound = true;
      document.addEventListener("keydown", function (e) { if (e.key === "Escape" && closeTop()) e.preventDefault(); });
    }
    if (ready) { var entry = { name: home, params: null, scroll: 0 }; stack.push(entry); show(entry, null); emit(entry, "", "init"); }
    return ready;
  }

  window.MDRouter = {
    init: init, go: go, tab: tab, back: back, closeTop: closeTop,
    has: function (n) { return has(views, n); },
    current: function () { var c = top(); return c ? { name: c.name, params: c.params } : null; },
    stack: function () { return stack.map(function (e) { return e.name; }); },
    pushOverlay: function (close) {
      if (typeof close !== "function") return function () {};
      var o = { close: close };
      overlays.push(o);
      return function () { var i = overlays.indexOf(o); if (i > -1) overlays.splice(i, 1); };
    },
    onChange: function (fn) {
      if (typeof fn !== "function") return function () {};
      listeners.push(fn);
      return function () { var i = listeners.indexOf(fn); if (i > -1) listeners.splice(i, 1); };
    }
  };
})();
