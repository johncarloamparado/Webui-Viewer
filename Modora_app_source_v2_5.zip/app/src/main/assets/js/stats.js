/* Modora live stats - measurements + parsing (MB6.2). Classic script (<script defer>), no modules.
 * ONLY real measurements are reported. Anything that cannot be read is null ("unavailable"), never 0 and never a guess.
 * ONE fixed read-only command (no user input, no dynamic parts) is run through MD.sh (root shell, js/bridge.js):
 *   /proc/stat first line (CPU jiffies), MemTotal + MemAvailable from /proc/meminfo, battery capacity + temp from
 *   /sys/class/power_supply/battery/. Nothing is written. Output must contain the end marker "@@e" or the sample is rejected.
 * API
 *   MDStats.SCRIPT                      the fixed command text
 *   MDStats.parse(out)                  -> {complete, cpu:{total,idle}|null, mem:{totalKb,availKb}|null, batt:{pct|null, tempC|null}|null}   (pure)
 *   MDStats.cpuPct(prev, cur)           -> 0..100 | null   (null when there is no previous sample or the counters did not advance / went backwards)
 *   MDStats.memPct(mem)                 -> 0..100 | null
 *   MDStats.push(arr, v, max)           append (null = a gap) and keep the last `max` entries; returns arr
 *   MDStats.sample()                    -> Promise<{ok, reason, data}>  reason: nobridge | timeout | failed | incomplete   NEVER rejects
 * Battery temperature: Android reports power_supply "temp" in tenths of a degree Celsius; values outside -30..150 C are rejected.
 */
(function () {
  "use strict";
  var B = "/sys/class/power_supply/battery";
  var SCRIPT = [
    'echo "@@s"',
    "head -n 1 /proc/stat 2>/dev/null",
    "grep -E '^(MemTotal|MemAvailable):' /proc/meminfo 2>/dev/null",
    "for f in capacity temp; do [ -r " + B + "/$f ] && echo \"B:$f=$(cat " + B + "/$f 2>/dev/null)\"; done",
    'echo "@@e"'
  ].join("\n");

  function int(s) { return /^\d{1,15}$/.test(s) ? parseInt(s, 10) : null; }

  function parse(out) {
    var r = { complete: false, cpu: null, mem: null, batt: null }, tk = null, av = null, cap = null, tmp = null, started = false;
    String(out == null ? "" : out).split("\n").forEach(function (raw) {
      var l = raw.replace(/\r/g, "").trim(), m;
      if (l === "@@s") { started = true; return; }
      if (l === "@@e") { r.complete = started; return; }
      if (/^cpu\s/.test(l)) {
        var f = l.split(/\s+/).slice(1, 9).map(int);
        if (f.length >= 5 && f.every(function (x) { return x !== null; })) {
          var total = f.reduce(function (a, b) { return a + b; }, 0);
          r.cpu = { total: total, idle: f[3] + f[4] };            // idle + iowait
        }
      } else if ((m = /^MemTotal:\s+(\d+)\s*kB$/.exec(l))) tk = int(m[1]);
      else if ((m = /^MemAvailable:\s+(\d+)\s*kB$/.exec(l))) av = int(m[1]);
      else if ((m = /^B:capacity=(-?\d+)$/.exec(l))) { var c = parseInt(m[1], 10); if (c >= 0 && c <= 100) cap = c; }
      else if ((m = /^B:temp=(-?\d+)$/.exec(l))) { var t = parseInt(m[1], 10) / 10; if (t >= -30 && t <= 150) tmp = t; }
    });
    if (tk && av !== null && av <= tk) r.mem = { totalKb: tk, availKb: av };
    if (cap !== null || tmp !== null) r.batt = { pct: cap, tempC: tmp };
    return r;
  }

  function cpuPct(prev, cur) {
    if (!prev || !cur) return null;
    var dt = cur.total - prev.total, di = cur.idle - prev.idle;
    if (!(dt > 0) || di < 0 || di > dt) return null;
    return Math.round((1 - di / dt) * 1000) / 10;
  }
  function memPct(mem) {
    if (!mem || !(mem.totalKb > 0)) return null;
    return Math.round((1 - mem.availKb / mem.totalKb) * 1000) / 10;
  }
  function push(arr, v, max) {
    arr.push(typeof v === "number" && isFinite(v) ? v : null);
    while (arr.length > (max || 30)) arr.shift();
    return arr;
  }

  function sample() {
    return new Promise(function (resolve) {
      var MD = window.MD;
      if (!MD || !MD.sh || !MD.bridge || !MD.bridge.available()) return resolve({ ok: false, reason: "nobridge", data: null });
      MD.sh(SCRIPT, { timeout: 6000, persist: true }).then(function (r) {
        if (r.code === -2 || r.code === -3) return resolve({ ok: false, reason: "timeout", data: null });
        var p = parse(r.out);
        if (!p.complete) return resolve({ ok: false, reason: r.code === 0 ? "incomplete" : "failed", data: null });
        resolve({ ok: true, reason: "", data: p });
      }, function () { resolve({ ok: false, reason: "failed", data: null }); });
    });
  }

  window.MDStats = { SCRIPT: SCRIPT, parse: parse, cpuPct: cpuPct, memPct: memPct, push: push, sample: sample };
})();
