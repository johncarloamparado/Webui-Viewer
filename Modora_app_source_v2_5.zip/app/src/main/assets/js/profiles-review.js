/* Modora profile review panel (MB5.2). Classic script. Mounted by js/profiles-view.js under the profile list: MDProfilesReview.mount(parentNode).
 * Flow: [Review changes...] -> reads the device (read-only) -> shows every setting as "now -> new" / "no change" / "skipped (reason)" -> [Apply N changes] or [Cancel].
 * Nothing is written before the person taps Apply. The values shown come from the same Plan object that apply() writes (js/profiles-apply.js).
 * All text via textContent. Requires MDProfilesApply + MDProfiles; shows an honest state when the bridge is missing. Optional: MDI18n.
 */
(function () {
  "use strict";
  function t(k, fb, p) {
    try { if (window.MDI18n) { var s = window.MDI18n.t(k, p); if (s && s !== k) return s; } } catch (e) {}
    return fb.replace(/\{(\w+)\}/g, function (m, n) { return p && p[n] != null ? p[n] : m; });
  }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  var LBL = { REFRESH_HZ: ["prof.k_hz", "Refresh rate"], DISABLE_HWC: ["prof.k_hwc", "Disable HWC overlays"], GOVERNOR: ["prof.k_gov", "CPU governor"], PROP_SF_TIMERS: ["prof.k_sf", "Disable SF refresh timers"],
    PROP_GPU: ["prof.k_gpu", "GPU / composition props"], PROP_MEM: ["prof.k_mem", "Memory props"], MODE: ["prof.k_mode", "ANR popups"], LIMIT: ["prof.k_limit", "Show limit"], WINDOW_MIN: ["prof.k_window", "Window"], TIMEOUT_MULT: ["prof.k_timeout", "Timeout"] };
  var SEC = { rme50: ["prof.sec_rme50", "Display (60Hz & SF)"], anr: ["prof.sec_anr", "ANR limiter"] };
  function val(k, v) {
    if (k === "REFRESH_HZ") return v === "auto" ? t("prof.v_auto", "Auto") : t("prof.v_hz", "{n} Hz", { n: v });
    if (k === "GOVERNOR") return v === "default" ? t("prof.v_stock", "Stock") : v;
    if (k === "MODE") return v === "show" ? t("prof.v_stock", "Stock") : v === "limit" ? t("prof.v_limit", "Limit") : t("prof.v_hide", "Hide");
    if (k === "LIMIT" || k === "TIMEOUT_MULT") return v + "×";
    if (k === "WINDOW_MIN") return t("prof.v_min", "{n} min", { n: v });
    return v === "1" ? t("prof.v_on", "On") : t("prof.v_off", "Off");
  }
  var WHY = { gov: ["papply.skip_gov", "Skipped: this CPU governor is not available on this device"], gov_unknown: ["papply.skip_gov_unknown", "Skipped: the available governors could not be read"],
    hz: ["papply.skip_hz", "Skipped: this panel does not report that refresh rate"], chars: ["papply.skip_chars", "Skipped: the tuner page could not read this value back"] };

  var st = { state: "idle", profileId: null, plan: null, result: null, note: "" }, host = null, focusNext = null;

  function reset(id) { st = { state: "idle", profileId: id || null, plan: null, result: null, note: "" }; }
  function secName(id) { return t(SEC[id][0], SEC[id][1]); }
  function bridgeOk() { return !!(window.MD && window.MD.bridge && window.MD.bridge.available()); }

  function startReview() {
    var P = window.MDProfiles, A = window.MDProfilesApply, id = P && P.selected();
    if (!A || !id || st.state === "loading" || st.state === "applying") return;
    st = { state: "loading", profileId: id, plan: null, result: null, note: st.note };
    focusNext = "title"; draw();
    A.plan(id).then(function (pl) {
      if (st.state !== "loading" || st.profileId !== id) return;
      st.plan = pl; st.state = pl.ok ? "ready" : "error"; focusNext = "title"; draw();
    });
  }
  function doApply() {
    var A = window.MDProfilesApply;
    if (!A || st.state !== "ready" || !st.plan || !st.plan.changes) return;
    var pl = st.plan; st.state = "applying"; st.note = ""; focusNext = "title"; draw();
    A.apply(pl).then(function (r) {
      if (r.stale && r.plan && r.plan.ok) { st = { state: "ready", profileId: st.profileId, plan: r.plan, result: null, note: t("papply.stale", "Your settings changed while you were reviewing. Check the updated changes below.") }; }
      else if (r.reason === "busy") { st.state = "ready"; st.note = t("papply.busy", "Another apply is still running."); }
      else if (r.sections) { st.state = "done"; st.result = r; }
      else { st.state = "error"; st.plan = r.plan && r.plan.ok === false ? r.plan : { ok: false, reason: r.reason || "error" }; }
      focusNext = "title"; draw();
    });
  }
  function cancel() { if (st.state === "applying" || st.state === "loading") return; var id = st.profileId; reset(id); focusNext = "review"; draw(); }

  function errText(reason) {
    if (reason === "nobridge") return t("papply.nobridge", "Open Modora inside the app to review and apply profiles.");
    if (reason === "noroot") return t("papply.noroot", "Could not reach root, so nothing was read or changed.");
    return t("papply.err", "Could not read your current settings. Nothing was changed.");
  }
  function rowsView(s) {
    var ul = el("ul", "md-diff-rows");
    s.rows.forEach(function (r) {
      var li = el("li", "md-diff-row is-" + r.status), lab = t(LBL[r.key][0], LBL[r.key][1]);
      li.appendChild(el("span", "md-diff-k", lab));
      var v = el("span", "md-diff-v");
      if (r.status === "change") { v.appendChild(el("s", "", val(r.key, r.from))); v.appendChild(document.createTextNode(" → ")); v.appendChild(el("b", "", val(r.key, r.to))); if (r.reboot) v.appendChild(el("em", "md-diff-tag", t("papply.reboot_tag", "Reboot"))); }
      else if (r.status === "same") { v.appendChild(el("b", "", val(r.key, r.from))); v.appendChild(el("em", "md-diff-tag", t("papply.same", "No change"))); }
      else { v.appendChild(el("b", "", val(r.key, r.from))); v.appendChild(el("em", "md-diff-tag md-diff-skip", t("papply.skipped", "Skipped"))); }
      li.appendChild(v);
      if (r.status === "skip" && WHY[r.why]) li.appendChild(el("small", "md-diff-why", t(WHY[r.why][0], WHY[r.why][1])));
      ul.appendChild(li);
    });
    return ul;
  }
  function resText(r) {
    var n = secName(r.id);
    if (r.state === "applied") return t("papply.res_ok", "{section}: applied and verified.", { section: n });
    if (r.state === "skipped") return t("papply.res_skipped", "{section}: nothing to change.", { section: n });
    if (r.state === "write_failed") return t("papply.res_write", "{section}: could not write the config (exit {code}). Nothing changed.", { section: n, code: r.code }) + (r.err ? " " + r.err : "");
    if (r.state === "apply_failed") return t("papply.res_apply", "{section}: the config was saved, but the module's apply step failed (exit {code}). A reboot may be needed.", { section: n, code: r.code }) + (r.err ? " " + r.err : "");
    if (r.state === "mismatch") return t("papply.res_mismatch", "{section}: the saved config does not match the preview. Check the tuner page.", { section: n });
    return t("papply.res_unverified", "{section}: the command ran, but the saved config could not be read back. Check the tuner page.", { section: n });
  }

  function draw() {
    if (!host) return;
    host.textContent = "";
    var P = window.MDProfiles, sel = P && P.selected(), p = sel && P.get(sel);
    if (st.state === "idle") {
      if (!p) return;
      var row = el("div", "md-diff-start");
      row.appendChild(el("p", "md-prof-note", t("papply.hint", "See exactly what would change on your device before anything is written.")));
      var b = el("button", "md-btn md-btn-sm", t("papply.review", "Review changes…")); b.type = "button"; b.setAttribute("data-papply", "review");
      if (!bridgeOk() || !window.MDProfilesApply) b.disabled = true;
      row.appendChild(b);
      if (!bridgeOk()) row.appendChild(el("p", "md-prof-note", t("papply.nobridge", "Open Modora inside the app to review and apply profiles.")));
      if (st.note) { var n0 = el("p", "md-prof-note", st.note); n0.setAttribute("role", "status"); row.appendChild(n0); }
      host.appendChild(row);
    } else {
      var card = el("section", "md-diff md-card"); card.setAttribute("aria-label", t("papply.title", "Review: {name}", { name: (st.plan && st.plan.name) || (p && p.name) || "" }));
      var h = el("h2", "md-diff-title", t("papply.title", "Review: {name}", { name: (st.plan && st.plan.name) || (p && p.name) || "" })); h.tabIndex = -1; h.setAttribute("data-papply-title", "1"); card.appendChild(h);
      var bar = el("div", "md-diff-bar");
      if (st.state === "loading" || st.state === "applying") {
        var s0 = el("p", "md-prof-note", st.state === "loading" ? t("papply.loading", "Reading your current settings…") : t("papply.applying", "Applying…")); s0.setAttribute("role", "status"); card.appendChild(s0);
      } else if (st.state === "error") {
        var e1 = el("div", "md-banner md-banner-danger"); e1.setAttribute("role", "alert"); var eb = el("div", "md-banner-body"); eb.appendChild(el("p", "md-banner-title", errText(st.plan && st.plan.reason))); e1.appendChild(eb); card.appendChild(e1);
        var rt = el("button", "md-btn md-btn-sm", t("common.retry", "Retry")); rt.type = "button"; rt.setAttribute("data-papply", "review"); var cl = el("button", "md-btn md-btn-sm", t("common.close", "Close")); cl.type = "button"; cl.setAttribute("data-papply", "cancel");
        bar.appendChild(rt); bar.appendChild(cl);
      } else if (st.state === "ready") {
        if (st.note) { var n1 = el("div", "md-banner md-banner-warn"); n1.setAttribute("role", "status"); var nb = el("div", "md-banner-body"); nb.appendChild(el("p", "md-banner-title", st.note)); n1.appendChild(nb); card.appendChild(n1); }
        st.plan.sections.forEach(function (s) {
          card.appendChild(el("h3", "md-diff-sec", secName(s.id)));
          if (s.state === "module_missing") { card.appendChild(el("p", "md-prof-note", t("papply.mod_missing", "The {section} module is not installed (apply.sh not found), so this part is skipped.", { section: secName(s.id) }))); return; }
          card.appendChild(rowsView(s));
        });
        var pl = st.plan;
        if (!pl.changes) card.appendChild(el("p", "md-prof-note", t("papply.nothing", "Nothing to change: your device already matches this profile, or the differing settings are skipped.")));
        else if (pl.reboot) card.appendChild(el("p", "md-prof-note", t("papply.reboot_note", "Settings tagged Reboot only take effect after you restart your device.")));
        var ap = el("button", "md-btn md-btn-gradient md-btn-sm", t("papply.apply", "Apply {n} changes", { n: pl.changes })); ap.type = "button"; ap.setAttribute("data-papply", "apply"); ap.disabled = !pl.changes;
        var cn = el("button", "md-btn md-btn-sm", t("common.cancel", "Cancel")); cn.type = "button"; cn.setAttribute("data-papply", "cancel");
        bar.appendChild(ap); bar.appendChild(cn);
      } else if (st.state === "done") {
        var r = st.result, ok = r.ok, bn = el("div", "md-banner " + (ok ? "md-banner-ok" : "md-banner-warn")); bn.setAttribute("role", "status");
        var bb = el("div", "md-banner-body"); bb.appendChild(el("p", "md-banner-title", ok ? t("papply.all_ok", "Profile applied.") : t("papply.some_failed", "Not everything was applied. Details below."))); bn.appendChild(bb); card.appendChild(bn);
        var ul = el("ul", "md-diff-res"); r.sections.forEach(function (x) { ul.appendChild(el("li", "is-" + x.state, resText(x))); }); card.appendChild(ul);
        if (r.reboot) card.appendChild(el("p", "md-prof-note", t("papply.reboot_needed", "Restart your device for the Reboot-tagged settings to take effect.")));
        var dn = el("button", "md-btn md-btn-sm", t("papply.done", "Done")); dn.type = "button"; dn.setAttribute("data-papply", "cancel"); bar.appendChild(dn);
      }
      if (bar.childNodes.length) card.appendChild(bar);
      host.appendChild(card);
    }
    if (focusNext) {
      var f = focusNext === "title" ? host.querySelector("[data-papply-title]") : host.querySelector('[data-papply="review"]');
      focusNext = null; if (f) try { f.focus(); } catch (e) {}
    }
  }

  function mount(parent) {
    var P = window.MDProfiles, sel = P && P.selected();
    if (st.state !== "applying" && st.state !== "loading" && st.profileId !== sel) reset(sel);   /* a running job keeps its panel; any other state belongs to one profile */
    host = el("div", "md-prof-review");
    host.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-papply]") : null; if (!b || b.disabled) return;
      var a = b.getAttribute("data-papply");
      if (a === "review") startReview(); else if (a === "apply") doApply(); else if (a === "cancel") cancel();
    });
    parent.appendChild(host); draw(); return host;
  }
  window.MDProfilesReview = { mount: mount, state: function () { return st.state; },
    _ui: { rowsView: rowsView, secName: secName, resText: resText, errText: errText } };   /* MB5.3: shared diff rendering for the restore panel */
})();
