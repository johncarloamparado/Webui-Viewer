/* Modora tags view (MB6.3a). Classic script (<script defer>), no modules. Requires js/tags.js (MDTags). All text via textContent.
 *   MDTagsView.chips(id)                     -> <div class="md-tags"> with read-only chips, or null when the module has no tags
 *   MDTagsView.editor(box, id, opts)         -> fills box with the editor for one module: removable chips, text field + Add, suggestions
 *       opts.onChange() called after every successful add/remove (the page redraws its list)
 *   MDTagsView.filter(box, state)            -> fills box with one filter chip per tag in use; state = {ids, active, onPick(tag|"")}
 *       (box is hidden when no module has tags). active = currently selected tag or "".
 * No native/root access. If MDTags is missing every function degrades to doing nothing / returning null.
 */
(function () {
  "use strict";
  function T(k, fb, p) {
    try { if (window.MDI18n) { var s = window.MDI18n.t(k, p); if (s && s !== k) return s; } } catch (e) {}
    return fb.replace(/\{(\w+)\}/g, function (m, n) { return p && p[n] != null ? p[n] : m; });
  }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function ok() { return !!window.MDTags; }

  function chips(id) {
    if (!ok()) return null;
    var l = window.MDTags.get(id);
    if (!l.length) return null;
    var w = el("div", "md-tags");
    l.forEach(function (t) { w.appendChild(el("span", "md-tag", t)); });
    return w;
  }

  function reasonText(r) {
    return { empty: T("tags.err_empty", "Type a tag first."), dup: T("tags.err_dup", "That tag is already on this module."),
      limit: T("tags.err_limit", "A module can have up to {n} tags.", { n: window.MDTags.MAX_TAGS }), invalid: T("tags.err_invalid", "Can't tag this module.") }[r] || "";
  }

  function editor(box, id, opts) {
    if (!box) return;
    box.textContent = "";
    if (!ok()) return;
    var M = window.MDTags, onChange = opts && typeof opts.onChange === "function" ? opts.onChange : function () {};
    var head = el("div", "md-tags-h", T("tags.title", "Tags"));
    var list = el("div", "md-tags"); list.setAttribute("role", "list");
    var row = el("div", "md-tags-add");
    var inp = el("input"); inp.type = "text"; inp.maxLength = M.MAX_LEN; inp.autocomplete = "off";
    inp.placeholder = T("tags.placeholder", "Add a tag…"); inp.setAttribute("aria-label", T("tags.add_aria", "New tag"));
    var btn = el("button", "ghost", T("tags.add", "Add")); btn.type = "button";
    var msg = el("p", "md-tags-msg"); msg.setAttribute("role", "status");
    var sug = el("div", "md-tags sug");
    row.appendChild(inp); row.appendChild(btn);
    box.appendChild(head); box.appendChild(list); box.appendChild(row); box.appendChild(msg); box.appendChild(sug);

    function paint() {
      list.textContent = ""; sug.textContent = "";
      var mine = M.get(id);
      if (!mine.length) list.appendChild(el("span", "md-tags-none", T("tags.none", "No tags yet.")));
      mine.forEach(function (t) {
        var c = el("span", "md-tag"); c.setAttribute("role", "listitem");
        c.appendChild(document.createTextNode(t));
        var x = el("button", "md-tag-x", "✕"); x.type = "button";
        x.setAttribute("aria-label", T("tags.remove_aria", "Remove tag {tag}", { tag: t }));
        x.addEventListener("click", function () { if (M.remove(id, t)) { msg.textContent = ""; paint(); onChange(); } });
        c.appendChild(x); list.appendChild(c);
      });
      var others = M.all().filter(function (o) { return mine.indexOf(o.tag) < 0; }).slice(0, 8);
      if (others.length && mine.length < M.MAX_TAGS) {
        sug.appendChild(el("span", "md-tags-sugl", T("tags.suggest", "Used elsewhere:")));
        others.forEach(function (o) {
          var b = el("button", "md-tag sug-b", o.tag); b.type = "button";
          b.setAttribute("aria-label", T("tags.use_aria", "Add tag {tag}", { tag: o.tag }));
          b.addEventListener("click", function () { submit(o.tag); });
          sug.appendChild(b);
        });
      }
    }
    function submit(raw) {
      var r = M.add(id, raw);
      if (!r.ok) { msg.textContent = reasonText(r.reason); return; }
      inp.value = ""; msg.textContent = r.reason === "storage" ? T("tags.mem_only", "Saved for this session only: storage is unavailable.") : "";
      paint(); onChange();
    }
    btn.addEventListener("click", function () { submit(inp.value); });
    inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); submit(inp.value); } });
    paint();
  }

  function filter(box, state) {
    if (!box) return;
    box.textContent = "";
    var tags = ok() ? window.MDTags.all(state && state.ids) : [];
    if (!tags.length) { box.hidden = true; return; }
    box.hidden = false;
    var active = state && state.active || "";
    tags.forEach(function (o) {
      var b = el("button", active === o.tag ? "on" : "", o.tag + " · " + o.count); b.type = "button"; b.dataset.mtag = o.tag;
      b.setAttribute("aria-pressed", active === o.tag ? "true" : "false");
      b.addEventListener("click", function () { if (state && typeof state.onPick === "function") state.onPick(active === o.tag ? "" : o.tag); });
      box.appendChild(b);
    });
  }

  window.MDTagsView = { chips: chips, editor: editor, filter: filter };
})();
