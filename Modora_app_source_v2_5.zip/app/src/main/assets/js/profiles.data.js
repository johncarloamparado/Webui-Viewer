/* Modora built-in profiles (MB5.1). GENERATED COPY of profiles.json (source of truth).
 * Why a .js copy: fetch/XHR of a .json file is blocked from file:// pages. Keep both in sync (a test compares them).
 * Values come only from settings the app already supports: rme50 (js/rme50.js presets) and anr (js/anr.js presets).
 */
window.MD_PROFILES_DATA = {
 "version": 1,
 "profiles": [
  {
   "id": "codm60",
   "name": "🎯 CODM 60",
   "desc": "60 Hz lock, all display tweaks, performance CPU, recommended ANR popup limit.",
   "rme50": {
    "REFRESH_HZ": "60",
    "DISABLE_HWC": "1",
    "GOVERNOR": "performance",
    "PROP_SF_TIMERS": "1",
    "PROP_GPU": "1",
    "PROP_MEM": "1"
   },
   "anr": {
    "MODE": "limit",
    "LIMIT": "3",
    "WINDOW_MIN": "10",
    "TIMEOUT_MULT": "2"
   }
  },
  {
   "id": "codm90",
   "name": "⚡ CODM 90",
   "desc": "90 Hz lock, GPU composition left normal, performance CPU, recommended ANR popup limit.",
   "rme50": {
    "REFRESH_HZ": "90",
    "DISABLE_HWC": "0",
    "GOVERNOR": "performance",
    "PROP_SF_TIMERS": "1",
    "PROP_GPU": "1",
    "PROP_MEM": "1"
   },
   "anr": {
    "MODE": "limit",
    "LIMIT": "3",
    "WINDOW_MIN": "10",
    "TIMEOUT_MULT": "2"
   }
  },
  {
   "id": "balanced",
   "name": "⚖️ Balanced",
   "desc": "60 Hz lock, stock CPU governor, cooler. Gentle ANR popup limit.",
   "rme50": {
    "REFRESH_HZ": "60",
    "DISABLE_HWC": "0",
    "GOVERNOR": "default",
    "PROP_SF_TIMERS": "1",
    "PROP_GPU": "1",
    "PROP_MEM": "0"
   },
   "anr": {
    "MODE": "limit",
    "LIMIT": "5",
    "WINDOW_MIN": "5",
    "TIMEOUT_MULT": "1"
   }
  },
  {
   "id": "stock",
   "name": "↩️ Stock",
   "desc": "Everything off, the system decides. Android default ANR behaviour.",
   "rme50": {
    "REFRESH_HZ": "auto",
    "DISABLE_HWC": "0",
    "GOVERNOR": "default",
    "PROP_SF_TIMERS": "0",
    "PROP_GPU": "0",
    "PROP_MEM": "0"
   },
   "anr": {
    "MODE": "show",
    "LIMIT": "3",
    "WINDOW_MIN": "10",
    "TIMEOUT_MULT": "1"
   }
  }
 ]
};
