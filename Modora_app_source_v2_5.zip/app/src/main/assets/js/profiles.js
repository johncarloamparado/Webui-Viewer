/* Modora profiles data + selection (MB5.1). Classic script (<script defer>), no modules.
 * A profile is a named bundle of settings the app ALREADY supports: section "rme50" (REFRESH_HZ, DISABLE_HWC, GOVERNOR, PROP_SF_TIMERS, PROP_GPU, PROP_MEM)
 * and/or section "anr" (MODE, LIMIT, WINDOW_MIN, TIMEOUT_MULT). Key names and value rules mirror js/rme50.js and js/anr.js.
 * THIS BATCH ONLY VALIDATES, LISTS AND REMEMBERS THE SELECTION. It never touches the device; applying is MB5.2.
 * Data: window.MD_PROFILES_DATA (js/profiles.data.js, copy of profiles.json). Anything invalid is dropped, never thrown; if nothing valid is left a built-in
 * Stock profile is used so the list is never empty. Selection key "md.profile" (localStorage, memory fallback); unknown/invalid id reads back as null.
 * API: MDProfiles.validate(data) -> {profiles, dropped, reasons[]}   .list()   .get(id)   .selected() -> id|null   .select(id) -> bool   .clear()
 *      .status() -> {source:"data"|"fallback", dropped, reasons[]}   .summary(profile) -> [{section, rows:[[key,rawValue]]}]   .onChange(fn) -> unsubscribe
 *      .reload() (re-reads window.MD_PROFILES_DATA)   .SCHEMA (allowed keys + rules; MB5.2 must reuse it)
 */
(function () {
  "use strict";
  var KEY = "md.profile", MAXP = 20, ID_RE = /^[a-z0-9_-]{1,32}$/, mem = null, listeners = [];
  var bool = function (v) { return v === "0" || v === "1" ? v : null; };
  var intIn = function (a, b) { return function (v) { return /^\d{1,3}$/.test(v) && +v >= a && +v <= b ? String(+v) : null; }; };
  var SCHEMA = {
    rme50: { REFRESH_HZ: function (v) { return v === "auto" ? v : intIn(30, 240)(v); }, DISABLE_HWC: bool, GOVERNOR: function (v) { return /^[A-Za-z0-9_.-]{1,32}$/.test(v) ? v : null; },
             PROP_SF_TIMERS: bool, PROP_GPU: bool, PROP_MEM: bool },
    anr:   { MODE: function (v) { return v === "show" || v === "limit" || v === "hide" ? v : null; }, LIMIT: intIn(1, 20), WINDOW_MIN: intIn(1, 120), TIMEOUT_MULT: intIn(1, 4) }
  };
  var FALLBACK = { id: "stock", name: "Stock", desc: "Everything off, the system decides. Android default ANR behaviour.",
    rme50: { REFRESH_HZ: "auto", DISABLE_HWC: "0", GOVERNOR: "default", PROP_SF_TIMERS: "0", PROP_GPU: "0", PROP_MEM: "0" },
    anr: { MODE: "show", LIMIT: "3", WINDOW_MIN: "10", TIMEOUT_MULT: "1" } };
  var profiles = [], info = { source: "fallback", dropped: 0, reasons: [] };

  function str(v, max) { return typeof v === "string" ? v.replace(/[\u0000-\u001f\u007f]/g, "").trim().slice(0, max) : ""; }
  function section(raw, rules, why) {
    if (raw == null) return null;
    if (typeof raw !== "object" || Array.isArray(raw)) { why.push("section not an object"); return null; }
    var out = {}, n = 0;
    Object.keys(raw).forEach(function (k) {
      if (!Object.prototype.hasOwnProperty.call(rules, k)) { why.push("unknown key " + String(k).slice(0, 20)); return; }
      var v = typeof raw[k] === "number" ? String(raw[k]) : raw[k], c = typeof v === "string" ? rules[k](v) : null;
      if (c === null) why.push("bad value for " + k); else { out[k] = c; n++; }
    });
    return n ? out : null;
  }
  function validate(data) {
    var res = { profiles: [], dropped: 0, reasons: [] }, seen = Object.create(null);
    if (!data || typeof data !== "object" || data.version !== 1 || !Array.isArray(data.profiles)) { res.reasons.push("bad data"); res.dropped = 1; return res; }
    data.profiles.slice(0, MAXP + 50).forEach(function (p, i) {
      var why = [];
      if (res.profiles.length >= MAXP) { res.dropped++; res.reasons.push("#" + i + " too many profiles"); return; }
      if (!p || typeof p !== "object" || !ID_RE.test(p.id || "") || seen[p.id]) { res.dropped++; res.reasons.push("#" + i + " bad or duplicate id"); return; }
      var name = str(p.name, 40); if (!name) { res.dropped++; res.reasons.push(p.id + " no name"); return; }
      var r = section(p.rme50, SCHEMA.rme50, why), a = section(p.anr, SCHEMA.anr, why);
      if (!r && !a) { res.dropped++; res.reasons.push(p.id + " no valid settings"); return; }
      if (why.length) res.reasons.push(p.id + ": " + why.join(", "));          /* invalid settings are removed, the rest of the profile is kept */
      var o = { id: p.id, name: name, desc: str(p.desc, 140) }; if (r) o.rme50 = r; if (a) o.anr = a;
      seen[p.id] = 1; res.profiles.push(o);
    });
    return res;
  }
  function reload() {
    var v; try { v = validate(window.MD_PROFILES_DATA); } catch (e) { v = { profiles: [], dropped: 1, reasons: ["exception"] }; }
    if (v.profiles.length) { profiles = v.profiles; info = { source: "data", dropped: v.dropped, reasons: v.reasons }; }
    else { profiles = [FALLBACK]; info = { source: "fallback", dropped: v.dropped, reasons: v.reasons }; }
    if (selected() === null && read()) write(null);                            /* stored id no longer exists */
  }
  function read() { if (mem !== null) return mem || null; try { return window.localStorage.getItem(KEY); } catch (e) { return null; } }
  function write(v) { try { if (v == null) window.localStorage.removeItem(KEY); else window.localStorage.setItem(KEY, v); mem = null; } catch (e) { mem = v == null ? "" : v; } }
  function get(id) { for (var i = 0; i < profiles.length; i++) if (profiles[i].id === id) return profiles[i]; return null; }
  function selected() { var v = read(); return v && get(v) ? v : null; }
  function emit() { listeners.slice().forEach(function (f) { try { f(selected()); } catch (e) {} }); }
  function select(id) { if (typeof id !== "string" || !get(id)) return false; if (selected() !== id) { write(id); emit(); } return true; }
  function clear() { if (selected() !== null || read()) { write(null); emit(); } }
  var ORDER = { rme50: ["REFRESH_HZ", "DISABLE_HWC", "GOVERNOR", "PROP_SF_TIMERS", "PROP_GPU", "PROP_MEM"], anr: ["MODE", "LIMIT", "WINDOW_MIN", "TIMEOUT_MULT"] };
  function summary(p) {
    var out = [];
    ["rme50", "anr"].forEach(function (s) {
      if (!p || !p[s]) return;
      out.push({ section: s, rows: ORDER[s].filter(function (k) { return p[s][k] != null; }).map(function (k) { return [k, p[s][k]]; }) });
    });
    return out;
  }
  window.MDProfiles = {
    validate: validate, list: function () { return profiles.slice(); }, get: get, selected: selected, select: select, clear: clear, reload: reload, summary: summary,
    status: function () { return { source: info.source, dropped: info.dropped, reasons: info.reasons.slice() }; }, SCHEMA: SCHEMA,
    onChange: function (f) { if (typeof f !== "function") return function () {}; listeners.push(f); return function () { var i = listeners.indexOf(f); if (i >= 0) listeners.splice(i, 1); }; }
  };
  reload();
})();
