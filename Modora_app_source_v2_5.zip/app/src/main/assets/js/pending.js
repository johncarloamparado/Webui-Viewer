/* Modora pending-reboot tracker (MB2.5). Classic script (<script defer>), no modules.
 * Enable/disable of a module only takes effect at the next boot, so every VERIFIED toggle is recorded here as {from, to, at}.
 * An entry is dropped when: the module is toggled back to its original state, the device has booted since the change
 * (boot time = now - /proc/uptime via MD.sh), or a live scan shows the module in a different state / gone (see reconcile()).
 * Only called from code paths that already verified the flag file (MDMods). Own localStorage key "md.pending" (memory fallback).
 * API: MDPending.note(id, from, to) -> bool   .list() -> [{id,from,to,at}] (sanitized)   .count()   .clear()
 *      .prune() -> Promise<{booted:number|0, dropped:number}>   (NEVER rejects; boot time unknown -> nothing dropped)
 *      .reconcile(modules[{id,e}]) -> dropped   (live scan data only)   .parseUptime(out) -> seconds|0 (pure)
 */
(function () {
  "use strict";
  var MD = (window.MD = window.MD || {});
  var KEY = "md.pending", VER = 1, MAXN = 300, ID_RE = /^[A-Za-z0-9._-]+$/, mem = null;

  function raw() { if (mem !== null) return mem; try { return window.localStorage.getItem(KEY); } catch (e) { return null; } }
  function load() {
    var o = {}, c;
    try { c = JSON.parse(raw() || "null"); } catch (e) { c = null; }
    if (!c || c.v !== VER || !c.items || typeof c.items !== "object") return o;
    Object.keys(c.items).slice(0, MAXN).forEach(function (id) {
      var x = c.items[id];
      if (ID_RE.test(id) && id.length <= 120 && x && typeof x.from === "boolean" && typeof x.to === "boolean" && x.from !== x.to &&
          typeof x.at === "number" && isFinite(x.at) && x.at > 0 && x.at <= Date.now() + 864e5) o[id] = { from: x.from, to: x.to, at: x.at };
    });
    return o;
  }
  function save(o) {
    var s = JSON.stringify({ v: VER, items: o });
    try { window.localStorage.setItem(KEY, s); mem = null; } catch (e) { mem = s; }
  }

  function note(id, from, to) {
    if (typeof id !== "string" || !ID_RE.test(id) || id.length > 120 || typeof from !== "boolean" || typeof to !== "boolean") return false;
    var o = load(), e = o[id];
    if (e) { if (e.from === to) delete o[id]; else o[id] = { from: e.from, to: to, at: Date.now() }; }
    else if (from !== to) o[id] = { from: from, to: to, at: Date.now() };
    save(o); return true;
  }
  function list() { var o = load(); return Object.keys(o).map(function (id) { return { id: id, from: o[id].from, to: o[id].to, at: o[id].at }; }).sort(function (a, b) { return a.at - b.at; }); }
  function count() { return list().length; }
  function clear() { mem = null; try { window.localStorage.removeItem(KEY); } catch (e) {} }

  function parseUptime(out) { var m = String(out == null ? "" : out).match(/^\s*(\d+(?:\.\d+)?)\s/); var v = m ? parseFloat(m[1]) : 0; return v > 0 && isFinite(v) ? v : 0; }

  function prune() {
    return new Promise(function (resolve) {
      var done = function (b, d) { resolve({ booted: b, dropped: d }); };
      if (!count()) return done(0, 0);
      if (!MD.sh || !MD.bridge || !MD.bridge.available()) return done(0, 0);
      var t0 = Date.now();
      MD.sh("cat /proc/uptime", { timeout: 5000 }).then(function (r) {
        var up = r.code === 0 ? parseUptime(r.out) : 0;
        if (!up) return done(0, 0);
        var bootAt = t0 - up * 1000, o = load(), dropped = 0;
        Object.keys(o).forEach(function (id) { if (o[id].at < bootAt) { delete o[id]; dropped++; } });
        if (dropped) save(o);
        done(bootAt, dropped);
      }, function () { done(0, 0); });
    });
  }

  function reconcile(mods) {
    var o = load(), dropped = 0, st = {};
    (mods || []).forEach(function (m) { if (m && typeof m.id === "string") st[m.id] = m.e === true; });
    Object.keys(o).forEach(function (id) { if (!(id in st) || st[id] !== o[id].to) { delete o[id]; dropped++; } });
    if (dropped) save(o);
    return dropped;
  }

  window.MDPending = { note: note, list: list, count: count, clear: clear, prune: prune, reconcile: reconcile, parseUptime: parseUptime };
})();
