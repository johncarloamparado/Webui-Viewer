/* Modora RME50 tuner page logic (MB3.2) - classic script, loaded at the end of rme50.html.
 * Everything below is the legacy v2.4/MB2.x script moved out of the HTML UNCHANGED, except:
 *  - inline onclick handlers (generated and static) replaced by data-* attributes + the listeners at the bottom;
 *  - the three templates in renderHz()/render() use the new .md-* class names (same data, same order, same data-k keys).
 * Commands, config keys, config text, defaults, presets, option texts and status/log parsing are untouched
 * (verified against the original page with a fake bridge: identical ksu.exec call sequences and DOM text). */
const ID='rme50_60hz_sf_fix',DIR='/data/adb/'+ID,CFG=DIR+'/config.conf',MOD='/data/adb/modules/'+ID,LOG='/data/local/tmp/'+ID+'.log';
const DEF={REFRESH_HZ:'60',DISABLE_HWC:'1',GOVERNOR:'performance',PROP_SF_TIMERS:'1',PROP_GPU:'1',PROP_MEM:'1'};
let cfg={...DEF},modes=[60,90];
const HZX={auto:'The system chooses between modes. Smoothest for scrolling, but frame pacing in games can vary.',
60:'Recommended for CODM at 60 FPS. Every frame gets exactly 16.7 ms, no mode switching, lowest heat.',
90:'Only useful if your game really renders 90 FPS. Each frame has just 11.1 ms, so heavy smoke and explosions will drop frames more easily.'};
const PRE=[
{n:'🎯 CODM 60',d:'60Hz lock, all tweaks, performance CPU',c:{REFRESH_HZ:'60',DISABLE_HWC:'1',GOVERNOR:'performance',PROP_SF_TIMERS:'1',PROP_GPU:'1',PROP_MEM:'1'}},
{n:'⚡ CODM 90',d:'90Hz lock, GPU composition left normal',c:{REFRESH_HZ:'90',DISABLE_HWC:'0',GOVERNOR:'performance',PROP_SF_TIMERS:'1',PROP_GPU:'1',PROP_MEM:'1'}},
{n:'⚖️ Balanced 60',d:'60Hz lock, stock CPU governor, cooler',c:{REFRESH_HZ:'60',DISABLE_HWC:'0',GOVERNOR:'default',PROP_SF_TIMERS:'1',PROP_GPU:'1',PROP_MEM:'0'}},
{n:'↩️ Stock',d:'Everything off, system decides',c:{REFRESH_HZ:'auto',DISABLE_HWC:'0',GOVERNOR:'default',PROP_SF_TIMERS:'0',PROP_GPU:'0',PROP_MEM:'0'}}];
const OPTS=[
{k:'DISABLE_HWC',t:'Disable HWC overlays',live:1,s:'Composites every layer on the GPU instead of the display hardware.',d:'Sends SurfaceFlinger debug call 1008. Avoids switching between overlay and GPU composition when many transparent layers appear. Resets on reboot and is re-applied at boot.',r:'The Mali-G57 does all compositing, which adds GPU load. In a GPU-bound game this can make lag WORSE. Test on and off.'},
{k:'PROP_SF_TIMERS',t:'Disable SF refresh timers',live:0,s:'Stops SurfaceFlinger lowering refresh on touch/idle/power events.',d:'Sets set_touch_timer_ms, set_display_power_timer_ms and set_idle_timer_ms to 0 at boot, so idle logic cannot override your lock.',r:'Slightly higher idle power use. Reboot required.'},
{k:'PROP_GPU',t:'GPU / composition props',live:0,s:'Hardware rendering flags, unsignaled buffer latching, UBWC.',d:'debug.egl.hw, debug.sf.hw, latch_unsignaled=1 (present buffers before the GPU fence signals), client composition cache on, UBWC compression on (saves memory bandwidth).',r:'Several are already default on modern Android, so gains may be small. Rarely, latch_unsignaled causes visual glitches. Reboot required.'},
{k:'PROP_MEM',t:'Memory props',live:0,s:'Marks the device as not low-RAM; LMK stops killing the heaviest app first.',d:'ro.config.low_ram=false and ro.lmk.kill_heaviest_task=false.',r:'On 4GB RAM a heavy game plus background apps can cause memory pressure. Disable if apps reload often. Reboot required.'}];
const $=s=>document.querySelector(s),hasKsu=typeof ksu!=='undefined';
function sh(c){return new Promise(r=>{const n='cb_'+Date.now()+Math.random().toString(36).slice(2);
window[n]=(e,o,er)=>{delete window[n];r({code:e,out:o||'',err:er||''})};
try{ksu.exec(c,'{}',n)}catch(x){delete window[n];r({code:-1,out:'',err:String(x)})}})}
function toast(m){const t=$('#toast');t.textContent=m;t.style.opacity=1;setTimeout(()=>t.style.opacity=0,1800)}
function renderHz(){const l=['auto',...modes];if(cfg.REFRESH_HZ!=='auto'&&!modes.includes(+cfg.REFRESH_HZ))l.push(cfg.REFRESH_HZ);
$('#seg').innerHTML=l.map(h=>`<button type="button" class="md-hz${cfg.REFRESH_HZ==h?' on':''}" data-hz="${h}" aria-pressed="${cfg.REFRESH_HZ==h}">${h==='auto'?'Auto':h}<small>${h==='auto'?'system':'Hz lock'}</small></button>`).join('');
$('#hzx').textContent=HZX[cfg.REFRESH_HZ]||'Locks the screen to a fixed '+cfg.REFRESH_HZ+'Hz.';
$('#modes').textContent='Detected panel modes: '+modes.join(', ')+' Hz'}
function setHz(h){cfg.REFRESH_HZ=h;renderHz()}
function render(){renderHz();
$('#pre').innerHTML=PRE.map((p,i)=>`<button type="button" class="md-card md-card-interactive md-preset" data-preset="${i}"><b>${p.n}</b><span>${p.d}</span></button>`).join('');
$('#opts').innerHTML=OPTS.map(o=>`<div class="md-card"><div class="md-between"><div><b>${o.t}</b><span class="md-badge ${o.live?'md-badge-ok':'md-badge-warn'} md-tag">${o.live?'Instant':'Reboot'}</span></div><label class="md-switch"><input type="checkbox" class="md-switch-input" data-k="${o.k}" aria-label="${o.t}" ${cfg[o.k]==='1'?'checked':''}><span class="md-switch-track"></span></label></div><p class="md-x">${o.s}</p><details><summary>Details &amp; risks</summary><p class="md-x">${o.d}</p><p class="md-x md-risk">⚠ ${o.r}</p></details></div>`).join('');
document.querySelectorAll('input[data-k]').forEach(i=>i.onchange=()=>cfg[i.dataset.k]=i.checked?'1':'0');
const s=$('#gov');if(s.options.length)s.value=cfg.GOVERNOR}
function preset(i){Object.assign(cfg,PRE[i].c);render();toast(PRE[i].n+' loaded: press Save & apply')}
async function probe(){let r=await sh('cat /sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors');
const l=['default',...r.out.trim().split(/\s+/).filter(x=>/^[A-Za-z0-9_-]+$/.test(x))];
const s=$('#gov');s.innerHTML=l.map(g=>`<option>${g}</option>`).join('');s.onchange=()=>cfg.GOVERNOR=s.value;s.value=cfg.GOVERNOR;
r=await sh('dumpsys display | grep -oE "fps=[0-9]+(\\.[0-9]+)?" | sort -u');
const m=[...new Set(r.out.split('\n').map(x=>Math.round(parseFloat(x.split('=')[1]))).filter(x=>x>=24&&x<=165))].sort((a,b)=>a-b);
if(m.length)modes=m;renderHz()}
async function load(){const r=await sh(`cat ${CFG} 2>/dev/null`);
r.out.split('\n').forEach(l=>{const m=l.match(/^([A-Z0-9_]+)=([A-Za-z0-9_-]+)$/);if(m&&m[1] in DEF)cfg[m[1]]=m[2]});render();await probe();render()}
async function save(apply){const b=Object.entries(cfg).map(([k,v])=>`${k}=${v}`).join('\n');
if(!hasKsu)return toast('No root bridge');
await sh(`mkdir -p ${DIR}; printf '%s\\n' '${b}' > ${CFG}`);
if(apply){await sh(`sh ${MOD}/apply.sh`);toast('Saved & applied')}else toast('Saved (reboot for props)');
status();logs()}
async function status(){const r=await sh(`for p in /sys/devices/system/cpu/cpufreq/policy*; do echo "\${p##*/}: $(cat $p/scaling_governor) @ $(cat $p/scaling_cur_freq 2>/dev/null) kHz"; done
echo "peak/min refresh: $(settings get global peak_refresh_rate) / $(settings get global min_refresh_rate)"
for k in ro.surface_flinger.set_idle_timer_ms debug.sf.latch_unsignaled ro.config.low_ram; do echo "$k=$(getprop $k)"; done`);
$('#st').textContent=r.out||r.err;
const g=(r.out.match(/policy\d+: (\S+)/)||[])[1],pk=(r.out.match(/peak\/min refresh: (\S+)/)||[])[1];
$('#c1').textContent='Refresh: '+(pk&&pk!=='null'?parseFloat(pk)+'Hz lock':'auto');$('#c2').textContent='CPU: '+(g||'?');
$('#c3').textContent='HWC overlays: '+(cfg.DISABLE_HWC==='1'?'off':'on')}
async function disp(){const r=await sh('dumpsys display | grep -iE "refreshRate|renderFrameRate|activeMode" | head -n 8');$('#st').textContent=r.out||r.err||'no data'}
async function logs(){const r=await sh(`tail -n 12 ${LOG} 2>/dev/null`);$('#lg').textContent=r.out||'(log empty)'}
$('#seg').addEventListener('click',e=>{const b=e.target.closest('button[data-hz]');if(b)setHz(b.dataset.hz)});
$('#pre').addEventListener('click',e=>{const b=e.target.closest('button[data-preset]');if(b)preset(+b.dataset.preset)});
$('#bStatus').addEventListener('click',()=>status());
$('#bDisp').addEventListener('click',()=>disp());
$('#bApply').addEventListener('click',()=>save(true));
$('#bSave').addEventListener('click',()=>save(false));

render();
if(!hasKsu)$('#warn').style.display='block';else load().then(()=>{status();logs()});
