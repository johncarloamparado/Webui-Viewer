/* Modora diagnostics + log viewer panels (MB5.4). Classic script. Mounted by js/profiles-view.js under the backup group: MDDiagView.mount(parentNode).
 * Two groups: "Diagnostics" (root status card + copyable report) and "Logs" (read-only viewer). Everything here only READS the device.
 * Panel state lives at module level so a Tools tab rebuild (profile selection) does not lose results. All text via textContent / textarea.value.
 * Requires MDDiag (js/diag.js). Optional: MDI18n.
 */
(function () {
  "use strict";
  function t(k, fb, p) {
    try { if (window.MDI18n) { var s = window.MDI18n.t(k, p); if (s && s !== k) return s; } } catch (e) {}
    return fb.replace(/\{(\w+)\}/g, function (m, n) { return p && p[n] != null ? p[n] : m; });
  }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function btn(label, act, cls) { var b = el("button", "md-btn md-btn-sm" + (cls ? " " + cls : ""), label); b.type = "button"; b.setAttribute("data-dg", act); return b; }
  function bridgeOk() { return !!(window.MD && window.MD.bridge && window.MD.bridge.available()); }
  function banner(tone, title, sub, role) {
    var b = el("div", "md-banner md-banner-" + tone); b.setAttribute("role", role || "status"); var d = el("div", "md-banner-body");
    d.appendChild(el("p", "md-banner-title", title)); if (sub) d.appendChild(el("p", "md-dg-sub", sub)); b.appendChild(d); return b;
  }
  function row(k, v) { var r = el("div", "md-dg-row"); r.appendChild(el("span", "md-dg-k", k)); r.appendChild(el("span", "md-dg-v", v)); return r; }
  function yn(b) { return b == null ? t("dg.unknown", "Unknown") : b ? t("dg.yes", "Yes") : t("dg.no", "No"); }
  var MGR = { ksu: "KernelSU", magisk: "Magisk", apatch: "APatch" };

  var dg = { state: "idle", res: null, text: "", note: "" };                 /* idle | loading | ready */
  var lg = { src: "system", n: 300, state: "idle", res: null, q: "", note: "", seq: 0 };   /* idle | loading | ready */
  var dHost = null, lHost = null, focusNext = null;

  /* ---------- diagnostics ---------- */
  function runCheck() {
    var D = window.MDDiag; if (!D || dg.state === "loading") return;
    dg = { state: "loading", res: null, text: "", note: "" }; focusNext = "dg"; drawD();
    D.collect().then(function (r) {
      if (dg.state !== "loading") return;
      dg = { state: "ready", res: r, text: D.report(r), note: "" }; focusNext = "dg"; drawD();
    });
  }
  function copyText(text) {
    var ok = window.MD && window.MD.bridge && window.MD.bridge.copy(text);
    return ok ? t("dg.copied", "Copied to the clipboard.") : t("dg.copy_unavailable", "Copy is not available here. Select the text above and copy it by hand.");
  }
  function shareText(text) { var ok = window.MD && window.MD.bridge && window.MD.bridge.share(text); return ok ? "" : t("dg.share_unavailable", "Sharing is not available here. Select the text above and copy it by hand."); }

  function verdict(r) {
    if (r.status === "ok") return banner("ok", t("dg.root_ok", "Root access confirmed"), t("dg.root_ok_sub", "Modora's root shell answered as user 0 (root) with complete output."));
    if (r.status === "noroot") return banner("warn", t("dg.root_no", "Root access not confirmed"), t("dg.root_no_sub", "The shell answered as user {uid}, not root. Grant Modora root access in your root manager, then check again.", { uid: r.uid || "?" }), "alert");
    if (r.status === "nobridge") return banner("warn", t("dg.root_nobridge", "Root access not checked"), t("dg.err_nobridge", "Open Modora inside the app to run the check."), "alert");
    var why = r.reason === "timeout" ? t("dg.why_timeout", "The check timed out. A root permission prompt may be waiting.")
      : r.reason === "bridge" ? t("dg.why_bridge", "The native bridge reported an error.")
      : r.reason === "incomplete" ? t("dg.why_incomplete", "The shell answered, but the output was cut short, so nothing can be confirmed.")
      : t("dg.why_nooutput", "The root shell did not return the expected output. Root may be denied or unavailable.");
    return banner("warn", t("dg.root_unknown", "Root access not confirmed"), why + (r.code != null && r.code > 0 ? " " + t("dg.exit_code", "(exit code {code})", { code: r.code }) : "") + (r.err ? " " + r.err : ""), "alert");
  }
  function resultView(g) {
    var r = dg.res, d = r.data;
    var v = verdict(r); v.tabIndex = -1; v.setAttribute("data-dg-title", "dg"); g.appendChild(v);
    if (d) {
      var box = el("div", "md-dg-rows"), dv = d.device || {};
      box.appendChild(row(t("dg.k_device", "Device"), [dv.manufacturer, dv.model].filter(Boolean).join(" ") || t("dg.unknown", "Unknown")));
      box.appendChild(row(t("dg.k_android", "Android"), (dv.android || t("dg.unknown", "Unknown")) + (dv.sdk ? " (SDK " + dv.sdk + ")" : "")));
      box.appendChild(row(t("dg.k_kernel", "Kernel"), d.kernel || t("dg.unknown", "Unknown")));
      box.appendChild(row(t("dg.k_selinux", "SELinux"), d.selinux || t("dg.unknown", "Unknown")));
      if (r.status === "ok") {
        var m = d.managers.length ? d.managers.map(function (x) { return MGR[x.id] + (x.version ? " (" + x.version + ")" : ""); }).join(", ") : t("dg.mgr_none", "None recognised");
        box.appendChild(row(t("dg.k_manager", "Root manager files found"), m));
        var off = d.modules.filter(function (x) { return !x.on; }).length;
        box.appendChild(row(t("dg.k_modules", "Modules"), t("dg.modules_val", "{n} installed, {off} disabled", { n: d.modules.length, off: off })));
        box.appendChild(row(t("dg.k_tuners", "Tuner modules"), t("dg.tuners_val", "60Hz & SF: {a}, ANR limiter: {b}", { a: yn(d.tuners.rme50), b: yn(d.tuners.anr) })));
        g.appendChild(box); g.appendChild(el("p", "md-prof-note", t("dg.mgr_note", "Root manager entries come from a file check. They show what was found, not proof of root; only the confirmed status above is proof.")));
      } else g.appendChild(box);
    }
    g.appendChild(el("p", "md-dg-label", t("dg.report", "Report (what Copy and Share send)")));
    var ta = el("textarea", "md-textarea md-bkp-text"); ta.readOnly = true; ta.rows = 8; ta.spellcheck = false; ta.value = dg.text; ta.setAttribute("aria-label", t("dg.report", "Report (what Copy and Share send)")); ta.setAttribute("data-dg-ta", "report"); g.appendChild(ta);
    var bar = el("div", "md-diff-bar"); bar.appendChild(btn(t("dg.copy", "Copy report"), "copy", "md-btn-gradient")); bar.appendChild(btn(t("dg.share", "Share…"), "share")); bar.appendChild(btn(t("dg.recheck", "Check again"), "check")); bar.appendChild(btn(t("common.close", "Close"), "dclose")); g.appendChild(bar);
    if (dg.note) { var n = el("p", "md-prof-note", dg.note); n.setAttribute("role", "status"); g.appendChild(n); }
  }
  function drawD() {
    if (!dHost) return; dHost.textContent = "";
    if (dg.state === "idle") {
      var b = btn(t("dg.check", "Check root & system"), "check", "md-btn-gradient"); if (!bridgeOk() || !window.MDDiag) b.disabled = true; dHost.appendChild(b);
      if (!bridgeOk()) dHost.appendChild(el("p", "md-prof-note", t("dg.err_nobridge", "Open Modora inside the app to run the check.")));
    } else if (dg.state === "loading") { var s = el("p", "md-prof-note", t("dg.checking", "Checking…")); s.setAttribute("role", "status"); dHost.appendChild(s); }
    else resultView(dHost);
    if (focusNext === "dg") { var f = dHost.querySelector("[data-dg-title]") || dHost.querySelector('[data-dg="check"]'); focusNext = null; if (f) try { f.focus(); } catch (e) {} }
  }

  /* ---------- logs ---------- */
  function loadLogs() {
    var D = window.MDDiag; if (!D || lg.state === "loading") return;
    var mine = ++lg.seq; lg.state = "loading"; lg.res = null; lg.note = ""; focusNext = "lg"; drawL();
    D.logs.run(lg.src, lg.n).then(function (r) { if (mine !== lg.seq) return; lg.state = "ready"; lg.res = r; focusNext = "lg"; drawL(); });
  }
  function shown() { return window.MDDiag.logs.filter(lg.res.text, lg.q); }
  function failText(r) {
    if (r.state === "nobridge") return t("lg.err_nobridge", "Open Modora inside the app to read logs.");
    if (r.state === "timeout") return t("lg.err_timeout", "Reading the log timed out.");
    if (r.state === "failed") return t("lg.err_failed", "Could not read this log (exit code {code}).", { code: r.code }) + (r.err ? " " + r.err : "");
    return t("lg.err_generic", "Could not read this log.");
  }
  function logResult(g) {
    var r = lg.res;
    if (!r.ok) { var bn = banner("danger", failText(r), "", "alert"); bn.tabIndex = -1; bn.setAttribute("data-dg-title", "lg"); g.appendChild(bn); return; }
    if (r.state === "empty") { var e = el("p", "md-prof-note", lg.src === "modora" ? t("lg.empty_modora", "No Modora entries found in the recent system log. Logging may be restricted on this device.") : t("lg.empty", "The log is empty.")); e.setAttribute("role", "status"); e.tabIndex = -1; e.setAttribute("data-dg-title", "lg"); g.appendChild(e); return; }
    var s = shown(), info = el("p", "md-bkp-ok", t("lg.count", "{shown} of {total} lines", { shown: s.lines, total: r.lines }) + (r.cut ? " · " + t("lg.cut", "older lines cut off") : "")); info.setAttribute("role", "status"); info.tabIndex = -1; info.setAttribute("data-dg-title", "lg"); g.appendChild(info);
    var q = el("input", "md-input"); q.type = "search"; q.value = lg.q; q.placeholder = t("lg.filter", "Filter lines…"); q.setAttribute("aria-label", t("lg.filter", "Filter lines…")); q.setAttribute("data-dg-q", "1"); q.setAttribute("autocomplete", "off"); q.setAttribute("autocapitalize", "off"); g.appendChild(q);
    var ta = el("textarea", "md-textarea md-bkp-text md-dg-log"); ta.readOnly = true; ta.rows = 12; ta.spellcheck = false; ta.wrap = "off"; ta.value = s.text; ta.setAttribute("aria-label", t("lg.text", "Log text")); ta.setAttribute("data-dg-ta", "log"); g.appendChild(ta);
    var bar = el("div", "md-diff-bar"), c = btn(t("lg.copy", "Copy shown lines"), "lcopy"), sh = btn(t("dg.share", "Share…"), "lshare"); if (!s.lines) { c.disabled = true; sh.disabled = true; }
    bar.appendChild(c); bar.appendChild(sh); bar.appendChild(btn(t("common.clear", "Clear"), "lclear")); g.appendChild(bar);
    if (lg.note) { var n = el("p", "md-prof-note", lg.note); n.setAttribute("role", "status"); g.appendChild(n); }
  }
  function drawL() {
    if (!lHost) return;
    var act = document.activeElement, keepQ = act && act.getAttribute && act.getAttribute("data-dg-q") === "1" && lHost.contains(act), pos = keepQ ? act.selectionStart : 0;
    lHost.textContent = "";
    var D = window.MDDiag, S = D ? D.logs.SOURCES : {}, lab1 = el("label", "md-label", t("lg.source", "Log")); lab1.setAttribute("for", "dg-src"); lHost.appendChild(lab1);
    var sel = el("select", "md-select"); sel.id = "dg-src"; sel.setAttribute("data-dg-sel", "src"); sel.disabled = lg.state === "loading";
    Object.keys(S).forEach(function (k) { var o = el("option", "", t("lg.src_" + k, S[k].label)); o.value = k; if (k === lg.src) o.selected = true; sel.appendChild(o); }); lHost.appendChild(sel);
    var lab2 = el("label", "md-label", t("lg.lines", "Lines")); lab2.setAttribute("for", "dg-n"); lHost.appendChild(lab2);
    var sn = el("select", "md-select"); sn.id = "dg-n"; sn.setAttribute("data-dg-sel", "n"); sn.disabled = lg.state === "loading";
    (D ? D.logs.LINES : []).forEach(function (n) { var o = el("option", "", String(n)); o.value = String(n); if (n === lg.n) o.selected = true; sn.appendChild(o); }); lHost.appendChild(sn);
    var bar = el("div", "md-diff-bar"), ld = btn(lg.res ? t("lg.reload", "Reload") : t("lg.load", "Load log"), "load", "md-btn-gradient"); if (!bridgeOk() || !D || lg.state === "loading") ld.disabled = true; bar.appendChild(ld); lHost.appendChild(bar);
    if (!bridgeOk()) lHost.appendChild(el("p", "md-prof-note", t("lg.err_nobridge", "Open Modora inside the app to read logs.")));
    if (lg.state === "loading") { var s = el("p", "md-prof-note", t("lg.loading", "Reading the log…")); s.setAttribute("role", "status"); lHost.appendChild(s); }
    else if (lg.state === "ready" && lg.res) logResult(lHost);
    if (focusNext === "lg") { var f = lHost.querySelector("[data-dg-title]"); focusNext = null; if (f) try { f.focus(); } catch (e) {} }
    else if (keepQ) { var q = lHost.querySelector('[data-dg-q="1"]'); if (q) try { q.focus(); q.setSelectionRange(pos, pos); } catch (e) {} }
  }

  function mount(parent) {
    var g = el("section", "md-set-group md-dg"); g.appendChild(el("h2", "", t("dg.title", "Diagnostics")));
    g.appendChild(el("p", "md-prof-note", t("dg.note", "Checks whether Modora can use root and collects basic device and module information as text you can copy or share. It only reads; nothing is changed. It contains no serial number, accounts or personal files.")));
    dHost = el("div", "md-dg-body");
    dHost.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-dg]") : null; if (!b || b.disabled || !dHost.contains(b)) return; var a = b.getAttribute("data-dg");
      if (a === "check") runCheck();
      else if (a === "copy") { dg.note = copyText(dg.text); drawD(); }
      else if (a === "share") { dg.note = shareText(dg.text); drawD(); }
      else if (a === "dclose") { dg = { state: "idle", res: null, text: "", note: "" }; focusNext = "dg"; drawD(); }
    });
    g.appendChild(dHost); parent.appendChild(g); drawD();

    var h = el("section", "md-set-group md-dg"); h.appendChild(el("h2", "", t("lg.title", "Logs")));
    h.appendChild(el("p", "md-prof-note", t("lg.note", "Read-only view of recent system logs. Logs can contain personal information such as app names and activity. Check the text before you share it.")));
    lHost = el("div", "md-dg-body");
    lHost.addEventListener("click", function (e) {
      var b = e.target.closest ? e.target.closest("[data-dg]") : null; if (!b || b.disabled || !lHost.contains(b)) return; var a = b.getAttribute("data-dg");
      if (a === "load") loadLogs();
      else if (a === "lcopy" && lg.res) { lg.note = copyText(shown().text); drawL(); }
      else if (a === "lshare" && lg.res) { lg.note = shareText(shown().text); drawL(); }
      else if (a === "lclear") { lg.seq++; lg.state = "idle"; lg.res = null; lg.q = ""; lg.note = ""; drawL(); }
    });
    lHost.addEventListener("change", function (e) {
      var s = e.target; if (!s || !s.getAttribute) return; var w = s.getAttribute("data-dg-sel"); if (!w || lg.state === "loading") return;
      if (w === "src" && window.MDDiag && Object.prototype.hasOwnProperty.call(window.MDDiag.logs.SOURCES, s.value)) { lg.src = s.value; lg.seq++; lg.state = "idle"; lg.res = null; lg.note = ""; drawL(); }
      else if (w === "n") { var n = parseInt(s.value, 10); if (window.MDDiag && window.MDDiag.logs.LINES.indexOf(n) >= 0) { lg.n = n; lg.seq++; lg.state = "idle"; lg.res = null; lg.note = ""; drawL(); } }
    });
    lHost.addEventListener("input", function (e) { var q = e.target; if (q && q.getAttribute && q.getAttribute("data-dg-q") === "1") { lg.q = q.value; lg.note = ""; drawL(); } });
    h.appendChild(lHost); parent.appendChild(h); drawL();
    return g;
  }
  window.MDDiagView = { mount: mount, state: function () { return { diag: dg.state, logs: lg.state }; } };
})();
