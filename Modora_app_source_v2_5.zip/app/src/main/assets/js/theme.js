/* Modora theme manager (MB1.2). Classic script (load with <script defer>), no modules.
 * Sets <html data-theme="dark|light"> and data-theme-pref="dark|light|system".
 * Preference is stored in localStorage key "md.theme" (interim: MB1.5 store.js
 * will take over persistence; the key name stays the same so nothing is lost).
 * Missing/invalid/unreadable preference falls back to "dark" (dark-first).
 * API: MDTheme.get() -> pref, .resolved() -> "dark"|"light", .set(pref) -> bool persisted,
 *      .onChange(fn(resolved, pref)) -> unsubscribe, .PREFS
 */
(function () {
  'use strict';
  var KEY = 'md.theme', PREFS = ['dark', 'light', 'system'], DEF = 'dark';
  var root = document.documentElement;
  var pref = DEF, current = '', listeners = [];

  function readStored() {
    try { var v = window.localStorage.getItem(KEY); return PREFS.indexOf(v) > -1 ? v : DEF; }
    catch (e) { return DEF; }
  }
  function writeStored(v) {
    try { window.localStorage.setItem(KEY, v); return true; } catch (e) { return false; }
  }
  function mq(q) { try { return window.matchMedia ? window.matchMedia(q) : null; } catch (e) { return null; } }

  // System theme: CSS media query first, native appInfo().nightMode as backup, else dark.
  function systemIsLight() {
    var l = mq('(prefers-color-scheme: light)'), d = mq('(prefers-color-scheme: dark)');
    if (l && l.matches) return true;
    if (d && d.matches) return false;
    try {
      if (window.ksu && typeof window.ksu.appInfo === 'function') {
        return JSON.parse(window.ksu.appInfo()).nightMode === false;
      }
    } catch (e) { /* ignore */ }
    return false;
  }

  function resolve() { return pref === 'system' ? (systemIsLight() ? 'light' : 'dark') : pref; }

  function apply(force) {
    var r = resolve();
    root.setAttribute('data-theme-pref', pref);
    if (r === current && !force) return;
    current = r;
    root.setAttribute('data-theme', r);
    for (var i = 0; i < listeners.length; i++) {
      try { listeners[i](r, pref); } catch (e) { /* listener errors must not break theming */ }
    }
  }

  function watchSystem() {
    ['(prefers-color-scheme: light)', '(prefers-color-scheme: dark)'].forEach(function (q) {
      var m = mq(q); if (!m) return;
      var h = function () { if (pref === 'system') apply(false); };
      if (m.addEventListener) m.addEventListener('change', h);
      else if (m.addListener) m.addListener(h);
    });
  }

  window.MDTheme = {
    PREFS: PREFS.slice(),
    get: function () { return pref; },
    resolved: function () { return current || resolve(); },
    set: function (p) {
      if (PREFS.indexOf(p) < 0) return false;
      pref = p;
      var ok = writeStored(p);
      apply(false);
      return ok;
    },
    onChange: function (fn) {
      if (typeof fn !== 'function') return function () {};
      listeners.push(fn);
      return function () { var i = listeners.indexOf(fn); if (i > -1) listeners.splice(i, 1); };
    }
  };

  pref = readStored();
  apply(true);
  watchSystem();
})();
