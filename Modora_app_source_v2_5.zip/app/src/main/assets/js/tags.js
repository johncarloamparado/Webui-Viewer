/* Modora module tags (MB6.3a). Classic script (<script defer>), no modules. Independent of store.js/bridge (home.html does not load store.js).
 * Tags are the USER's own labels per module id (e.g. "gaming", "battery"). Nothing is read from or written to the device:
 * storage is localStorage key "md.tags" (JSON {moduleId: [tag, ...]}), with an in-memory fallback if storage throws.
 * Tags never touch the favourites file, deck order, module flag files or any root command.
 *
 * Rules (pure, unit-testable):
 *   MDTags.norm(raw)        -> clean tag string or ""   (trim, collapse whitespace, strip control chars, lowercase, max 20 chars; "" if empty)
 *   MDTags.MAX_TAGS = 8 per module, MAX_LEN = 20 chars. Tags are unique per module (case-insensitive, stored lowercase).
 * API:
 *   MDTags.get(id)            -> array of tags (copy)
 *   MDTags.add(id, raw)       -> {ok, tag, reason}   reason: invalid|empty|dup|limit|storage(only when memory fallback)
 *   MDTags.remove(id, tag)    -> bool (true when something was removed)
 *   MDTags.all(ids?)          -> [{tag, count}] sorted by count desc then name; when ids is given only modules in ids are counted
 *   MDTags.matches(id, q)     -> true when any tag of id contains the lower-cased query q
 *   MDTags.has(id, tag)       -> bool
 *   MDTags.prune(ids)         -> number of module entries dropped that are not in ids (only call after a COMPLETE successful scan)
 *   MDTags.exportAll() / MDTags.persistent()
 *   MDTags.onChange(fn)       -> unsubscribe; fn() is called after every successful add/remove/prune
 */
(function () {
  "use strict";
  var KEY = "md.tags", MAX_TAGS = 8, MAX_LEN = 20, ID_RE = /^[A-Za-z0-9._-]+$/;
  var mem = null, persist = true, subs = [];

  function validId(id) { return typeof id === "string" && id.length > 0 && id.length <= 120 && ID_RE.test(id) && id !== "." && id !== ".."; }
  function ls() { try { return window.localStorage || null; } catch (e) { return null; } }
  function own(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }

  function norm(raw) {
    if (typeof raw !== "string") return "";
    var s = raw.replace(/[\u0000-\u001f\u007f-\u009f\u200b-\u200f\u2028\u2029\ufeff]/g, " ").replace(/\s+/g, " ").trim().toLowerCase();
    if (s.length > MAX_LEN) s = s.slice(0, MAX_LEN).trim();
    return s;
  }

  function clean(obj) {                       // validate whatever was stored; anything odd is dropped, never trusted
    var out = Object.create(null);   // null prototype: a module/tag named __proto__ is just a key
    if (!obj || typeof obj !== "object" || Array.isArray(obj)) return out;
    Object.keys(obj).forEach(function (id) {
      if (!validId(id) || !Array.isArray(obj[id])) return;
      var seen = Object.create(null), list = [];
      obj[id].forEach(function (t) {
        var n = norm(t);
        if (n && !own(seen, n) && list.length < MAX_TAGS) { seen[n] = 1; list.push(n); }
      });
      if (list.length) out[id] = list;
    });
    return out;
  }

  function load() {
    if (mem) return mem;
    var s = ls(), raw = null;
    if (s) { try { raw = s.getItem(KEY); } catch (e) { raw = null; } }
    var parsed = null;
    if (raw) { try { parsed = JSON.parse(raw); } catch (e) { parsed = null; } }
    mem = clean(parsed);
    return mem;
  }

  function save() {                           // true when it reached localStorage
    var s = ls();
    if (s) { try { s.setItem(KEY, JSON.stringify(mem)); persist = true; return true; } catch (e) {} }
    persist = false; return false;
  }

  function fire() { subs.slice().forEach(function (f) { try { f(); } catch (e) { /* listener errors must not break tags */ } }); }

  function get(id) { var d = load(); return validId(id) && own(d, id) ? d[id].slice() : []; }
  function has(id, tag) { var n = norm(tag); return !!n && get(id).indexOf(n) > -1; }

  function add(id, raw) {
    if (!validId(id)) return { ok: false, tag: "", reason: "invalid" };
    var n = norm(raw);
    if (!n) return { ok: false, tag: "", reason: "empty" };
    var d = load(), cur = own(d, id) ? d[id] : [];
    if (cur.indexOf(n) > -1) return { ok: false, tag: n, reason: "dup" };
    if (cur.length >= MAX_TAGS) return { ok: false, tag: n, reason: "limit" };
    d[id] = cur.concat(n);
    var stored = save(); fire();
    return { ok: true, tag: n, reason: stored ? "" : "storage" };
  }

  function remove(id, tag) {
    if (!validId(id)) return false;
    var n = norm(tag), d = load();
    if (!n || !own(d, id)) return false;
    var at = d[id].indexOf(n);
    if (at < 0) return false;
    d[id] = d[id].filter(function (t) { return t !== n; });
    if (!d[id].length) delete d[id];
    save(); fire(); return true;
  }

  function all(ids) {
    var d = load(), count = Object.create(null), allow = null;
    if (Array.isArray(ids)) { allow = Object.create(null); ids.forEach(function (i) { allow[i] = 1; }); }
    Object.keys(d).forEach(function (id) {
      if (allow && !own(allow, id)) return;
      d[id].forEach(function (t) { count[t] = (count[t] || 0) + 1; });
    });
    return Object.keys(count).map(function (t) { return { tag: t, count: count[t] }; })
      .sort(function (a, b) { return b.count - a.count || (a.tag < b.tag ? -1 : a.tag > b.tag ? 1 : 0); });
  }

  function matches(id, q) {
    if (typeof q !== "string" || !q) return false;
    var l = q.toLowerCase();
    return get(id).some(function (t) { return t.indexOf(l) > -1; });
  }

  function prune(ids) {
    if (!Array.isArray(ids)) return 0;
    var keep = Object.create(null), d = load(), n = 0;
    ids.forEach(function (i) { keep[i] = 1; });
    Object.keys(d).forEach(function (id) { if (!own(keep, id)) { delete d[id]; n++; } });
    if (n) { save(); fire(); }
    return n;
  }

  window.MDTags = {
    MAX_TAGS: MAX_TAGS, MAX_LEN: MAX_LEN,
    norm: norm, get: get, has: has, add: add, remove: remove, all: all, matches: matches, prune: prune,
    exportAll: function () { var d = load(), o = Object.create(null); Object.keys(d).forEach(function (k) { o[k] = d[k].slice(); }); return o; },
    persistent: function () { return persist; },
    onChange: function (fn) { if (typeof fn !== "function") return function () {}; subs.push(fn); return function () { var i = subs.indexOf(fn); if (i > -1) subs.splice(i, 1); }; },
    _reset: function () { mem = null; persist = true; }   // tests only
  };
})();
