/* Modora install-sheet ZIP scanner core (MBFIX.6 / MINI 1A). Classic script (<script defer>), no modules, NO DOM, no native-bridge dependency.
 * Finds *.zip files and tells genuine module ZIPs (module.prop at the archive ROOT) from everything else, read-only, without extracting.
 * Not wired into any UI in 1A: home.html still uses its own scanZips().
 *
 * API  (window.MDZipScan; also module.exports under Node for tests)
 *   scan(executor?, options?) -> Promise<result>        NEVER rejects
 *       executor(cmd, {timeout}) -> Promise<{code, out}>   default: window.MD.sh (js/bridge.js). Inject a fake in tests.
 *       options: {timeout ms (default 30000, the overall bridge timeout), dirs [absolute dirs] (tests only; default DIRS)}
 *   parse(output) -> {ok:true, method, modules, others, skipped:{large,unreadable}, truncated}
 *                 |  {ok:false, reason}   reason: empty|nomarker|noend|malformed|badcount|nofind
 *       Pure. Rejects missing markers, truncated output, a body with no END line, row-count mismatch, malformed rows, duplicate markers,
 *       and any module row when no inspection method was found.
 *   buildScript(options?) -> string                     the (read-only, static apart from quoted dirs) shell script
 *   Constants: DIRS, MAX_ZIPS (60), MAX_BYTES (256 MiB), METHODS, NOTE_NOINSPECT
 *
 * Result of scan():
 *   {status, modules:[{path,name,nameKnown,ver,code,size}], others:[{path,size}], method, note, noteKey, reason, skipped:{large,unreadable}, truncated}
 *     status: "ok"          scan complete. modules = ZIPs whose ROOT has module.prop; others = every other examined ZIP.
 *             "noinspector" no usable unzip on this device. modules is ALWAYS [], every in-limit ZIP is in others, note = NOTE_NOINSPECT.
 *             "error"       nothing trustworthy (reason: timeout|bridge|empty|nomarker|noend|malformed|badcount|nofind). modules/others empty.
 *             "nobridge"    no executor available.
 *     method: "unzip"|"busybox"|"ksu-busybox"|"magisk-busybox"|"toybox"|"none"|"" (error/nobridge)
 *     note / noteKey: user-facing English text and a suggested i18n key for MINI 1C ("" when there is nothing to say). 1A adds NO i18n keys.
 *     truncated: true when more than MAX_ZIPS distinct ZIPs exist (only the first MAX_ZIPS were examined).
 *     skipped.large: ZIPs over MAX_BYTES (not examined, not listed).  skipped.unreadable: names with control chars/newlines or unknown size.
 *   Name/ver values come from the FIRST name=/version=/versionCode= line of the root module.prop (text after the first "=").
 *   A module whose name= is missing gets the file name (without .zip) as name AND nameKnown:false (1C: the UI must not present that as module metadata).
 *
 * Wire format (stdout, one record per line, fields TAB-separated; no field can contain a TAB/newline because control characters are
 * stripped from values and paths containing them are skipped in the shell):
 *   MDZS1<TAB>BEGIN
 *   MDZS1<TAB>METHOD<TAB>id|none
 *   MDZS1<TAB>M<TAB>size<TAB>path<TAB>name<TAB>version<TAB>versionCode      (module)
 *   MDZS1<TAB>O<TAB>size<TAB>path                                           (other)
 *   MDZS1<TAB>SKIP<TAB>large<TAB>unreadable<TAB>truncated(0|1)
 *   MDZS1<TAB>END<TAB>rowCount                                              (rowCount = number of M+O rows)
 * Lines outside BEGIN..END are ignored (login banners); any other line inside the frame makes the output malformed.
 *
 * Safety: the script only reads (find, wc, unzip -l/-p, grep, cut, tr, head). It never writes, extracts or deletes. The only dynamic
 * text is the directory list, validated and single-quoted; no file name or user value is ever put into a command by this file.
 */
(function (root) {
  "use strict";
  var TAG = "MDZS1";
  var DIRS = ["/sdcard/Download", "/sdcard/Downloads", "/storage/emulated/0/Download", "/sdcard", "/data/adb", "/sdcard/Modora/zips"];
  var MAX_ZIPS = 60, MAX_BYTES = 256 * 1024 * 1024, DEFAULT_TIMEOUT = 30000;
  var METHODS = ["unzip", "busybox", "ksu-busybox", "magisk-busybox", "toybox"];
  var NOTE_NOINSPECT = "Could not look inside zips on this device, so they are not checked.";
  var NOTE_KEY = "install.zipscan_noinspect";
  var DIR_RE = /^\/[A-Za-z0-9._\/-]+$/;

  function shq(v) { return "'" + String(v).replace(/'/g, "'\\''") + "'"; }   // local copy: this file must run without bridge.js

  function buildScript(options) {
    var dirs = (options && options.dirs) || DIRS, q = [];
    dirs.forEach(function (d) {
      if (typeof d !== "string" || !DIR_RE.test(d) || d.indexOf("..") !== -1) throw new TypeError("zipscan: bad directory");
      q.push(shq(d));
    });
    return [
      "T=\"$(printf '\\t')\"; NL=\"$(printf '\\nx')\"; NL=\"${NL%x}\"",
      "echo \"" + TAG + "${T}BEGIN\"",
      // ---- find one usable ZIP-inspection method, once ----
      "probe() { o=$(\"$@\" 2>&1 </dev/null | head -n 5); case \"$o\" in *[Nn]ot\\ found*|*nknown\\ command*|*nvalid\\ applet*) return 1;; *sage*) return 0;; esac; return 1; }",
      "MID=none",
      "if command -v unzip >/dev/null 2>&1 && probe unzip; then MID=unzip",
      "elif command -v busybox >/dev/null 2>&1 && probe busybox unzip; then MID=busybox",
      "elif [ -x /data/adb/ksu/bin/busybox ] && probe /data/adb/ksu/bin/busybox unzip; then MID=ksu-busybox",
      "elif [ -x /data/adb/magisk/busybox ] && probe /data/adb/magisk/busybox unzip; then MID=magisk-busybox",
      "elif command -v toybox >/dev/null 2>&1 && probe toybox unzip; then MID=toybox",
      "fi",
      "zi() { case \"$MID\" in unzip) unzip \"$@\";; busybox) busybox unzip \"$@\";; ksu-busybox) /data/adb/ksu/bin/busybox unzip \"$@\";;",
      "  magisk-busybox) /data/adb/magisk/busybox unzip \"$@\";; toybox) toybox unzip \"$@\";; *) return 1;; esac; }",
      "echo \"" + TAG + "${T}METHOD${T}$MID\"",
      "if ! command -v find >/dev/null 2>&1; then echo \"" + TAG + "${T}NOFIND\"; exit 0; fi",
      // ---- walk, classify ----
      "{ for d in " + q.join(" ") + "; do",
      "    [ -d \"$d\" ] || continue",
      "    find \"$d\" -maxdepth 2 -type f -name '*.zip' 2>/dev/null",
      "  done; } | {",
      "  n=0; big=0; bad=0; trunc=0; SEEN=\"$NL\"",
      "  while IFS= read -r f; do",
      "    case \"$f\" in /*) ;; *) continue;; esac",
      "    [ -f \"$f\" ] || continue",
      "    c=$(printf '%s' \"$f\" | tr -d '[:cntrl:]')",
      "    [ \"$c\" = \"$f\" ] || { bad=$((bad+1)); continue; }",
      "    sz=$(wc -c < \"$f\" 2>/dev/null | tr -d ' \\t')",
      "    case \"$sz\" in ''|*[!0-9]*) bad=$((bad+1)); continue;; esac",
      "    key=\"$sz:${f##*/}\"",
      "    case \"$SEEN\" in *\"$NL$key$NL\"*) continue;; esac",
      "    SEEN=\"$SEEN$key$NL\"",
      "    [ \"$sz\" -gt " + MAX_BYTES + " ] && { big=$((big+1)); continue; }",
      "    if [ \"$n\" -ge " + MAX_ZIPS + " ]; then trunc=1; break; fi",
      "    n=$((n+1))",
      "    if [ \"$MID\" != none ] && zi -l \"$f\" </dev/null 2>/dev/null | grep -Eq '(^|[[:space:]])module\\.prop[[:space:]]*$'; then",
      "      P=$(zi -p \"$f\" module.prop </dev/null 2>/dev/null | head -n 200 | tr -d '\\r')",
      "      if [ -n \"$P\" ]; then",
      "        nm=$(printf '%s\\n' \"$P\" | grep -m1 '^name=' | cut -d= -f2- | tr -d '[:cntrl:]')",
      "        vr=$(printf '%s\\n' \"$P\" | grep -m1 '^version=' | cut -d= -f2- | tr -d '[:cntrl:]')",
      "        vc=$(printf '%s\\n' \"$P\" | grep -m1 '^versionCode=' | cut -d= -f2- | tr -d '[:cntrl:]')",
      "        printf '%s\\tM\\t%s\\t%s\\t%s\\t%s\\t%s\\n' " + TAG + " \"$sz\" \"$f\" \"$nm\" \"$vr\" \"$vc\"",
      "        continue",
      "      fi",
      "    fi",
      "    printf '%s\\tO\\t%s\\t%s\\n' " + TAG + " \"$sz\" \"$f\"",
      "  done",
      "  printf '%s\\tSKIP\\t%s\\t%s\\t%s\\n' " + TAG + " \"$big\" \"$bad\" \"$trunc\"",
      "  printf '%s\\tEND\\t%s\\n' " + TAG + " \"$n\"",
      "}"
    ].join("\n");
  }

  function isInt(s) { return /^(0|[1-9][0-9]{0,15})$/.test(s); }
  function okPath(p) { return typeof p === "string" && p.charAt(0) === "/" && !/[\u0000-\u001f\u007f]/.test(p) && !/(^|\/)\.\.(\/|$)/.test(p); }
  function clean(s, n) { return String(s == null ? "" : s).replace(/[\u0000-\u001f\u007f]/g, "").trim().slice(0, n); }
  function base(p) { return p.slice(p.lastIndexOf("/") + 1); }

  function parse(output) {
    var text = output == null ? "" : String(output);
    if (!text.trim()) return { ok: false, reason: "empty" };
    var lines = text.split("\n");
    if (lines[lines.length - 1] === "") lines.pop();                      // the final newline is not a blank line
    var begun = false, ended = false, method = null, skip = null, endCount = -1, rows = 0, i, f, l;
    var modules = [], others = [], seen = {};
    function bad() { return { ok: false, reason: "malformed" }; }
    for (i = 0; i < lines.length; i++) {
      l = lines[i].replace(/\r$/, "");
      if (!begun) { if (l === TAG + "\tBEGIN") begun = true; continue; }
      if (ended) { if (l === "") continue; if (l.indexOf(TAG + "\t") === 0) return bad(); continue; }   // trailing noise after END is ignored
      if (l === "") return bad();
      f = l.split("\t");
      if (f[0] !== TAG) return bad();
      if (f[1] === "BEGIN") return bad();
      if (f[1] === "NOFIND" && f.length === 2) return { ok: false, reason: "nofind" };
      if (f[1] === "METHOD") {
        if (method !== null || f.length !== 3 || !(f[2] === "none" || METHODS.indexOf(f[2]) >= 0)) return bad();
        method = f[2];
      } else if (f[1] === "M" || f[1] === "O") {
        if (method === null) return bad();
        var isM = f[1] === "M";
        if (f.length !== (isM ? 7 : 4) || !isInt(f[2]) || !okPath(f[3])) return bad();
        if (isM && method === "none") return bad();                      // no module may be asserted without an inspector
        rows++;
        var size = Number(f[2]), key = size + ":" + base(f[3]);
        if (seen[key]) continue;                                          // /sdcard vs /storage/emulated/0 alias: keep the first
        seen[key] = 1;
        if (isM) {
          var nm = clean(f[4], 200);
          modules.push({ path: f[3], name: nm || base(f[3]).replace(/\.zip$/i, ""), nameKnown: !!nm, ver: clean(f[5], 80), code: clean(f[6], 20), size: size });
        } else others.push({ path: f[3], size: size });
      } else if (f[1] === "SKIP") {
        if (skip !== null || f.length !== 5 || !isInt(f[2]) || !isInt(f[3]) || !(f[4] === "0" || f[4] === "1")) return bad();
        skip = { large: Number(f[2]), unreadable: Number(f[3]), truncated: f[4] === "1" };
      } else if (f[1] === "END") {
        if (f.length !== 3 || !isInt(f[2])) return bad();
        endCount = Number(f[2]); ended = true;
      } else return bad();
    }
    if (!begun) return { ok: false, reason: "nomarker" };
    if (!ended || method === null || skip === null) return { ok: false, reason: "noend" };
    if (endCount !== rows) return { ok: false, reason: "badcount" };
    return { ok: true, method: method, modules: modules, others: others, skipped: { large: skip.large, unreadable: skip.unreadable }, truncated: skip.truncated };
  }

  function fail(status, reason, method) {
    return { status: status, modules: [], others: [], method: method || "", note: "", noteKey: "", reason: reason, skipped: { large: 0, unreadable: 0 }, truncated: false };
  }

  function defaultExecutor() {
    var MD = root && root.MD;
    return MD && typeof MD.sh === "function" ? MD.sh : null;
  }

  function scan(executor, options) {
    options = options || {};
    return new Promise(function (resolve) {
      var ex = typeof executor === "function" ? executor : defaultExecutor();
      if (!ex) return resolve(fail("nobridge", "nobridge"));
      var cmd, tmo = Number(options.timeout);
      if (!isFinite(tmo) || tmo <= 0) tmo = DEFAULT_TIMEOUT;
      try { cmd = buildScript(options); } catch (e) { return resolve(fail("error", "bridge")); }
      var p;
      try { p = Promise.resolve(ex(cmd, { timeout: Math.floor(tmo) })); } catch (e) { return resolve(fail("error", "bridge")); }
      p.then(function (r) {
        r = r || {};
        var code = typeof r.code === "number" ? r.code : -1;
        if (code === -2 || code === -3) return resolve(fail("error", "timeout"));
        var out = r.out == null ? "" : String(r.out);
        var pr = parse(out);
        if (!pr.ok) return resolve(fail("error", (code < 0 && pr.reason === "empty") ? "bridge" : pr.reason));
        var res = { status: "ok", modules: pr.modules, others: pr.others, method: pr.method, note: "", noteKey: "", reason: "", skipped: pr.skipped, truncated: pr.truncated };
        if (pr.method === "none") {
          res.status = "noinspector"; res.modules = []; res.note = NOTE_NOINSPECT; res.noteKey = NOTE_KEY;
          res.others = pr.others.concat(pr.modules.map(function (m) { return { path: m.path, size: m.size }; }));   // defensive; parse already rejects M rows here
        }
        resolve(res);
      }, function () { resolve(fail("error", "bridge")); });
    });
  }

  var api = { scan: scan, parse: parse, buildScript: buildScript, DIRS: DIRS.slice(), MAX_ZIPS: MAX_ZIPS, MAX_BYTES: MAX_BYTES, METHODS: METHODS.slice(), NOTE_NOINSPECT: NOTE_NOINSPECT, NOTE_KEY: NOTE_KEY };
  if (typeof module === "object" && module && module.exports) module.exports = api;
  if (root && typeof root === "object") root.MDZipScan = api;
})(typeof window !== "undefined" ? window : (typeof globalThis !== "undefined" ? globalThis : this));
