/* Modora module scan + saved-data cache (MB2.2). Classic script (<script defer>), no modules.
 * Runs the SAME root shell scan the legacy deck used (lists /data/adb/modules/*, reads module.prop, and reads the deck
 * favourites file /data/adb/moddeck/favs) through MD.sh (js/bridge.js) with a timeout, and NEVER reports success unless the
 * output is complete (start marker "@u<uid>" AND end marker "@@0|@@1") and the shell is uid 0.
 * Requires js/bridge.js. Independent of core.js/store.js (own localStorage key "md.scan.cache", memory fallback).
 * API: MDScan.scan({timeout}) -> Promise<result>   (NEVER rejects)
 *        result.status: "ok" | "noroot" | "error" | "nobridge"
 *        ok:       {status, at, uid, modules[{id,n,v,w,a,e,d}], favs[ids]|null (null = no favourites file)}
 *        others:   {status, reason, code}   reason: noroot|timeout|nooutput|incomplete|bridge|nobridge
 *      MDScan.parse(out) -> {marker, complete, uid, modules, favs, favFile}   (pure; used by scan and tests)
 *      MDScan.cached() -> {t, modules, favs[]} | null     (validated + sanitized; corrupt/foreign data -> null)
 *      MDScan.saveCache({at, modules, favs}) -> bool      (only call with a successful scan)   MDScan.clearCache()
 * Cache is only a first-paint aid: callers must label it as saved data and replace it with the live result.
 */
(function () {
  "use strict";
  var MD = (window.MD = window.MD || {});
  var FAV = "/data/adb/moddeck/favs", KEY = "md.scan.cache", VER = 1, MAXN = 300, MAXBYTES = 200000, TIMEOUT = 20000;
  var ID_RE = /^[A-Za-z0-9._-]+$/, mem = null;

  var SCRIPT = [
    'echo "@u$(id -u)"',
    'for d in /data/adb/modules/*/; do',
    '  [ -f "$d/remove" ] && continue',
    '  id=$(basename "$d")',
    "  n=$(grep -m1 '^name=' \"$d/module.prop\" 2>/dev/null | cut -d= -f2-)",
    "  v=$(grep -m1 '^version=' \"$d/module.prop\" 2>/dev/null | cut -d= -f2-)",
    "  ds=$(grep -m1 '^description=' \"$d/module.prop\" 2>/dev/null | cut -d= -f2-)",
    '  w=0; [ -f "$d/webroot/index.html" ] && w=1',
    '  a=0; [ -f "$d/action.sh" ] && a=1',
    '  e=1; [ -f "$d/disable" ] && e=0',
    "  printf '%s\\001%s\\001%s\\001%s\\001%s\\001%s\\001%s\\n' \"$id\" \"$n\" \"$v\" \"$w\" \"$a\" \"$e\" \"$ds\"",
    "done",
    "if [ -f " + FAV + ' ]; then echo "@@1"; cat ' + FAV + '; else echo "@@0"; fi'
  ].join("\n");

  function uniq(a) { var s = {}, o = []; a.forEach(function (x) { if (!s[x]) { s[x] = 1; o.push(x); } }); return o; }

  function parse(out) {
    var r = { marker: false, complete: false, uid: "", modules: [], favs: null, favFile: false }, fromFile = null, ids = [];
    String(out == null ? "" : out).split("\n").forEach(function (l) {
      if (l.indexOf("@u") === 0) { r.marker = true; r.uid = l.slice(2).trim(); }
      else if (l.indexOf("@@") === 0) { fromFile = l.charAt(2) === "1"; r.complete = true; }
      else if (fromFile !== null) { var t = l.trim(); if (ID_RE.test(t)) ids.push(t); }
      else if (l.indexOf("\x01") >= 0) {
        var f = l.split("\x01");
        if (f.length >= 6 && ID_RE.test(f[0])) r.modules.push({ id: f[0], n: f[1] || f[0], v: f[2] || "", w: f[3] === "1", a: f[4] === "1", e: f[5] === "1", d: (f[6] || "").trim() });
      }
    });
    r.favFile = fromFile === true; r.favs = r.favFile ? uniq(ids) : null;
    return r;
  }

  function scan(o) {
    o = o || {};
    return new Promise(function (resolve) {
      var fail = function (status, reason, code) { resolve({ status: status, reason: reason, code: code }); };
      if (!MD.sh || !MD.bridge || !MD.bridge.available()) return fail("nobridge", "nobridge", -5);
      MD.sh(SCRIPT, { timeout: o.timeout || TIMEOUT }).then(function (r) {
        var p = parse(r.out);
        if (r.code === -2 || r.code === -3) return fail("error", "timeout", r.code);
        if (r.code === -1 || r.code === -4 || r.code === -5) return fail("error", "bridge", r.code);
        if (!p.marker) return fail("error", "nooutput", r.code);
        if (!p.complete) return fail("error", "incomplete", r.code);
        if (p.uid !== "0") return resolve({ status: "noroot", reason: "noroot", code: r.code, uid: p.uid });
        resolve({ status: "ok", at: Date.now(), uid: p.uid, modules: p.modules, favs: p.favs });
      }, function () { fail("error", "bridge", -1); });
    });
  }

  function str(v, n) { return String(v == null ? "" : v).slice(0, n); }
  function cleanMods(list) {
    var o = [];
    for (var i = 0; i < list.length && o.length < MAXN; i++) {
      var m = list[i];
      if (m && typeof m === "object" && typeof m.id === "string" && ID_RE.test(m.id) && m.id.length <= 120)
        o.push({ id: m.id, n: str(m.n || m.id, 200), v: str(m.v, 80), w: m.w === true, a: m.a === true, e: m.e === true, d: str(m.d, 300) });
    }
    return o;
  }
  function cleanFavs(list) {
    return uniq((Array.isArray(list) ? list : []).filter(function (x) { return typeof x === "string" && ID_RE.test(x) && x.length <= 120; })).slice(0, MAXN);
  }

  function readRaw() {
    if (mem !== null) return mem;
    try { return window.localStorage.getItem(KEY); } catch (e) { return null; }
  }
  function cached() {
    var raw = readRaw(), c;
    if (!raw) return null;
    try { c = JSON.parse(raw); } catch (e) { return null; }
    if (!c || typeof c !== "object" || c.v !== VER || typeof c.t !== "number" || !isFinite(c.t) || c.t <= 0 || c.t > Date.now() + 864e5 || !Array.isArray(c.modules)) return null;
    return { t: c.t, modules: cleanMods(c.modules), favs: cleanFavs(c.favs) };
  }
  function saveCache(res) {
    if (!res || typeof res.at !== "number" || !Array.isArray(res.modules)) return false;
    var raw = JSON.stringify({ v: VER, t: res.at, modules: cleanMods(res.modules), favs: cleanFavs(res.favs) });
    if (raw.length > MAXBYTES) { clearCache(); return false; }
    try { window.localStorage.setItem(KEY, raw); mem = null; return true; } catch (e) { mem = raw; return false; }
  }
  function clearCache() { mem = null; try { window.localStorage.removeItem(KEY); } catch (e) {} }

  window.MDScan = { scan: scan, parse: parse, cached: cached, saveCache: saveCache, clearCache: clearCache };
})();
