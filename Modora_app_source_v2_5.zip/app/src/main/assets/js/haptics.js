/* Modora haptics (MB6.3b). Classic script (<script defer>), no modules. Requires js/bridge.js (MD.bridge.vibrate/has) but degrades to doing nothing.
 * One native call only: ksu.vibrate(ms) (one-shot, <= 200 ms, already in MainActivity). No patterns, no root, no new native method.
 * Preference: localStorage "md.haptics" = "1" | "0" (default "1" = on), memory fallback if storage throws.
 * A pulse is sent only when: the preference is on, the native method exists, the page is visible, and >= 60 ms passed since the last one
 * (error() is never dropped by that gap: a failure right after a tick must still be felt).
 * API: MDHaptics.available()  -> bool  (native vibrate method exists; this cannot prove the phone will actually buzz)
 *      MDHaptics.enabled()    -> bool  (preference AND available)      MDHaptics.pref() -> bool (preference only)
 *      MDHaptics.setPref(bool) -> bool saved to localStorage
 *      MDHaptics.tap() 15 ms | confirm() 30 ms | error() 45 ms  -> bool (true = a pulse was sent)
 *      MDHaptics.test()       -> bool  (ignores the preference and the throttle: used by the Settings "Test" button; needs available())
 *      MDHaptics.onChange(fn) -> unsubscribe
 */
(function () {
  "use strict";
  var KEY = "md.haptics", GAP = 60, last = 0, memVal = null, subs = [];

  function B() { try { return window.MD && window.MD.bridge ? window.MD.bridge : null; } catch (e) { return null; } }
  function ls() { try { return window.localStorage || null; } catch (e) { return null; } }
  function available() { var b = B(); try { return !!(b && typeof b.has === "function" && b.has("vibrate") && typeof b.vibrate === "function"); } catch (e) { return false; } }
  function pref() {
    var v = memVal, s = ls();
    if (v === null && s) { try { v = s.getItem(KEY); } catch (e) { v = null; } }
    return v !== "0";
  }
  function setPref(on) {
    var v = on ? "1" : "0", s = ls(), stored = false;
    if (s) { try { s.setItem(KEY, v); stored = true; memVal = null; } catch (e) {} }
    if (!stored) memVal = v;
    subs.slice().forEach(function (f) { try { f(); } catch (e) {} });
    return stored;
  }
  function send(ms, force, noGap) {
    if (!force && !(pref() && available())) return false;
    if (force && !available()) return false;
    if (!force) {
      if (typeof document !== "undefined" && document.hidden) return false;
      var now = Date.now(); if (!noGap && now - last < GAP) return false; last = now;
    }
    try { return B().vibrate(ms) === true; } catch (e) { return false; }
  }

  window.MDHaptics = {
    available: available, pref: pref, setPref: setPref,
    enabled: function () { return pref() && available(); },
    tap: function () { return send(15); }, confirm: function () { return send(30); }, error: function () { return send(45, false, true); },
    test: function () { return send(30, true); },
    onChange: function (fn) { if (typeof fn !== "function") return function () {}; subs.push(fn); return function () { var i = subs.indexOf(fn); if (i > -1) subs.splice(i, 1); }; },
    _reset: function () { memVal = null; last = 0; }   // tests only
  };
})();
