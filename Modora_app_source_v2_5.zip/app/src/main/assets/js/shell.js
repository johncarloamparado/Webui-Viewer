/* Modora app shell (MB2.1). Classic script (<script defer>), no modules.
 * Builds the bottom tab bar from ONE registry and wires it to MDRouter (js/router.js).
 * RULE: a tab is live only when its view exists in the page (<section class="md-view" data-view="NAME">).
 *       A tab whose view is not built yet is rendered dimmed, aria-disabled and labelled "Soon"; tapping it
 *       only shows a toast. Later batches enable a tab simply by adding its view (MB2.3 modules, MB2.5 settings).
 * Back: handled by MDRouter (overlay -> previous route -> native). Tabs use MDRouter.tab(): back from a tab
 *       returns to the home tab, back from home leaves the app.
 * Requires: icons.js, router.js, i18n.js (+ i18n.en.js) loaded first. Every dependency has a safe fallback.
 * API: window.MDShell { tabs(), open(name) -> bool, ready() }
 */
(function () {
  "use strict";
  var TABS = [
    { id: "deck",     icon: "layers",   key: "nav.deck",     en: "Deck" },
    { id: "modules",  icon: "puzzle",   key: "nav.modules",  en: "Modules" },
    { id: "tools",    icon: "terminal", key: "nav.tools",    en: "Tools" },
    { id: "settings", icon: "settings", key: "nav.settings", en: "Settings" }
  ];
  var HOME = "deck", bar = null, built = false;

  function t(key, fallback) {
    try { if (window.MDI18n) { var s = window.MDI18n.t(key); if (s && s !== key) return s; } } catch (e) {}
    return fallback;
  }
  function live(name) { return !!(window.MDRouter && window.MDRouter.has(name)); }
  function icon(n) { try { return window.MDIcons ? window.MDIcons.svg(n) : ""; } catch (e) { return ""; } }

  function toast(msg) {                                    // reuse the page toast element if there is one
    var el = document.getElementById("toast");
    if (!el) return;
    el.textContent = msg; el.style.opacity = "1";
    clearTimeout(toast.tm); toast.tm = setTimeout(function () { el.style.opacity = "0"; }, 2200);
  }

  function open(name) {
    if (!live(name)) { toast(t("nav.soon_toast", "Coming in a later update")); return false; }
    var cur = window.MDRouter.current();
    if (cur && cur.name === name) { try { window.scrollTo({ top: 0, behavior: "smooth" }); } catch (e) { window.scrollTo(0, 0); } return true; }
    return window.MDRouter.tab(name);
  }

  function mark(name) {
    if (!bar) return;
    var btns = bar.querySelectorAll(".md-tab");
    for (var i = 0; i < btns.length; i++) {
      if (btns[i].getAttribute("data-tab") === name) btns[i].setAttribute("aria-current", "page");
      else btns[i].removeAttribute("aria-current");
    }
  }

  function build() {
    var inner = document.createElement("div"); inner.className = "md-tabbar-in";
    TABS.forEach(function (tb) {
      var on = live(tb.id), label = t(tb.key, tb.en), b = document.createElement("button");
      b.type = "button"; b.className = "md-tab"; b.setAttribute("data-tab", tb.id);
      if (!on) { b.setAttribute("aria-disabled", "true"); b.setAttribute("aria-label", label + ", " + t("nav.soon", "Soon")); }
      // markup below is built only from our fixed registry + MDIcons.svg output; labels are set via textContent
      b.innerHTML = '<span class="md-tab-ico">' + icon(tb.icon) + '</span><span class="md-tab-label"></span>' +
        (on ? "" : '<span class="md-tab-soon" aria-hidden="true"></span>');
      b.querySelector(".md-tab-label").textContent = label;
      var soon = b.querySelector(".md-tab-soon"); if (soon) soon.textContent = t("nav.soon", "Soon");
      b.addEventListener("click", function () { open(tb.id); });
      inner.appendChild(b);
    });
    bar.textContent = ""; bar.appendChild(inner);
    built = true;
    document.body.classList.add("has-tabbar");
  }

  function keyboardGuard() {                                // bar would ride above the soft keyboard; hide it while typing
    var TEXT = { text: 1, search: 1, url: 1, email: 1, tel: 1, password: 1, number: 1 };
    function isText(el) {
      if (!el || !el.tagName) return false;
      var n = el.tagName.toLowerCase();
      return n === "textarea" || (n === "input" && (!el.type || TEXT[el.type]));
    }
    function clearIfNotText() { if (!isText(document.activeElement)) document.body.classList.remove("md-kbd"); }
    document.addEventListener("focusin", function (e) { if (isText(e.target)) document.body.classList.add("md-kbd"); else clearIfNotText(); });
    document.addEventListener("focusout", function () { setTimeout(clearIfNotText, 60); });
    document.addEventListener("change", function (e) { if (e.target && e.target.tagName && e.target.tagName.toLowerCase() === "select") setTimeout(clearIfNotText, 0); });
    document.addEventListener("blur", function (e) { if (e.target && e.target.tagName && e.target.tagName.toLowerCase() === "select") setTimeout(clearIfNotText, 0); }, true);
    window.addEventListener("resize", function () {
      var vv = window.visualViewport;
      if (!vv || vv.height >= window.innerHeight * 0.8) clearIfNotText();
    });
    document.addEventListener("visibilitychange", clearIfNotText);
    setInterval(clearIfNotText, 250);
  }

  function init() {
    bar = document.getElementById("md-tabbar");
    if (!bar || !window.MDRouter) return false;
    var ok = window.MDRouter.init({ home: HOME, fallback: HOME });
    if (!ok) return false;                                   // no views: leave the legacy page exactly as it was
    build(); keyboardGuard();
    window.MDRouter.onChange(function (e) { mark(e.name); });
    var cur = window.MDRouter.current(); mark(cur ? cur.name : HOME);
    return true;
  }

  window.MDShell = {
    tabs: function () { return TABS.map(function (x) { return { id: x.id, live: live(x.id) }; }); },
    open: open, ready: function () { return built; }
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
