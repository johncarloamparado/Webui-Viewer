/* Modora icons (MB1.3) - classic script, no modules.
 * WHY: external <use href="img/icons.svg#x"> is blocked from file:// pages
 * ("file: URLs are treated as unique security origins", verified in Chromium),
 * and the app loads file:///android_asset/*. So the sprite is injected INLINE and
 * icons are referenced same-document:  <svg class="md-icon" aria-hidden="true"><use href="#i-NAME"/></svg>
 * Source of truth for artwork: img/icons.svg. If you edit one, regenerate the other
 * (the symbol bodies below are exactly the <symbol> contents of icons.svg).
 * API: window.MDIcons { names(), has(n), svg(n, {cls, label}) -> markup string, inject() }
 * Load with <script defer src="js/icons.js">. Safe to call inject() more than once.
 */
(function () {
  "use strict";
  var ATTR = 'viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"';
  var BODY = {
  "home": "<path d=\"M3 11.5 12 4l9 7.5\"/><path d=\"M5.5 10v9.5h13V10\"/><path d=\"M10 19.5v-5h4v5\"/>",
  "layers": "<path d=\"m12 3 9 5-9 5-9-5 9-5Z\"/><path d=\"m3 12.5 9 5 9-5\"/><path d=\"m3 16.5 9 5 9-5\"/>",
  "puzzle": "<path d=\"M10 4.5a2 2 0 1 1 4 0V6h4a1 1 0 0 1 1 1v4h-1.5a2 2 0 1 0 0 4H19v4a1 1 0 0 1-1 1h-4v-1.5a2 2 0 1 0-4 0V20H6a1 1 0 0 1-1-1v-4h1.5a2 2 0 1 0 0-4H5V7a1 1 0 0 1 1-1h4V4.5Z\"/>",
  "settings": "<circle cx=\"12\" cy=\"12\" r=\"3\"/><path d=\"M19.4 14a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V20a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H4a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H10a1.7 1.7 0 0 0 1-1.5V4a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V10a1.7 1.7 0 0 0 1.5 1H20a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z\"/>",
  "search": "<circle cx=\"11\" cy=\"11\" r=\"6.5\"/><path d=\"m20 20-4.2-4.2\"/>",
  "plus": "<path d=\"M12 5v14M5 12h14\"/>",
  "x": "<path d=\"M6 6l12 12M18 6 6 18\"/>",
  "check": "<path d=\"m5 12.5 4.5 4.5L19 7.5\"/>",
  "chevron-right": "<path d=\"m9 6 6 6-6 6\"/>",
  "chevron-left": "<path d=\"m15 6-6 6 6 6\"/>",
  "chevron-down": "<path d=\"m6 9 6 6 6-6\"/>",
  "chevron-up": "<path d=\"m6 15 6-6 6 6\"/>",
  "arrow-up": "<path d=\"M12 19V5M6 11l6-6 6 6\"/>",
  "arrow-down": "<path d=\"M12 5v14M6 13l6 6 6-6\"/>",
  "trash": "<path d=\"M4 7h16\"/><path d=\"M9 7V4.5h6V7\"/><path d=\"M6.5 7l1 13h9l1-13\"/><path d=\"M10 11v6M14 11v6\"/>",
  "undo": "<path d=\"M9 14 4 9l5-5\"/><path d=\"M4 9h10a6 6 0 0 1 0 12h-3\"/>",
  "refresh": "<path d=\"M20 11a8 8 0 0 0-14.5-4.2L4 9\"/><path d=\"M4 4v5h5\"/><path d=\"M4 13a8 8 0 0 0 14.5 4.2L20 15\"/><path d=\"M20 20v-5h-5\"/>",
  "power": "<path d=\"M12 3v9\"/><path d=\"M6.3 6.8a8 8 0 1 0 11.4 0\"/>",
  "download": "<path d=\"M12 4v11\"/><path d=\"m7 10.5 5 5 5-5\"/><path d=\"M5 20h14\"/>",
  "upload": "<path d=\"M12 16V5\"/><path d=\"m7 9.5 5-5 5 5\"/><path d=\"M5 20h14\"/>",
  "copy": "<rect x=\"8.5\" y=\"8.5\" width=\"11\" height=\"11\" rx=\"2\"/><path d=\"M15.5 8.5V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v7.5a2 2 0 0 0 2 2h2.5\"/>",
  "share": "<circle cx=\"6\" cy=\"12\" r=\"2.5\"/><circle cx=\"18\" cy=\"6\" r=\"2.5\"/><circle cx=\"18\" cy=\"18\" r=\"2.5\"/><path d=\"m8.2 10.8 7.6-3.6M8.2 13.2l7.6 3.6\"/>",
  "external": "<path d=\"M14 4h6v6\"/><path d=\"M20 4 11 13\"/><path d=\"M18 14v4.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 4 18.5v-11A1.5 1.5 0 0 1 5.5 6H10\"/>",
  "info": "<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M12 11v5.5\"/><path d=\"M12 7.6v.1\"/>",
  "alert-triangle": "<path d=\"M10.3 4.2 2.9 17.5A2 2 0 0 0 4.6 20.5h14.8a2 2 0 0 0 1.7-3L13.7 4.2a2 2 0 0 0-3.4 0Z\"/><path d=\"M12 9.5v4.5\"/><path d=\"M12 17.3v.1\"/>",
  "alert-circle": "<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M12 7.5v5.5\"/><path d=\"M12 16.4v.1\"/>",
  "check-circle": "<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"m8 12.3 2.8 2.8L16.3 9.5\"/>",
  "folder": "<path d=\"M3.5 7.5a2 2 0 0 1 2-2h4l2 2.5h7a2 2 0 0 1 2 2v7.5a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2V7.5Z\"/>",
  "file": "<path d=\"M14 3.5H7a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8.5L14 3.5Z\"/><path d=\"M14 3.5v5h5\"/>",
  "terminal": "<rect x=\"3\" y=\"4.5\" width=\"18\" height=\"15\" rx=\"2.5\"/><path d=\"m7.5 10 3 2.5-3 2.5\"/><path d=\"M13 15.5h3.5\"/>",
  "sliders": "<path d=\"M4 7h9M17 7h3M4 17h3M11 17h9\"/><circle cx=\"15\" cy=\"7\" r=\"2\"/><circle cx=\"9\" cy=\"17\" r=\"2\"/>",
  "sun": "<circle cx=\"12\" cy=\"12\" r=\"4\"/><path d=\"M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6 7 7M17 17l1.4 1.4M18.4 5.6 17 7M7 17l-1.4 1.4\"/>",
  "moon": "<path d=\"M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5Z\"/>",
  "contrast": "<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M12 3v18\" /><path d=\"M12 3a9 9 0 0 1 0 18Z\" fill=\"currentColor\" stroke=\"none\"/>",
  "more": "<circle cx=\"5.5\" cy=\"12\" r=\"1.2\" fill=\"currentColor\"/><circle cx=\"12\" cy=\"12\" r=\"1.2\" fill=\"currentColor\"/><circle cx=\"18.5\" cy=\"12\" r=\"1.2\" fill=\"currentColor\"/>",
  "menu": "<path d=\"M4 7h16M4 12h16M4 17h16\"/>",
  "grip": "<circle cx=\"9\" cy=\"6.5\" r=\"1.2\" fill=\"currentColor\"/><circle cx=\"15\" cy=\"6.5\" r=\"1.2\" fill=\"currentColor\"/><circle cx=\"9\" cy=\"12\" r=\"1.2\" fill=\"currentColor\"/><circle cx=\"15\" cy=\"12\" r=\"1.2\" fill=\"currentColor\"/><circle cx=\"9\" cy=\"17.5\" r=\"1.2\" fill=\"currentColor\"/><circle cx=\"15\" cy=\"17.5\" r=\"1.2\" fill=\"currentColor\"/>",
  "bolt": "<path d=\"M13 3 5 13.5h6L10 21l8-10.5h-6L13 3Z\"/>",
  "shield": "<path d=\"M12 3.5 5 6v5.5c0 4.3 2.9 7.6 7 9 4.1-1.4 7-4.7 7-9V6l-7-2.5Z\"/>",
  "cpu": "<rect x=\"6\" y=\"6\" width=\"12\" height=\"12\" rx=\"2\"/><rect x=\"9.5\" y=\"9.5\" width=\"5\" height=\"5\" rx=\".8\"/><path d=\"M9 3v3M15 3v3M9 18v3M15 18v3M3 9h3M3 15h3M18 9h3M18 15h3\"/>",
  "tag": "<path d=\"M3.5 12.2V5.5a2 2 0 0 1 2-2h6.7l8.3 8.3a2 2 0 0 1 0 2.8l-6.7 6.7a2 2 0 0 1-2.8 0L3.5 12.2Z\"/><path d=\"M8 8v.1\"/>",
  "filter": "<path d=\"M4 5.5h16l-6 7.5v5.5l-4 2V13L4 5.5Z\"/>",
  "star": "<path d=\"m12 3.8 2.5 5.2 5.7.8-4.1 4 1 5.7-5.1-2.7-5.1 2.7 1-5.7-4.1-4 5.7-.8L12 3.8Z\"/>",
  "globe": "<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M3 12h18\"/><path d=\"M12 3c2.5 2.6 3.8 5.6 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3Z\"/>",
  "eye": "<path d=\"M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z\"/><circle cx=\"12\" cy=\"12\" r=\"2.8\"/>",
  "eye-off": "<path d=\"M4 4l16 16\"/><path d=\"M10 6a9 9 0 0 1 2-.5c6 0 9.5 6.5 9.5 6.5a16 16 0 0 1-3 3.8M6.3 7.8A16 16 0 0 0 2.5 12S6 18.5 12 18.5c1.4 0 2.7-.3 3.8-.8\"/><path d=\"M9.9 9.9a2.8 2.8 0 0 0 4 4\"/>",
  "package": "<path d=\"M12 3 4 7v10l8 4 8-4V7l-8-4Z\"/><path d=\"m4 7 8 4 8-4\"/><path d=\"M12 11v10\"/>",
  "pencil": "<path d=\"M4 20h4L19 9a2.1 2.1 0 0 0-3-3L5 17v3Z\"/><path d=\"m14.5 7.5 3 3\"/>",
  "pin": "<path d=\"M9 4h6l-1 6 3 3H7l3-3-1-6Z\"/><path d=\"M12 13v7\"/>",
  "x-circle": "<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"m9 9 6 6M15 9l-6 6\"/>",
  "clock": "<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M12 7v5l3.2 2\"/>",
  "lock": "<rect x=\"5\" y=\"10.5\" width=\"14\" height=\"10\" rx=\"2\"/><path d=\"M8 10.5V8a4 4 0 0 1 8 0v2.5\"/>",
  };
  function esc(s) { return String(s).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
  function has(n) { return Object.prototype.hasOwnProperty.call(BODY, n); }
  function names() { return Object.keys(BODY); }
  function svg(n, o) {
    o = o || {};
    if (!has(n)) return "";
    var cls = "md-icon" + (o.cls ? " " + esc(o.cls) : "");
    var a11y = o.label ? 'role="img" aria-label="' + esc(o.label) + '"' : 'aria-hidden="true" focusable="false"';
    return '<svg class="' + cls + '" ' + a11y + '><use href="#i-' + n + '"/></svg>';
  }
  function inject() {
    if (!document.body || document.getElementById("md-icon-sprite")) return;
    var out = '<svg id="md-icon-sprite" xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false">';
    for (var k in BODY) if (has(k)) out += '<symbol id="i-' + k + '" ' + ATTR + '>' + BODY[k] + '</symbol>';
    out += "</svg>";
    document.body.insertAdjacentHTML("afterbegin", out);
  }
  window.MDIcons = { names: names, has: has, svg: svg, inject: inject };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", inject);
  else inject();
})();
