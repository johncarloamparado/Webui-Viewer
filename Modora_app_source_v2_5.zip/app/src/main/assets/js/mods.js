/* Modora module actions (MB2.3). Classic script (<script defer>), no modules. Requires js/bridge.js (MD.sh, MD.shq).
 * Only operations that already existed in the v2.4 deck, now VERIFIED after running:
 *   enable  = rm -f  /data/adb/modules/<id>/disable        disable = touch /data/adb/modules/<id>/disable
 * Every call re-reads the flag file and reports success ONLY when the file state matches the request.
 * There is NO uninstall here: "Remove" in the deck only removes a module from the deck list (no verified uninstall command).
 * API: MDMods.setEnabled(id, enable, {timeout}) -> Promise<{ok, id, enabled, reason}>   (NEVER rejects)
 *        reason: invalid|nobridge|nomodule|timeout|bridge|failed|noroot  (ok:false only)
 *      MDMods.setEnabledMany(ids, enable) -> Promise<{ok:[ids], failed:[{id, reason}]}>   (sequential, never rejects)
 *      MDMods.cmd(id, enable) -> shell text (pure; used by tests)   MDMods.parse(out) -> "0"|"1"|"nomodule"|"" (pure)
 */
(function () {
  "use strict";
  var MD = (window.MD = window.MD || {});
  var ID_RE = /^[A-Za-z0-9._-]+$/, BASE = "/data/adb/modules/", TIMEOUT = 10000;

  function validId(id) { return typeof id === "string" && id.length > 0 && id.length <= 120 && ID_RE.test(id) && id !== "." && id !== ".."; }

  function cmd(id, enable) {
    var q = MD.shq, dir = q(BASE + id), flag = q(BASE + id + "/disable");
    return "[ -d " + dir + " ] || { echo @nomodule; exit 0; }\n" +
      (enable ? "rm -f " + flag : "touch " + flag) + "\n" +
      "if [ -f " + flag + " ]; then echo @d1; else echo @d0; fi";
  }

  function parse(out) {
    var s = String(out == null ? "" : out), m = s.match(/@(nomodule|d[01])\s*$/m);
    return m ? (m[1] === "nomodule" ? "nomodule" : m[1].charAt(1)) : "";
  }

  function setEnabled(id, enable, o) {
    o = o || {};
    return new Promise(function (resolve) {
      var fail = function (reason) { resolve({ ok: false, id: id, enabled: null, reason: reason }); };
      if (!validId(id)) return fail("invalid");
      if (!MD.sh || !MD.shq || !MD.bridge || !MD.bridge.available()) return fail("nobridge");
      var c; try { c = cmd(id, !!enable); } catch (e) { return fail("invalid"); }
      MD.sh(c, { timeout: o.timeout || TIMEOUT }).then(function (r) {
        if (r.code === -2 || r.code === -3) return fail("timeout");
        if (r.code === -1 || r.code === -4 || r.code === -5) return fail("bridge");
        var p = parse(r.out);
        if (p === "nomodule") return fail("nomodule");
        if (p === "") return fail(r.code === 0 ? "failed" : "noroot");
        var nowEnabled = p === "0";                       // @d0 = no disable flag = enabled
        if (nowEnabled !== !!enable) return fail("failed");   // command ran but the file state is not what was asked
        resolve({ ok: true, id: id, enabled: nowEnabled, reason: "" });
      }, function () { fail("bridge"); });
    });
  }

  function setEnabledMany(ids, enable, o) {
    var res = { ok: [], failed: [] }, list = (ids || []).slice(), i = 0;
    return new Promise(function (resolve) {
      (function next() {
        if (i >= list.length) return resolve(res);
        var id = list[i++];
        setEnabled(id, enable, o).then(function (r) {
          if (r.ok) res.ok.push(id); else res.failed.push({ id: id, reason: r.reason });
          next();
        });
      })();
    });
  }

  window.MDMods = { setEnabled: setEnabled, setEnabledMany: setEnabledMany, cmd: cmd, parse: parse, validId: validId };
})();
