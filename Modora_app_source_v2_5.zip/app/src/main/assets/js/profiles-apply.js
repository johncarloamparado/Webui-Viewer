/* Modora profile diff + apply (MB5.2). Classic script (<script defer>), no modules. Requires js/bridge.js (MD.sh, MD.shq, MD.bridge) and js/profiles.js (MDProfiles).
 * plan(id)   -> Promise<Plan>   reads the CURRENT tuner configs from the device (read-only commands) and computes exactly what would be written.
 * apply(plan)-> Promise<Result> re-reads the device, REFUSES (stale) if the plan no longer matches, then writes the SAME text/commands the tuner pages write
 *               (rme50: write config, then `sh MOD/apply.sh`; anr: write config + apply.sh in one command) and reads the config back to verify.
 * The preview and the write share one object: Plan.sections[].text is what is written, Plan.sections[].rows is what is shown. Nothing else is written.
 * Config format, key ORDER, defaults, load rules, paths and command text mirror js/rme50.js and js/anr.js byte for byte (see TARGETS). Do not change them here
 * without changing the tuner pages. Dynamic values are validated to /^[A-Za-z0-9_-]+$/ before they reach a command (defence in depth on top of MDProfiles.SCHEMA).
 * Skipped (never written) settings: a CPU governor that is not in the device's scaling_available_governors (or cannot be verified), a refresh rate the panel does not
 * report (only when the panel reports its modes), and any value the tuner page itself could not read back (governor containing "."). A skipped row keeps the CURRENT value.
 * Plan: {ok, reason?, profileId, name, sections:[{id, state:"ready"|"module_missing", rows:[{key, from, to, final, status:"change"|"same"|"skip", why, reboot}], changes, reboot, text, writeCmd, applyCmd}], changes, reboot, sig}
 * Result: {ok, stale?, reason?, sections:[{id, state:"applied"|"apply_failed"|"write_failed"|"unverified"|"mismatch"|"skipped", code, err}], reboot}
 * NEVER rejects. Single-flight: a second apply() while one runs returns {ok:false, reason:"busy"}.
 */
(function () {
  "use strict";
  var MD = (window.MD = window.MD || {});
  var SAFE = /^[A-Za-z0-9_-]+$/, busy = false;

  var TARGETS = {
    rme50: {
      dir: "/data/adb/rme50_60hz_sf_fix", cfg: "/data/adb/rme50_60hz_sf_fix/config.conf", mod: "/data/adb/modules/rme50_60hz_sf_fix",
      def: { REFRESH_HZ: "60", DISABLE_HWC: "1", GOVERNOR: "performance", PROP_SF_TIMERS: "1", PROP_GPU: "1", PROP_MEM: "1" },
      reboot: { PROP_SF_TIMERS: 1, PROP_GPU: 1, PROP_MEM: 1 }
    },
    anr: {
      dir: "/data/adb/anr_dialog_limiter", cfg: "/data/adb/anr_dialog_limiter/config.conf", mod: "/data/adb/modules/anr_dialog_limiter",
      def: { MODE: "limit", LIMIT: "3", WINDOW_MIN: "10", TIMEOUT_MULT: "2" },
      reboot: { TIMEOUT_MULT: 1 }
    }
  };
  var ORDER = ["rme50", "anr"];

  /* ---- pure helpers (exported for tests) ---- */
  function parseCfg(id, out) {                         /* same rules as the tuner pages' load() */
    var T = TARGETS[id], cfg = {}, k;
    for (k in T.def) cfg[k] = T.def[k];
    String(out == null ? "" : out).split("\n").forEach(function (l) {
      if (id === "rme50") {
        var m = l.match(/^([A-Z0-9_]+)=([A-Za-z0-9_-]+)$/);
        if (m && Object.prototype.hasOwnProperty.call(T.def, m[1])) cfg[m[1]] = m[2];
      } else {
        var i = l.indexOf("=");
        if (i > 0) { var key = l.slice(0, i), v = l.slice(i + 1).trim(); if (Object.prototype.hasOwnProperty.call(T.def, key) && /^[a-z0-9]+$/.test(v)) cfg[key] = v; }
      }
    });
    return cfg;
  }
  function cfgText(id, cfg) { return Object.keys(TARGETS[id].def).map(function (k) { return k + "=" + cfg[k]; }).join("\n"); }
  function writeCmd(id, cfg) {                         /* the tuner pages' exact text */
    var T = TARGETS[id], b = cfgText(id, cfg);
    return "mkdir -p " + T.dir + "; printf '%s\\n' '" + b + "' > " + T.cfg;
  }
  function applyCmd(id) { return "sh " + TARGETS[id].mod + "/apply.sh"; }
  function parseGovs(out) { return ["default"].concat(String(out || "").trim().split(/\s+/).filter(function (x) { return /^[A-Za-z0-9_-]+$/.test(x); })); }
  function parseModes(out) {                           /* same as rme50.js probe() */
    var seen = {}, m = [];
    String(out || "").split("\n").forEach(function (x) { var n = Math.round(parseFloat(x.split("=")[1])); if (n >= 24 && n <= 165 && !seen[n]) { seen[n] = 1; m.push(n); } });
    return m.sort(function (a, b) { return a - b; });
  }

  /* env = {govs:[...]|null, modes:[...]}; returns a section (without device state) for profile values `vals` over current config `cur` */
  function buildSection(id, vals, cur, env) {
    var T = TARGETS[id], fin = {}, k, rows = [], changes = 0, reboot = false;
    for (k in cur) fin[k] = cur[k];
    Object.keys(T.def).forEach(function (key) {
      if (!vals || vals[key] == null) return;
      var to = String(vals[key]), row = { key: key, from: cur[key], to: to, final: cur[key], status: "same", why: null, reboot: false };
      if (id === "rme50" && key === "GOVERNOR") {
        if (!SAFE.test(to)) { row.status = "skip"; row.why = "chars"; }
        else if (to !== "default" && !(env.govs && env.govs.indexOf(to) >= 0)) { row.status = "skip"; row.why = env.govs && env.govs.length > 1 ? "gov" : "gov_unknown"; }
      } else if (id === "rme50" && key === "REFRESH_HZ") {
        if (to !== "auto" && env.modes && env.modes.length && env.modes.indexOf(+to) < 0) { row.status = "skip"; row.why = "hz"; }
      }
      if (row.status !== "skip") {
        if (!SAFE.test(to)) { row.status = "skip"; row.why = "chars"; }
        else { row.final = to; fin[key] = to; if (to !== cur[key]) { row.status = "change"; changes++; if (T.reboot[key]) { row.reboot = true; reboot = true; } } }
      }
      rows.push(row);
    });
    return { id: id, state: "ready", rows: rows, changes: changes, reboot: reboot, cur: cur, fin: fin, text: cfgText(id, fin), writeCmd: writeCmd(id, fin), applyCmd: applyCmd(id) };
  }

  /* ---- device reads (read-only commands) ---- */
  function readSection(id, vals, shell, light) {
    var T = TARGETS[id], env = { govs: null, modes: [] };
    return shell("[ -f " + T.mod + "/apply.sh ] && echo yes || echo no", { timeout: 15000 }).then(function (ex) {
      var e = String(ex.out).trim();
      if (ex.code !== 0 || (e !== "yes" && e !== "no")) return { fail: "noroot" };
      if (e === "no") return { sec: { id: id, state: "module_missing", rows: [], changes: 0, reboot: false, text: "" } };
      return shell("cat " + T.cfg + " 2>/dev/null", { timeout: 15000 }).then(function (c) {
        var cur = parseCfg(id, c.out);
        if (id !== "rme50" || light) return { sec: buildSection(id, vals, cur, env) };
        return shell("cat /sys/devices/system/cpu/cpufreq/policy0/scaling_available_governors", { timeout: 15000 }).then(function (g) {
          env.govs = g.code === 0 ? parseGovs(g.out) : null;
          return shell('dumpsys display | grep -oE "fps=[0-9]+(\\\\.[0-9]+)?" | sort -u', { timeout: 15000 }).then(function (d) {
            env.modes = d.code === 0 ? parseModes(d.out) : [];
            return { sec: buildSection(id, vals, cur, env) };
          });
        });
      });
    });
  }
  function sigOf(sections) { return JSON.stringify(sections.map(function (s) { return [s.id, s.state, s.text, s.cur ? cfgText(s.id, s.cur) : ""]; })); }

  function plan(profileId) {
    var P = window.MDProfiles;
    return planFor(P && P.get ? P.get(profileId) : null, false);
  }
  /* MB5.3: same planner for a profile-shaped object that is NOT in MDProfiles (a restored backup). p = {id, name, rme50?, anr?}, values already validated by the caller.
   * The plan carries custom:true + src:p so apply() re-plans from the same object. Built-in profiles keep the original path (plan(id)). */
  function planCustom(p) { return planFor(p && typeof p === "object" ? p : null, true); }
  function planFor(p, custom) {
    return new Promise(function (resolve) {
      if (!p) return resolve({ ok: false, reason: "noprofile" });
      if (!MD.sh || !MD.bridge || !MD.bridge.available()) return resolve({ ok: false, reason: "nobridge", profileId: p.id, name: p.name });
      var out = [], chain = Promise.resolve(), failed = null;
      ORDER.forEach(function (id) {
        if (!p[id]) return;
        chain = chain.then(function () {
          if (failed) return;
          return readSection(id, p[id], MD.sh).then(function (r) { if (r.fail) failed = r.fail; else out.push(r.sec); });
        });
      });
      chain.then(function () {
        if (failed) return resolve({ ok: false, reason: failed, profileId: p.id, name: p.name });
        var n = 0, rb = false;
        out.forEach(function (s) { n += s.changes; if (s.reboot) rb = true; });
        var res = { ok: true, profileId: p.id, name: p.name, sections: out, changes: n, reboot: rb, sig: sigOf(out) };
        if (custom) { res.custom = true; res.src = p; }
        resolve(res);
      }, function () { resolve({ ok: false, reason: "error", profileId: p.id, name: p.name }); });
    });
  }

  /* MB5.3: read-only read of the CURRENT tuner configs for a backup. -> {ok, reason?, cfg:{rme50?:{...}, anr?:{...}}, missing:[ids]}. Never rejects.
   * A module whose apply.sh is missing is reported in `missing` (not in cfg). A missing config file reads as the page defaults, exactly like the tuner pages. */
  function readCurrent() {
    return new Promise(function (resolve) {
      if (!MD.sh || !MD.bridge || !MD.bridge.available()) return resolve({ ok: false, reason: "nobridge" });
      var cfg = {}, missing = [], chain = Promise.resolve(), failed = null;
      ORDER.forEach(function (id) {
        chain = chain.then(function () {
          if (failed) return;
          return readSection(id, null, MD.sh, true).then(function (r) {
            if (r.fail) failed = r.fail; else if (r.sec.state === "module_missing") missing.push(id); else cfg[id] = r.sec.cur;
          });
        });
      });
      chain.then(function () { resolve(failed ? { ok: false, reason: failed } : { ok: true, cfg: cfg, missing: missing }); }, function () { resolve({ ok: false, reason: "error" }); });
    });
  }

  /* ---- apply ---- */
  function readBack(s) {                               /* "match" | "mismatch" | "unreadable" (bridge problem, not a file problem) */
    var T = TARGETS[s.id];
    return MD.sh("cat " + T.cfg + " 2>/dev/null", { timeout: 15000 }).then(function (r) {
      if (r.code < 0) return "unreadable";
      return r.code === 0 && cfgText(s.id, parseCfg(s.id, r.out)) === s.text ? "match" : "mismatch";
    });
  }
  function applySection(s) {
    var res = { id: s.id, state: "applied", code: 0, err: "" };
    var note = function (r) { res.code = r.code; res.err = String(r.err || "").split("\n")[0].slice(0, 160); };
    var check = function (okState) {
      return readBack(s).then(function (v) {
        if (v === "mismatch") res.state = "mismatch"; else if (v === "unreadable") res.state = "unverified"; else res.state = okState;
        return res;
      });
    };
    if (s.id === "rme50") {
      return MD.sh(s.writeCmd, { timeout: 30000 }).then(function (w) {
        if (w.code !== 0) { note(w); res.state = "write_failed"; return res; }
        return MD.sh(s.applyCmd, { timeout: 60000 }).then(function (a) {
          if (a.code !== 0) { note(a); return check("apply_failed"); }
          return check("applied");
        });
      });
    }
    return MD.sh(s.writeCmd + "; " + s.applyCmd, { timeout: 90000 }).then(function (a) {
      if (a.code !== 0) { note(a); return check("apply_failed"); }
      return check("applied");
    });
  }

  function apply(pl) {
    return new Promise(function (resolve) {
      if (busy) return resolve({ ok: false, reason: "busy" });
      if (!pl || !pl.ok || !pl.sections) return resolve({ ok: false, reason: "badplan" });
      busy = true;
      var done = function (r) { busy = false; resolve(r); };
      (pl.custom ? planFor(pl.src, true) : plan(pl.profileId)).then(function (fresh) {
        if (!fresh.ok) return done({ ok: false, reason: fresh.reason, plan: fresh });
        if (fresh.sig !== pl.sig) return done({ ok: false, stale: true, reason: "stale", plan: fresh });
        var results = [], chain = Promise.resolve(), reboot = false, allOk = true;
        fresh.sections.forEach(function (s) {
          chain = chain.then(function () {
            if (s.state !== "ready" || !s.changes) { results.push({ id: s.id, state: "skipped", code: 0, err: "" }); return; }
            return applySection(s).then(function (r) { results.push(r); if (r.state !== "applied") allOk = false; else if (s.reboot) reboot = true; });
          });
        });
        chain.then(function () { done({ ok: allOk, sections: results, reboot: reboot }); }, function () { done({ ok: false, reason: "error", sections: results }); });
      });
    });
  }

  window.MDProfilesApply = { plan: plan, planCustom: planCustom, readCurrent: readCurrent, apply: apply, busy: function () { return busy; },
    _t: { parseCfg: parseCfg, cfgText: cfgText, writeCmd: writeCmd, applyCmd: applyCmd, parseGovs: parseGovs, parseModes: parseModes, buildSection: buildSection, TARGETS: TARGETS } };
})();
