/* Modora scroll hint (classic script, no modules). Marks every .md-sh container: while its .md-sh-scroll child has more content below
 * the visible part the container gets .has-more (css/scrollhint.css then shows a fade + "Scroll for more" chip). It only toggles a class;
 * it never changes the list's content. Re-checks on scroll, resize, content change and when a hidden sheet is shown.
 * API: MDScrollHint.attach(container) -> detach(), MDScrollHint.scan() (attach every .md-sh not yet attached)
 */
(function () {
  "use strict";
  function attach(box) {
    if (!box || box.__mdsh) return function () {};
    var sc = box.querySelector(".md-sh-scroll"); if (!sc) return function () {};
    box.__mdsh = true;
    function check() { box.classList.toggle("has-more", sc.scrollHeight - sc.scrollTop - sc.clientHeight > 6); }
    sc.addEventListener("scroll", check, { passive: true });
    var ro = null, mo = null;
    try { if (window.ResizeObserver) { ro = new ResizeObserver(check); ro.observe(sc); } } catch (e) {}
    try { if (window.MutationObserver) { mo = new MutationObserver(check); mo.observe(sc, { childList: true, subtree: true }); } } catch (e) {}
    window.addEventListener("resize", check);
    check();
    return function () { sc.removeEventListener("scroll", check); window.removeEventListener("resize", check); if (ro) ro.disconnect(); if (mo) mo.disconnect(); box.__mdsh = false; box.classList.remove("has-more"); };
  }
  function scan() { var l = document.querySelectorAll(".md-sh"); for (var i = 0; i < l.length; i++) attach(l[i]); }
  window.MDScrollHint = { attach: attach, scan: scan };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", scan); else scan();
})();
