/* Modora Settings view (MB2.5). Classic script (<script defer>), no modules. Builds <section data-view="settings"> content.
 * HONESTY RULE: only controls that really work are interactive. Today that is: clear saved scan data, accent (System / Default blue) and haptics on/off + Test (MB6.3b, via js/feel-view.js; disabled with a reason when unsupported) and Help > Show intro (MB8.1, replays js/onboard.js). Language (MB8.2: System default / English / Filipino, reloads the page) is real too. Everything else is
 * a read-only row stating the current value and why it cannot be changed yet. Theme (Dark/Light/System) and Density (Comfortable/Compact) are real since MBFIX.1.
 * All text via textContent. Requires nothing (MDI18n, MDScan, MDPending, MD.bridge are optional).
 */
(function () {
  "use strict";
  function t(k, fb, p) {
    try { if (window.MDI18n) { var s = window.MDI18n.t(k, p); if (s && s !== k) return s; } } catch (e) {}
    return fb.replace(/\{(\w+)\}/g, function (m, n) { return p && p[n] != null ? p[n] : m; });
  }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function toast(m) {
    var e = document.getElementById("toast"); if (!e) return;
    e.textContent = m; e.style.opacity = "1"; e.style.pointerEvents = "none";
    clearTimeout(toast.tm); toast.tm = setTimeout(function () { e.style.opacity = "0"; }, 2200);
  }
  function row(title, value, sub) {
    var r = el("div", "md-set-row"), main = el("div", "md-set-main");
    main.appendChild(el("b", "", title));
    if (sub) main.appendChild(el("small", "", sub));
    r.appendChild(main); if (value) r.appendChild(el("span", "md-set-val", value));
    return r;
  }
  function group(title) { var g = el("section", "md-set-group"); g.appendChild(el("h2", "", title)); return g; }

  // MB8.2: real language control. Options = "system" + every registered strings file (MDI18n.available()); a change is saved
  // by MDI18n.setLang (localStorage md.lang) and the page reloads once so every view/sheet is rebuilt in the new language.
  // Without MDI18n (or with a single language) it stays an honest read-only row.
  function languageRow() {
    var I = window.MDI18n, codes = [];
    try { codes = I && I.available ? I.available().slice().sort() : []; } catch (e) {}
    if (!I || !I.setLang || codes.length < 2) return row(t("settings.language", "Language"), "English");
    var cur = "system"; try { cur = I.pref(); } catch (e) {}
    var r = el("div", "md-set-row md-feel md-feel-col"), top = el("div", "md-feel-top"), main = el("div", "md-set-main");
    main.appendChild(el("b", "", t("settings.language", "Language")));
    main.appendChild(el("small", "", t("settings.language_sub", "Choose the app language. With System default, Modora follows your device language when it is English or Filipino; otherwise it uses English. The screen reloads when you change it.")));
    top.appendChild(main);
    var seg = el("div", "md-seg"); seg.setAttribute("role", "group"); seg.setAttribute("aria-label", t("settings.language", "Language"));
    ["system"].concat(codes).forEach(function (code) {
      var b = el("button", "md-seg-b", code === "system" ? t("lang.system", "System default") : t("lang." + code, code));
      b.type = "button"; b.dataset.lang = code;
      if (code !== "system") b.setAttribute("lang", code);                       // each language name is shown in its own language
      b.setAttribute("aria-pressed", code === cur ? "true" : "false");
      b.addEventListener("click", function () {
        if (code === cur) return;
        var ok = false; try { ok = I.setLang(code); } catch (e) {}
        if (!ok) { toast(t("settings.unavailable", "Unavailable")); return; }
        try { window.location.reload(); } catch (e) {}
      });
      seg.appendChild(b);
    });
    r.appendChild(top); r.appendChild(seg);
    return r;
  }

  // MBFIX.1: generic real choice row (segmented buttons). api = {get(): current, set(v): bool}. Re-marks aria-pressed after a pick; no reload.
  function choiceRow(title, sub, opts, api) {
    var r = el("div", "md-set-row md-feel md-feel-col"), top = el("div", "md-feel-top"), main = el("div", "md-set-main");
    main.appendChild(el("b", "", title)); if (sub) main.appendChild(el("small", "", sub));
    top.appendChild(main);
    var seg = el("div", "md-seg"); seg.setAttribute("role", "group"); seg.setAttribute("aria-label", title);
    var btns = [];
    function mark() { var cur = ""; try { cur = api.get(); } catch (e) {} btns.forEach(function (b) { b.setAttribute("aria-pressed", b.dataset.v === cur ? "true" : "false"); }); }
    opts.forEach(function (o) {
      var b = el("button", "md-seg-b", o[1]); b.type = "button"; b.dataset.v = o[0];
      b.addEventListener("click", function () {
        var ok = false; try { ok = api.set(o[0]); } catch (e) {}
        mark();
        if (!ok) toast(t("settings.not_saved", "Applied, but it could not be saved for next time"));
      });
      btns.push(b); seg.appendChild(b);
    });
    mark(); r.appendChild(top); r.appendChild(seg);
    return r;
  }
  function themeRow() {
    var T = window.MDTheme;
    if (!T || !T.set) return row(t("settings.theme", "Theme"), t("settings.theme_dark", "Dark"));
    return choiceRow(t("settings.theme", "Theme"), t("settings.theme_sub", "Dark, Light, or follow your phone."),
      [["dark", t("theme.dark", "Dark")], ["light", t("theme.light", "Light")], ["system", t("theme.system", "System")]],
      { get: function () { return T.get(); }, set: function (v) { return T.set(v); } });
  }
  function densityRow() {
    var D = window.MDDensity;
    if (!D || !D.set) return row(t("settings.density", "Density"), t("density.comfortable", "Comfortable"));
    return choiceRow(t("settings.density", "Density"), t("settings.density_sub", "Compact fits more on screen. Buttons stay easy to tap."),
      [["comfortable", t("density.comfortable", "Comfortable")], ["compact", t("density.compact", "Compact")]],
      { get: function () { return D.get(); }, set: function (v) { return D.set(v); } });
  }

  // File manager for "Browse" (module zip picker). Real control: the native bridge lists the apps that can pick a file, the choice is stored
  // natively and used by the next Browse. Read-only row with a reason when the bridge lacks these methods (older/other host).
  function fileManagerRow() {
    var k = null; try { k = window.ksu || null; } catch (e) {}
    var can = !!(k && typeof k.listPickers === "function" && typeof k.setPicker === "function" && typeof k.getPicker === "function");
    var title = t("settings.fm", "File manager");
    if (!can) return row(title, t("settings.fm_system", "System default"), t("settings.fm_nobridge", "Open this from the Modora app to change the file manager."));
    var apps = []; try { apps = JSON.parse(k.listPickers()) || []; } catch (e) {}
    var cur = ""; try { cur = k.getPicker() || ""; } catch (e) {}
    var r = el("div", "md-set-row md-feel md-feel-col"), top = el("div", "md-feel-top"), main = el("div", "md-set-main");
    main.appendChild(el("b", "", title)); main.appendChild(el("small", "", t("settings.fm_sub", "Choose which app opens when you tap Browse to pick a module zip.")));
    var val = el("span", "md-set-val"); top.appendChild(main); top.appendChild(val);
    var list = el("div", "md-fm-list"); list.setAttribute("role", "radiogroup"); list.setAttribute("aria-label", title); list.hidden = true;
    var btns = [];
    function label() { var l = t("settings.fm_system", "System default"); apps.forEach(function (a) { if (a.pkg === cur) l = a.label || a.pkg; }); return l; }
    function mark() { val.textContent = label(); btns.forEach(function (b) { b.setAttribute("aria-checked", b.dataset.pkg === cur ? "true" : "false"); }); }
    [{ pkg: "", label: t("settings.fm_system", "System default") }].concat(apps).forEach(function (a) {
      var b = el("button", "md-fm-opt", a.label || a.pkg); b.type = "button"; b.dataset.pkg = a.pkg; b.setAttribute("role", "radio");
      b.addEventListener("click", function () {
        var ok = false; try { ok = !!k.setPicker(a.pkg); } catch (e) {}
        if (!ok) { toast(t("settings.not_saved", "Applied, but it could not be saved for next time")); return; }
        cur = a.pkg; mark(); list.hidden = true; toggle.setAttribute("aria-expanded", "false"); toast(t("settings.fm_saved", "File manager saved"));
      });
      btns.push(b); list.appendChild(b);
    });
    if (!apps.length) list.appendChild(el("p", "md-fm-none", t("settings.fm_none", "No other file manager apps were found on this phone.")));
    var toggle = el("button", "md-btn md-btn-sm", t("settings.fm_change", "Change")); toggle.type = "button"; toggle.setAttribute("aria-expanded", "false");
    toggle.addEventListener("click", function () { list.hidden = !list.hidden; toggle.setAttribute("aria-expanded", list.hidden ? "false" : "true"); });
    top.appendChild(toggle);
    mark(); r.appendChild(top); r.appendChild(list);
    return r;
  }


  function savedCopySettingsGroup() {
    var api = window.MDSavedCopy, setting = api && api.setting;
    var g = group(t("settings.install_storage", "Install & saved copies"));
    if (!api || !setting) {
      g.appendChild(row(t("settings.savecopy", "Save a copy of installed ZIPs"), t("settings.unavailable", "Unavailable"), t("settings.savecopy_unavailable", "The saved-copy helper is not available in this build.")));
      return g;
    }
    var r = el("div", "md-set-row md-feel md-feel-col"), top = el("div", "md-feel-top"), main = el("div", "md-set-main");
    var title = t("settings.savecopy", "Save a copy of installed ZIPs");
    main.appendChild(el("b", "", title));
    main.appendChild(el("small", "", t("settings.savecopy_sub", "Keep a verified copy of each ZIP that installs successfully. Default: on.")));
    top.appendChild(main);
    var sw = el("button", "md-set-switch", ""); sw.type = "button"; sw.setAttribute("role", "switch"); sw.setAttribute("aria-label", title);
    function mark() {
      var on = setting.get() !== false;
      sw.setAttribute("aria-checked", on ? "true" : "false");
      sw.textContent = on ? t("settings.savecopy_on", "On") : t("settings.savecopy_off", "Off");
    }
    sw.addEventListener("click", function () {
      var next = !(setting.get() !== false), ok = false;
      try { ok = setting.set(next); } catch (e) {}
      mark();
      if (!ok) toast(t("settings.not_saved", "Applied, but it could not be saved for next time"));
      else if (setting.persistent && !setting.persistent()) toast(t("settings.savecopy_session", "Saved for this session only because storage is unavailable."));
    });
    r.appendChild(top); r.appendChild(sw); g.appendChild(r);

    var folder = row(t("settings.savecopy_folder", "Saved ZIP folder"), api.DIR, t("settings.savecopy_folder_sub", "Read-only location for saved copies. Files are not automatically deleted."));
    folder.classList.add("md-copy");
    var path = folder.querySelector(".md-set-val"); if (path) path.setAttribute("aria-label", t("settings.savecopy_folder", "Saved ZIP folder"));
    g.appendChild(folder);

    var stats = row(t("settings.savecopy_stats_title", "Saved copies"), "", t("settings.savecopy_stats_loading", "Checking saved ZIP count and total size…"));
    stats.id = "md-savecopy-stats-row";
    var sub = stats.querySelector("small"); if (sub) sub.id = "md-savecopy-stats";
    g.appendChild(stats);
    var showRow = row(t("settings.show_saved_zips", "Show saved zips"), "", t("settings.show_saved_zips_sub", "Open the install sheet with only this folder scanned."));
    var show = el("button", "md-btn md-btn-sm", t("settings.show_saved_zips", "Show saved zips")); show.type = "button";
    show.addEventListener("click", function () {
      if (!window.MDInstallUI || typeof window.MDInstallUI.showSavedZips !== "function") { toast(t("settings.unavailable", "Unavailable")); return; }
      window.MDInstallUI.showSavedZips();
    });
    showRow.appendChild(show); g.appendChild(showRow);

    function formatSize(bytes) {
      bytes = Math.max(0, Number(bytes) || 0);
      if (bytes < 1024) return bytes + " B";
      if (bytes < 1048576) return (bytes / 1024).toFixed(1) + " KB";
      if (bytes < 1073741824) return (bytes / 1048576).toFixed(1) + " MB";
      return (bytes / 1073741824).toFixed(2) + " GB";
    }
    function updateStats() {
      var label = document.getElementById("md-savecopy-stats");
      if (!label) return Promise.resolve(false);
      if (!window.MD || typeof window.MD.sh !== "function") { label.textContent = t("settings.savecopy_stats_unavailable", "Count is unavailable without the app's root bridge."); return Promise.resolve(false); }
      var cmd = "D='/sdcard/Modora/zips'; if [ -d \"$D\" ]; then N=$(find \"$D\" -maxdepth 1 -type f -name '*.zip' 2>/dev/null | wc -l | tr -d ' '); S=$(find \"$D\" -maxdepth 1 -type f -name '*.zip' -exec wc -c {} + 2>/dev/null | awk '$2!=\"total\" {s+=$1} END {printf \"%.0f\",s+0}'); echo \"MDSAVE1 $N ${S:-0}\"; else echo 'MDSAVE1 0 0'; fi";
      return window.MD.sh(cmd, { timeout: 7000 }).then(function (res) {
        var m = /MDSAVE1\s+(\d+)\s+(\d+)/.exec(res && res.out || "");
        if (!res || res.code !== 0 || !m) { label.textContent = t("settings.savecopy_stats_unavailable", "Count is unavailable without the app's root bridge."); return false; }
        label.textContent = t("settings.savecopy_stats", "{count} saved zips · {size}", { count: Number(m[1]), size: formatSize(Number(m[2])) });
        return true;
      }, function () { label.textContent = t("settings.savecopy_stats_unavailable", "Count is unavailable without the app's root bridge."); return false; });
    }
    mark(); updateStats();
    g._refreshSavedCopyStats = updateStats;
    return g;
  }

  function build() {
    var box = document.getElementById("set-body");
    if (!box) return;
    box.textContent = "";
    var g = group(t("settings.appearance", "Appearance"));
    g.appendChild(themeRow());
    var accRow = window.MDFeelView ? window.MDFeelView.accentRow() : null;   // MB6.3b: a real control when MDAccent exists
    g.appendChild(accRow || row(t("settings.accent", "Accent colour"), t("settings.accent_default", "Default blue"), t("settings.accent_why", "Custom accents are not available yet.")));
    g.appendChild(densityRow());
    box.appendChild(g);

    var hapRow = window.MDFeelView ? window.MDFeelView.hapticsRow() : null;   // MB6.3b: only when it can really work
    if (hapRow) { g = group(t("settings.feedback", "Feedback")); g.appendChild(hapRow); box.appendChild(g); }

    g = group(t("settings.fm", "File manager"));
    g.appendChild(fileManagerRow());
    box.appendChild(g);

    var saveCopyGroup = savedCopySettingsGroup();
    box.appendChild(saveCopyGroup);

    g = group(t("settings.language", "Language"));
    g.appendChild(languageRow());
    box.appendChild(g);

    if (window.MDOnboard) {                                   // MB8.1: replay the first-run intro (only when the script is present)
      g = group(t("settings.help", "Help"));
      var ir = row(t("settings.intro", "Intro tour"), "", t("settings.intro_sub", "A short tour of the Deck, Modules and Tools. It is shown once on first launch."));
      var ib = el("button", "md-btn md-btn-sm", t("settings.intro_btn", "Show intro")); ib.type = "button";
      ib.addEventListener("click", function () { window.MDOnboard.open(); });
      ir.appendChild(ib); g.appendChild(ir); box.appendChild(g);
    }

    g = group(t("settings.data", "Saved data"));
    var r = row(t("settings.cache", "Saved module list"), "", t("settings.cache_sub", "A copy of the last scan is shown instantly on start, labelled as saved. Clearing it only removes that copy; the next scan rebuilds it."));
    var b = el("button", "md-btn md-btn-sm", t("common.clear", "Clear")); b.type = "button";
    b.addEventListener("click", function () {
      if (!window.MDScan) { toast(t("settings.unavailable", "Unavailable")); return; }
      window.MDScan.clearCache(); toast(t("settings.cache_cleared", "Saved data cleared"));
    });
    r.appendChild(b); g.appendChild(r); box.appendChild(g);

    g = group(t("settings.about", "About"));
    var info = null; try { info = window.MD && window.MD.bridge && window.MD.bridge.appInfo ? window.MD.bridge.appInfo() : null; } catch (e) {}
    g.appendChild(row(t("settings.version", "Version"), info && info.versionName ? info.versionName + " (" + info.versionCode + ")" : t("settings.unknown", "Unknown"),
      info ? "" : t("settings.no_bridge", "Open this from the Modora app to see app details.")));
    if (info && info.package) { var pr = row(t("settings.package", "Package"), String(info.package)); pr.classList.add("md-copy"); g.appendChild(pr); }   // selectable: meant to be copied
    var dr = row(t("settings.deck_file", "Deck file"), "", "/data/adb/moddeck/favs"); dr.classList.add("md-copy"); g.appendChild(dr);
    box.appendChild(g);
  }
  window.MDSettings = { build: build, refreshSavedCopyStats: function () {
    var box = document.getElementById("set-body");
    if (!box) return Promise.resolve(false);
    var rows = box.querySelectorAll(".md-set-group"), i;
    for (i = 0; i < rows.length; i++) if (rows[i]._refreshSavedCopyStats) return rows[i]._refreshSavedCopyStats();
    return Promise.resolve(false);
  } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", build); else build();
})();
