/* Modora pull-to-refresh (MB8.3). Classic script (<script defer>), no modules, no dependencies (icons/i18n optional).
 * One finger pulling DOWN from the very top of the page on a view that can really refresh (Deck, Modules: both re-run the
 * module scan) shows a small status pill; releasing past the threshold calls opts.refresh() ONCE.
 * Never hijacks anything else: ignored when the page is scrolled, when a sheet/dialog is open (opts.blocked), on inputs and
 * drag handles ([data-mvh]) and when the gesture is mostly horizontal. The visible refresh button stays the non-gesture path.
 * State machine: idle -> pulling -> refreshing -> done -> idle. A new gesture is ignored unless idle, and refresh() is
 * only called from the single idle->refreshing transition, so overlapping requests are impossible from this module.
 * API: MDPtr.attach({views:[names], refresh:()=>Promise<"ok"|"fail">|any, blocked:()=>bool, maxWait:ms}) -> detach()
 *      MDPtr.state() -> "idle"|"pulling"|"refreshing"|"done"   MDPtr.dist(dy) -> displayed pull for a finger move of dy px (pure)
 *      MDPtr.TH (release threshold, px)
 * A refresh result other than "fail" counts as ok. A refresh that never settles is given up after maxWait (default 45 s) as "fail".
 */
(function () {
  "use strict";
  var TH = 64, MAXPULL = 110, HOLD = 60, SLOP = 8, RESIST = 0.6, SKIP = "input,textarea,select,[data-mvh],[data-ptr-skip]";
  var st = "idle", opts = null, root = null, ico = null, label = null, live = null, bound = false;
  var track = null, timers = [];

  function T(key, fb) {
    try { if (window.MDI18n) { var s = window.MDI18n.t(key); if (s && s !== key) return s; } } catch (e) {}
    return fb;
  }
  function dist(dy) { return dy <= SLOP ? 0 : Math.min(MAXPULL, (dy - SLOP) * RESIST); }
  function later(fn, ms) { var id = setTimeout(fn, ms); timers.push(id); return id; }
  function clearTimers() { while (timers.length) clearTimeout(timers.pop()); }

  function build() {
    if (root) return;
    root = document.createElement("div"); root.className = "md-ptr"; root.setAttribute("aria-hidden", "true"); root.hidden = true;
    ico = document.createElement("span"); ico.className = "md-ptr-ico";
    try { if (window.MDIcons) ico.innerHTML = window.MDIcons.svg("refresh"); } catch (e) {}
    label = document.createElement("span"); label.className = "md-ptr-label";
    root.appendChild(ico); root.appendChild(label);
    live = document.createElement("div"); live.className = "md-sr-only"; live.setAttribute("role", "status"); live.setAttribute("aria-live", "polite");
    document.body.appendChild(root); document.body.appendChild(live);
  }
  function place(pull, anim) {
    root.hidden = false;
    if (anim) root.setAttribute("data-anim", ""); else root.removeAttribute("data-anim");
    root.style.opacity = String(Math.max(0, Math.min(1, pull / 36)));
    root.style.transform = "translate(-50%," + Math.round(pull - 44) + "px)";
    ico.style.transform = st === "refreshing" ? "" : "rotate(" + Math.round(pull * 3) + "deg)";
  }
  function mark(state, text) { root.setAttribute("data-state", state); label.textContent = text; }
  function hide() {
    place(0, true);
    later(function () { if (st === "idle" && root) { root.hidden = true; root.removeAttribute("data-state"); } }, 260);
  }
  function setIdle() { st = "idle"; track = null; hide(); }

  function start() {
    st = "refreshing"; clearTimers();
    mark("refreshing", T("ptr.refreshing", "Refreshing…")); live.textContent = T("ptr.refreshing", "Refreshing…");
    place(HOLD, true);
    var settled = false, maxWait = opts && opts.maxWait > 0 ? opts.maxWait : 45000;
    function finish(res) {
      if (settled) return; settled = true; clearTimers();
      var ok = res !== "fail", msg = ok ? T("ptr.done", "Updated") : T("ptr.failed", "Couldn't refresh");
      st = "done"; mark(ok ? "done" : "failed", msg); live.textContent = msg; place(HOLD, true);
      later(setIdle, ok ? 900 : 1700);
    }
    later(function () { finish("fail"); }, maxWait);
    var p;
    try { p = opts.refresh(); } catch (e) { return finish("fail"); }
    Promise.resolve(p).then(finish, function () { finish("fail"); });
  }

  function onView() {
    if (!opts || !window.MDRouter) return false;
    var c = window.MDRouter.current();
    return !!c && opts.views.indexOf(c.name) > -1;
  }
  function scrolled() { return (window.pageYOffset || document.documentElement.scrollTop || 0) > 0; }

  function ts(e) {
    track = null;
    if (st !== "idle" || !opts || !e.touches || e.touches.length !== 1) return;
    if (!onView() || scrolled()) return;
    try { if (opts.blocked && opts.blocked()) return; } catch (x) { return; }
    var t = e.target;
    if (t && t.closest && t.closest(SKIP)) return;
    if (document.querySelector(".md-sorting")) return;
    var p = e.touches[0];
    track = { x: p.clientX, y: p.clientY, lock: null, pull: 0 };
  }
  function tm(e) {
    if (!track) return;
    if (!e.touches || e.touches.length !== 1) { cancel(); return; }
    var p = e.touches[0], dx = p.clientX - track.x, dy = p.clientY - track.y;
    if (track.lock === null) {
      if (Math.abs(dx) < SLOP && Math.abs(dy) < SLOP) return;
      if (dy > 0 && dy > Math.abs(dx) * 1.2) { track.lock = "pull"; build(); st = "pulling"; clearTimers(); }
      else { track = null; return; }                         // upward / sideways: native scroll or swipe, not ours
    }
    if (scrolled() || dy <= 0) { cancel(); return; }
    if (e.cancelable) e.preventDefault();
    track.pull = dist(dy);
    var armed = track.pull >= TH;
    mark(armed ? "release" : "pull", armed ? T("ptr.release", "Release to refresh") : T("ptr.pull", "Pull to refresh"));
    place(track.pull, false);
  }
  function te(e) {
    if (!track) return;
    var was = track; track = null;
    if (was.lock !== "pull") return;
    if (e && e.type === "touchcancel") { st = "idle"; hide(); return; }
    if (was.pull >= TH && st === "pulling") start(); else { st = "idle"; hide(); }
  }
  function cancel() { if (track && track.lock === "pull") { st = "idle"; hide(); } track = null; }

  function attach(o) {
    if (!o || typeof o.refresh !== "function" || !Array.isArray(o.views)) return function () {};
    opts = { views: o.views.slice(), refresh: o.refresh, blocked: o.blocked, maxWait: o.maxWait };
    if (!bound) {
      bound = true;
      document.addEventListener("touchstart", ts, { passive: true });
      document.addEventListener("touchmove", tm, { passive: false });
      document.addEventListener("touchend", te, { passive: true });
      document.addEventListener("touchcancel", te, { passive: true });
    }
    return function () { if (st === "pulling") { st = "idle"; hide(); } opts = null; track = null; };
  }

  window.MDPtr = { attach: attach, state: function () { return st; }, dist: dist, TH: TH };
})();
