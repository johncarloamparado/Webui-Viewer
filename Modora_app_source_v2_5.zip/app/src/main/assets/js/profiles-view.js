/* Modora Profiles selector view (MB5.1; MB5.2 mounts the review panel under the list). Builds the content of <section data-view="tools"> (#tools-body). Classic script, DOM + textContent only.
 * HONESTY RULE: choosing a profile ONLY remembers the choice (MDProfiles.select). Changing the device happens only through the review panel (MB5.2) after an explicit Apply tap.
 * Requires js/profiles.js (+ profiles.data.js). Without it the view shows an error state instead of fake data. Optional: MDI18n, MDIcons.
 */
(function () {
  "use strict";
  function t(k, fb, p) {
    try { if (window.MDI18n) { var s = window.MDI18n.t(k, p); if (s && s !== k) return s; } } catch (e) {}
    return fb.replace(/\{(\w+)\}/g, function (m, n) { return p && p[n] != null ? p[n] : m; });
  }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  var LBL = { REFRESH_HZ: ["prof.k_hz", "Refresh rate"], DISABLE_HWC: ["prof.k_hwc", "Disable HWC overlays"], GOVERNOR: ["prof.k_gov", "CPU governor"], PROP_SF_TIMERS: ["prof.k_sf", "Disable SF refresh timers"],
    PROP_GPU: ["prof.k_gpu", "GPU / composition props"], PROP_MEM: ["prof.k_mem", "Memory props"], MODE: ["prof.k_mode", "ANR popups"], LIMIT: ["prof.k_limit", "Show limit"], WINDOW_MIN: ["prof.k_window", "Window"], TIMEOUT_MULT: ["prof.k_timeout", "Timeout"] };
  function val(k, v) {
    if (k === "REFRESH_HZ") return v === "auto" ? t("prof.v_auto", "Auto") : t("prof.v_hz", "{n} Hz", { n: v });
    if (k === "GOVERNOR") return v === "default" ? t("prof.v_stock", "Stock") : v;
    if (k === "MODE") return v === "show" ? t("prof.v_stock", "Stock") : v === "limit" ? t("prof.v_limit", "Limit") : t("prof.v_hide", "Hide");
    if (k === "LIMIT" || k === "TIMEOUT_MULT") return v + "×";
    if (k === "WINDOW_MIN") return t("prof.v_min", "{n} min", { n: v });
    return v === "1" ? t("prof.v_on", "On") : t("prof.v_off", "Off");
  }
  function build() {
    var box = document.getElementById("tools-body"); if (!box) return;
    var P = window.MDProfiles;
    box.textContent = "";
    if (!P) { var e0 = el("div", "md-banner md-banner-danger", t("prof.err_scripts", "Profiles could not load (required scripts failed).")); e0.setAttribute("role", "alert"); box.appendChild(e0); return; }
    var st = P.status(), sel = P.selected(), list = P.list();
    var g = el("section", "md-set-group"); g.appendChild(el("h2", "", t("prof.title", "Profiles")));
    g.appendChild(el("p", "md-prof-note", t("prof.note", "Choosing a profile only remembers your choice for now. It does not change your device yet: applying a profile arrives in a later update.")));
    if (st.source === "fallback" || st.dropped || st.reasons.length) {
      var b = el("div", "md-banner md-banner-warn"); b.setAttribute("role", "status");
      var body = el("div", "md-banner-body");
      body.appendChild(el("p", "md-banner-title", st.source === "fallback" ? t("prof.fallback", "Profile data could not be read. Showing the built-in Stock profile only.") : t("prof.partial", "Some profile data was invalid and was skipped.")));
      b.appendChild(body); g.appendChild(b);
    }
    var grp = el("div", "md-prof-list"); grp.setAttribute("role", "radiogroup"); grp.setAttribute("aria-label", t("prof.title", "Profiles"));
    list.forEach(function (p) {
      var card = el("div", "md-prof" + (p.id === sel ? " is-selected" : ""));
      var r = el("button", "md-prof-pick"); r.type = "button"; r.setAttribute("role", "radio"); r.setAttribute("aria-checked", p.id === sel ? "true" : "false"); r.setAttribute("data-profile", p.id);
      var mark = el("span", "md-prof-mark"); mark.setAttribute("aria-hidden", "true");
      var tx = el("span", "md-prof-txt"); tx.appendChild(el("b", "", p.name)); if (p.desc) tx.appendChild(el("small", "", p.desc));
      r.appendChild(mark); r.appendChild(tx); card.appendChild(r);
      var d = el("details", "md-prof-det"); d.appendChild(el("summary", "", t("prof.contains", "Settings in this profile")));
      P.summary(p).forEach(function (s) {
        d.appendChild(el("h3", "", s.section === "rme50" ? t("prof.sec_rme50", "Display (60Hz & SF)") : t("prof.sec_anr", "ANR limiter")));
        var ul = el("ul", "md-prof-rows");
        s.rows.forEach(function (row) { var li = el("li"); li.appendChild(el("span", "", t(LBL[row[0]][0], LBL[row[0]][1]))); li.appendChild(el("b", "", val(row[0], row[1]))); ul.appendChild(li); });
        d.appendChild(ul);
      });
      card.appendChild(d); grp.appendChild(card);
    });
    g.appendChild(grp);
    var bar = el("div", "md-prof-bar");
    var cur = el("span", "md-prof-cur"); cur.setAttribute("role", "status"); cur.setAttribute("aria-live", "polite");
    var sp = sel ? P.get(sel) : null;
    cur.textContent = sp ? t("prof.selected", "Selected: {name}", { name: sp.name }) : t("prof.none", "No profile selected");
    var clr = el("button", "md-btn md-btn-sm", t("prof.clear", "Clear selection")); clr.type = "button"; clr.setAttribute("data-profile-clear", "1"); clr.disabled = !sel;
    bar.appendChild(cur); bar.appendChild(clr); g.appendChild(bar);
    if (window.MDProfilesReview) window.MDProfilesReview.mount(g);                 /* MB5.2: review + apply panel (js/profiles-review.js) */
    g.addEventListener("click", function (e) {
      var pick = e.target.closest ? e.target.closest("[data-profile]") : null;
      if (pick && g.contains(pick)) { P.select(pick.getAttribute("data-profile")); return; }
      var c = e.target.closest ? e.target.closest("[data-profile-clear]") : null;
      if (c && !c.disabled) P.clear();
    });
    box.appendChild(g);
    if (window.MDBackupView) window.MDBackupView.mount(box);                       /* MB5.3: backup + restore group (js/backup-view.js) */
    if (window.MDDiagView) window.MDDiagView.mount(box);                           /* MB5.4: diagnostics + logs groups (js/diag-view.js) */
    var focusId = build.focus; build.focus = null;
    if (focusId) { var f = box.querySelector('[data-profile="' + focusId + '"]'); if (f) f.focus(); }
  }
  function rebuild() { var a = document.activeElement; build.focus = a && a.getAttribute && a.getAttribute("data-profile"); build(); }
  window.MDProfilesView = { build: build };
  function init() { build(); if (window.MDProfiles) window.MDProfiles.onChange(rebuild); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
