/* Modora Profiles selector view (MB5.1; MB5.2 mounts the review panel under the list). Builds the content of <section data-view="tools"> (#tools-body). Classic script, DOM + textContent only.
 * HONESTY RULE: choosing a profile ONLY remembers the choice (MDProfiles.select). Changing the device happens only through the review panel (MB5.2) after an explicit Apply tap.
 * Requires js/profiles.js (+ profiles.data.js). Without it the view shows an error state instead of fake data. Optional: MDI18n, MDIcons.
 */
(function () {
  "use strict";
  function t(k, fb, p) {
    try { if (window.MDI18n) { var s = window.MDI18n.t(k, p); if (s && s !== k) return s; } } catch (e) {}
    return fb.replace(/\{(\w+)\}/g, function (m, n) { return p && p[n] != null ? p[n] : m; });
  }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  var LBL = { REFRESH_HZ: ["prof.k_hz", "Refresh rate"], DISABLE_HWC: ["prof.k_hwc", "Disable HWC overlays"], GOVERNOR: ["prof.k_gov", "CPU governor"], PROP_SF_TIMERS: ["prof.k_sf", "Disable SF refresh timers"],
    PROP_GPU: ["prof.k_gpu", "GPU / composition props"], PROP_MEM: ["prof.k_mem", "Memory props"], MODE: ["prof.k_mode", "ANR popups"], LIMIT: ["prof.k_limit", "Show limit"], WINDOW_MIN: ["prof.k_window", "Window"], TIMEOUT_MULT: ["prof.k_timeout", "Timeout"] };
  function val(k, v) {
    if (k === "REFRESH_HZ") return v === "auto" ? t("prof.v_auto", "Auto") : t("prof.v_hz", "{n} Hz", { n: v });
    if (k === "GOVERNOR") return v === "default" ? t("prof.v_stock", "Stock") : v;
    if (k === "MODE") return v === "show" ? t("prof.v_stock", "Stock") : v === "limit" ? t("prof.v_limit", "Limit") : t("prof.v_hide", "Hide");
    if (k === "LIMIT" || k === "TIMEOUT_MULT") return v + "×";
    if (k === "WINDOW_MIN") return t("prof.v_min", "{n} min", { n: v });
    return v === "1" ? t("prof.v_on", "On") : t("prof.v_off", "Off");
  }
  function build() {
    var box = document.getElementById("tools-body"); if (!box) return;
    box.textContent = "";
    if (window.MDDiagView) window.MDDiagView.mount(box);
  }
  function rebuild() { var a = document.activeElement; build.focus = a && a.getAttribute && a.getAttribute("data-profile"); build(); }
  window.MDProfilesView = { build: build };
  function init() { build(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
