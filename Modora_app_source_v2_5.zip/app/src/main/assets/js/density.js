/* Modora density (MBFIX.1). Classic script. Sets <html data-density="comfortable|compact">; css/tokens.css does the rest.
 * Stored in localStorage "md.density" (comfortable default; unreadable/invalid value -> comfortable).
 * API: MDDensity.get() -> pref, .set(pref) -> bool persisted, .PREFS */
(function () {
  "use strict";
  var KEY = "md.density", PREFS = ["comfortable", "compact"], root = document.documentElement, cur = "comfortable";
  function read() { try { var v = window.localStorage.getItem(KEY); return PREFS.indexOf(v) > -1 ? v : "comfortable"; } catch (e) { return "comfortable"; } }
  function apply() { root.setAttribute("data-density", cur); }
  window.MDDensity = {
    PREFS: PREFS.slice(),
    get: function () { return cur; },
    set: function (p) {
      if (PREFS.indexOf(p) < 0) return false;
      cur = p; apply();
      try { window.localStorage.setItem(KEY, p); return true; } catch (e) { return false; }
    }
  };
  cur = read(); apply();
})();
