/* Modora first-run onboarding (MB8.1). Classic script (<script defer>), no modules, no inline handlers.
 * A short 3-step intro shown ONCE on first launch. It never blocks: Skip is on every step except the last (which has "Get started"),
 * Back / Escape / outside tap / Android back all dismiss it as "skipped", and the app underneath stays fully usable.
 * Seen flag: localStorage "md.onboarded" = "1" (memory fallback if storage throws). It does not touch the device, root, the deck,
 * the scan cache, backups or any other preference. Nothing here runs a root command.
 * Returning users: if a saved scan copy ("md.scan.cache", written by js/scan.js) already exists the app was used before, so the intro is
 * NOT shown automatically (the flag is set quietly). It can always be replayed from Settings > Help > Show intro.
 * All text via i18n keys onb.* (fallback English literals below); everything is set with textContent.
 * API: MDOnboard.shouldShow() -> bool   .open(opts) -> bool   .close() -> bool   .isOpen()   .seen()   .reset()   .persistent()
 *      .step() -> 0-based index   .count()   .SLIDES (fixed registry)
 */
(function () {
  "use strict";
  var KEY = "md.onboarded", SCAN_KEY = "md.scan.cache";
  var SLIDES = [
    { icon: "home",     id: "welcome", k: "onb.s1", t: "Welcome to Modora",  b: "Modora is a control panel for your root modules. This 30-second tour covers the basics. You can skip it any time and replay it later from Settings." },
    { icon: "puzzle",   id: "modules", k: "onb.s2", t: "Deck and Modules",   b: "The Deck holds your favourite modules as tiles. The Modules tab lists every installed module so you can switch it on or off. Changes apply after the next reboot, and Modora tells you when one is waiting." },
    { icon: "shield",   id: "tools",   k: "onb.s3", t: "Tools and safety",   b: "Tools has tuner profiles, backup and restore, diagnostics and the power menu. A profile shows exactly what will change before anything is applied, and power actions always ask you to confirm first. Modora needs root access; Diagnostics can check whether it has it." }
  ];
  var root = null, idx = 0, removeOv = null, opener = null, mem = null, open = false;

  function T(k, fb) { try { if (window.MDI18n) { var s = window.MDI18n.t(k); if (s && s !== k) return s; } } catch (e) {} return fb; }
  function ls() { try { return window.localStorage || null; } catch (e) { return null; } }
  function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }
  function btn(cls, attr) { var b = el("button", "md-btn " + cls); b.type = "button"; b.setAttribute(attr, ""); return b; }

  /* ---------- seen flag ---------- */
  function seen() {
    if (mem === "1") return true;
    var s = ls(); if (!s) return false;
    try { return s.getItem(KEY) === "1"; } catch (e) { return false; }
  }
  function markSeen() {
    var s = ls();
    if (s) { try { s.setItem(KEY, "1"); mem = null; return true; } catch (e) {} }
    mem = "1"; return false;
  }
  function reset() { mem = null; var s = ls(); if (s) { try { s.removeItem(KEY); } catch (e) {} } }
  function usedBefore() { var s = ls(); if (!s) return false; try { return !!s.getItem(SCAN_KEY); } catch (e) { return false; } }
  function shouldShow() {
    if (seen()) return false;
    if (usedBefore()) { markSeen(); return false; }   // an existing user: never interrupt, just remember
    return true;
  }

  /* ---------- UI ---------- */
  function paint() {
    var s = SLIDES[idx], last = idx === SLIDES.length - 1;
    var ic = root.querySelector("[data-onb-ico]"); ic.textContent = "";
    if (window.MDIcons) ic.innerHTML = window.MDIcons.svg(s.icon);      // fixed registry name -> trusted markup
    root.querySelector("#onb-t").textContent = T(s.k + "_title", s.t);
    root.querySelector("#onb-d").textContent = T(s.k + "_body", s.b);
    root.querySelector("[data-onb-step]").textContent = T("onb.step", "Step {n} of {m}").replace("{n}", idx + 1).replace("{m}", SLIDES.length);
    var dots = root.querySelectorAll(".md-onb-dot");
    for (var i = 0; i < dots.length; i++) dots[i].classList.toggle("is-on", i === idx);
    root.querySelector("[data-onb-back]").hidden = idx === 0;
    root.querySelector("[data-onb-skip]").hidden = last;
    root.querySelector("[data-onb-next]").textContent = last ? T("onb.done", "Get started") : T("onb.next", "Next");
  }
  function go(n) { if (n < 0 || n >= SLIDES.length) return; idx = n; paint(); }

  function trap(e) {
    if (e.key === "Escape") { if (!removeOv) { e.preventDefault(); close(); } return; }  // with a router, its own Escape handler closes us
    if (e.key !== "Tab") return;
    var f = [].slice.call(root.querySelectorAll("button:not([disabled]):not([hidden])"));
    if (!f.length) return;
    var first = f[0], lastB = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); lastB.focus(); }
    else if (!e.shiftKey && document.activeElement === lastB) { e.preventDefault(); first.focus(); }
  }

  function build() {
    root = el("div", "md-onb"); root.hidden = true;
    root.setAttribute("role", "dialog"); root.setAttribute("aria-modal", "true");
    root.setAttribute("aria-labelledby", "onb-t"); root.setAttribute("aria-describedby", "onb-d");
    var card = el("div", "md-onb-card");
    var ico = el("span", "md-onb-ico"); ico.setAttribute("data-onb-ico", ""); ico.setAttribute("aria-hidden", "true");
    var step = el("p", "md-onb-step"); step.setAttribute("data-onb-step", ""); step.setAttribute("aria-live", "polite");
    var h = el("h2", "md-onb-title"); h.id = "onb-t"; h.tabIndex = -1;
    var p = el("p", "md-onb-body"); p.id = "onb-d";
    var dots = el("div", "md-onb-dots"); dots.setAttribute("aria-hidden", "true");
    SLIDES.forEach(function () { dots.appendChild(el("span", "md-onb-dot")); });
    var acts = el("div", "md-onb-actions");
    var skip = btn("md-btn-ghost", "data-onb-skip"), back = btn("", "data-onb-back"), next = btn("md-btn-primary", "data-onb-next");
    skip.textContent = T("onb.skip", "Skip"); back.textContent = T("common.back", "Back");
    acts.appendChild(skip); acts.appendChild(back); acts.appendChild(next);
    card.appendChild(ico); card.appendChild(step); card.appendChild(h); card.appendChild(p); card.appendChild(dots); card.appendChild(acts);
    root.appendChild(card);
    skip.addEventListener("click", function () { close(); });
    back.addEventListener("click", function () { go(idx - 1); });
    next.addEventListener("click", function () { if (idx >= SLIDES.length - 1) close(); else go(idx + 1); });
    root.addEventListener("click", function (e) { if (e.target === root) close(); });   // outside tap = skip
    root.addEventListener("keydown", trap);
    document.body.appendChild(root);
  }

  function openIntro() {
    if (open) return true;
    if (!document.body) return false;
    if (!root) build();
    opener = document.activeElement && document.activeElement !== document.body ? document.activeElement : null;
    idx = 0; paint(); root.hidden = false; open = true;
    document.body.classList.add("md-onb-open");
    removeOv = window.MDRouter && window.MDRouter.pushOverlay ? window.MDRouter.pushOverlay(function () { close(true); }) : null;
    try { root.querySelector("[data-onb-next]").focus(); } catch (e) {}
    return true;
  }
  function close(fromRouter) {
    if (!open) return false;
    open = false; root.hidden = true; document.body.classList.remove("md-onb-open");
    if (removeOv && !fromRouter) removeOv();             // the router already dropped it when it called us
    removeOv = null;
    markSeen();                                          // finished or skipped: either way do not show it again by itself
    if (opener && opener.focus && document.contains(opener)) { try { opener.focus(); } catch (e) {} }
    opener = null;
    return true;
  }

  window.MDOnboard = {
    SLIDES: SLIDES, shouldShow: shouldShow, open: openIntro, close: function () { return close(); },
    isOpen: function () { return open; }, seen: seen, reset: reset, step: function () { return idx; }, count: function () { return SLIDES.length; },
    persistent: function () { var s = ls(); if (!s) return false; try { return s.getItem(KEY) === "1"; } catch (e) { return false; } }
  };

  function auto() { try { if (window.MDOnboard.shouldShow()) setTimeout(openIntro, 0); } catch (e) {} }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", auto); else auto();
})();
