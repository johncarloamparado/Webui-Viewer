package com.custom.tweaks;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Bounded LRU cache for module webroot files (MB7.2). Every webroot request used to start its own `su -c cat`
 * (MainActivity.shouldInterceptRequest); this class lets repeated requests for the same static file be answered from memory.
 *
 * Pure java.util on purpose (no Android classes) so it can be compiled and tested on a desktop JVM.
 * (android.util.LruCache was not used: it is a stub-only class off-device and could not be tested for real here.)
 *
 * Rules (the reason this class has this shape):
 *  - BOUNDED: total bytes (maxBytes), bytes per entry (maxEntryBytes; a bigger file is served but never stored, so one
 *    big file cannot flush everything) and entry count (maxEntries). Least recently used entries go first.
 *  - Only successful reads are stored. A failed/missing/denied read (null) is NEVER cached, so a file that appears
 *    later, or a root prompt that is answered later, is picked up on the next request.
 *  - NO STALE DATA: entries expire after ttlMs; clear() drops everything AND invalidates loads that are still running
 *    (a load that started before clear() is returned to its caller but never stored). MainActivity calls clear() when a
 *    module is opened, when the app goes to the background, and before and after every ksu.exec (any command may write).
 *  - One load per key at a time: parallel requests for the same file wait for the first one (the WebView asks for
 *    resources in parallel) instead of starting one `su` each. If that load fails or takes longer than waitMs, a waiting
 *    request does its own load, exactly like before the cache existed.
 *  - The byte[] returned is shared with the cache: callers must not modify it.
 *  - info() reports counters only (no file names, no module ids, no content).
 */
final class WebrootCache {
  /** Reads the file. Returns the bytes, or null if it could not be read. May throw (treated as null). */
  interface Loader { byte[] load() throws Exception; }
  interface Clock { long nowMs(); }

  // ---- tunables (package-private so tests can shrink them) ----
  volatile int maxBytes = 8 << 20;        // total payload bytes
  volatile int maxEntryBytes = 1 << 20;   // a single file bigger than this is never stored
  volatile int maxEntries = 512;
  volatile long ttlMs = 5 * 60 * 1000L;   // protects against changes made by other programs
  volatile long waitMs = 20000;           // longest a request waits for another request's load of the same file
  volatile Clock clock = () -> System.nanoTime() / 1000000L;

  private static final class Entry {
    final byte[] data; final long at;
    Entry(byte[] d, long t) { data = d; at = t; }
  }
  private static final class Flight {
    final CountDownLatch done = new CountDownLatch(1);
    volatile byte[] result;
  }

  private final Object lock = new Object();
  private final LinkedHashMap<String, Entry> map = new LinkedHashMap<>(64, 0.75f, true); // access order = LRU
  private final HashMap<String, Flight> flights = new HashMap<>();
  private long bytes, gen;
  private long hits, misses, loads, coalesced, stores, evictions, expired, bypassed, discarded, clears;

  /**
   * Only static files are cached: html/js/css/images/fonts. Data files (json, txt, ...) are what scripts and daemons rewrite,
   * so they are always read fresh. `path` is the request path (already validated by the caller).
   */
  static boolean isStatic(String path) {
    if (path == null) return false;
    int slash = path.lastIndexOf('/'), dot = path.lastIndexOf('.');
    if (dot <= slash || dot == path.length() - 1) return false;
    switch (path.substring(dot + 1).toLowerCase(java.util.Locale.ROOT)) {
      case "html": case "htm": case "js": case "mjs": case "css": case "svg":
      case "png": case "jpg": case "jpeg": case "gif": case "webp": case "ico":
      case "woff": case "woff2": case "ttf": case "otf": case "wasm":
        return true;
      default:
        return false;
    }
  }

  /** Returns the cached bytes for key, or runs loader (once, even for parallel callers). null = could not be read. */
  byte[] get(String key, Loader loader) {
    Flight mine = null, other = null;
    long g;
    synchronized (lock) {
      Entry e = map.get(key); // also marks it as most recently used
      if (e != null) {
        if (clock.nowMs() - e.at <= ttlMs) { hits++; return e.data; }
        drop(key, e); expired++;
      }
      misses++;
      g = gen;
      other = flights.get(key);
      if (other == null) { mine = new Flight(); flights.put(key, mine); }
    }
    if (other != null) {
      boolean done = false;
      try { done = other.done.await(waitMs, TimeUnit.MILLISECONDS); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
      byte[] r = other.result;
      if (done && r != null) { synchronized (lock) { coalesced++; } return r; }
      return loadAndStore(key, loader, null, g); // that load failed / timed out: do our own (same as before the cache)
    }
    return loadAndStore(key, loader, mine, g);
  }

  private byte[] loadAndStore(String key, Loader loader, Flight f, long g) {
    byte[] d = null;
    try {
      d = loader.load();
    } catch (Exception e) {
      d = null;
    } finally {
      synchronized (lock) {
        loads++;
        if (f != null && flights.get(key) == f) flights.remove(key);
        if (d != null) {
          if (d.length > Math.min(maxEntryBytes, maxBytes)) bypassed++;
          else if (gen != g) discarded++; // cleared while loading: the data may predate a write
          else {
            Entry old = map.put(key, new Entry(d, clock.nowMs()));
            if (old != null) bytes -= old.data.length;
            bytes += d.length; stores++;
            evict();
          }
        }
      }
      if (f != null) { f.result = d; f.done.countDown(); }
    }
    return d;
  }

  /** Drops every entry and makes loads that are still running unable to store their result. Cheap; safe to call often. */
  void clear() {
    synchronized (lock) {
      gen++; clears++;
      map.clear(); bytes = 0;
      flights.clear(); // running loads finish for the callers that already wait for them, but new requests start fresh
    }
  }

  private void drop(String key, Entry e) { map.remove(key); bytes -= e.data.length; }

  private void evict() { // lock held
    Iterator<Map.Entry<String, Entry>> it = map.entrySet().iterator();
    while ((bytes > maxBytes || map.size() > maxEntries) && it.hasNext()) {
      Map.Entry<String, Entry> me = it.next(); // eldest = least recently used
      bytes -= me.getValue().data.length; it.remove(); evictions++;
    }
  }

  int entries() { synchronized (lock) { return map.size(); } }
  long bytes() { synchronized (lock) { return bytes; } }

  /** Counters only, as JSON: no file names, module ids or content. */
  String info() {
    synchronized (lock) {
      return "{\"entries\":" + map.size() + ",\"bytes\":" + bytes + ",\"maxBytes\":" + maxBytes + ",\"maxEntryBytes\":" + maxEntryBytes
        + ",\"maxEntries\":" + maxEntries + ",\"ttlMs\":" + ttlMs + ",\"hits\":" + hits + ",\"misses\":" + misses + ",\"loads\":" + loads
        + ",\"coalesced\":" + coalesced + ",\"stores\":" + stores + ",\"evictions\":" + evictions + ",\"expired\":" + expired
        + ",\"bypassed\":" + bypassed + ",\"discarded\":" + discarded + ",\"clears\":" + clears + "}";
    }
  }
}
