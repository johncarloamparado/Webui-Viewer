package com.custom.tweaks;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.*;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.webkit.*;
import android.view.View;
import android.widget.Toast;
import java.io.*;
import java.util.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
  static final String HOST = "mui.kernelsu.org", ASSET = "file:///android_asset/";
  WebView w;
  String cur = ""; // module whose webroot is currently being served

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    w = new WebView(this);
    w.setBackgroundColor(0xFF060A18);
    setContentView(w);
    WebSettings ws = w.getSettings();
    ws.setJavaScriptEnabled(true);
    ws.setDomStorageEnabled(true);
    ws.setAllowFileAccess(false); // file:///android_asset still loads
    ws.setAllowContentAccess(false);
    ws.setAllowFileAccessFromFileURLs(false);
    ws.setAllowUniversalAccessFromFileURLs(false);
    ws.setSafeBrowsingEnabled(true);
    WebView.setWebContentsDebuggingEnabled((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0);
    ws.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
    ws.setCacheMode(WebSettings.LOAD_DEFAULT);
    ws.setLoadWithOverviewMode(true);
    ws.setUseWideViewPort(true);
    w.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
        // Main frame (holds the root bridge): only our assets and the module host.
        String u = r.getUrl().toString();
        String scheme = r.getUrl().getScheme();
        if (u.startsWith(ASSET) || u.startsWith("https://" + HOST + "/")) return false;
        if ("https".equals(scheme) || "http".equals(scheme)) { openExternal(u); return true; }
        return true; // block intent:, javascript:, data:, file: outside assets
      }
      // Serve a module's webroot through root (same URL layout KernelSU uses)
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
        if (!HOST.equals(r.getUrl().getHost())) return null;
        String path = r.getUrl().getPath();
        if (path == null || path.equals("/")) path = "/index.html";
        if (!path.matches("[\\w./@~+ -]+") || path.contains("..")) return res(404, "text/plain", null);
        byte[] d = null;
        try {
          Process p = new ProcessBuilder("su", "-c", "cat '/data/adb/modules/" + cur + "/webroot" + path + "' 2>/dev/null").start();
          d = bytes(p.getInputStream());
          if (p.waitFor() != 0) d = null;
        } catch (Exception e) { d = null; }
        return d == null ? res(404, "text/plain", null) : res(200, mime(path), d);
      }
    });
    w.addJavascriptInterface(new Bridge(), "ksu");
    open(getIntent());
  }

  WebResourceResponse res(int code, String mime, byte[] d) {
    InputStream in = new ByteArrayInputStream(d == null ? new byte[0] : d);
    if (code == 200) return new WebResourceResponse(mime, "utf-8", in);
    return new WebResourceResponse(mime, "utf-8", code, "Not Found", new HashMap<String, String>(), in);
  }

  static String mime(String p) {
    String e = p.substring(p.lastIndexOf('.') + 1).toLowerCase();
    switch (e) {
      case "js": case "mjs": return "text/javascript";
      case "json": return "application/json";
      case "wasm": return "application/wasm";
      case "woff2": return "font/woff2";
      case "svg": return "image/svg+xml";
    }
    String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(e);
    return m == null ? "application/octet-stream" : m;
  }

  void open(Intent i) {
    String p = i.getStringExtra("page");
    if (p != null && p.startsWith("module:")) openMod(p.substring(7));
    else w.loadUrl(ASSET + (p == null ? "home.html" : p));
  }

  void openMod(String id) {
    if (!id.matches("[A-Za-z0-9._-]+")) return;
    cur = id; w.clearCache(true);
    w.loadUrl("https://" + HOST + "/index.html");
  }

  @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); open(i); }
  @SuppressWarnings("deprecation") @Override public void onBackPressed() {
    // Let the page close sheets/dialogs/routes first; it returns true when handled.
    w.evaluateJavascript("(window.MD&&MD.onBack&&MD.onBack())===true", v -> {
      if ("true".equals(v)) return;
      if (w.canGoBack()) w.goBack(); else finish();
    });
  }

  void openExternal(String u) {
    try {
      Uri uri = Uri.parse(u);
      String sc = uri.getScheme();
      if (!"http".equals(sc) && !"https".equals(sc)) return;
      startActivity(new Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    } catch (Exception e) {}
  }

  static byte[] bytes(InputStream in) throws IOException {
    ByteArrayOutputStream o = new ByteArrayOutputStream();
    byte[] b = new byte[8192]; int n;
    while ((n = in.read(b)) > 0) o.write(b, 0, n);
    return o.toByteArray();
  }

  Icon icon(String glyph, String id) {
    Bitmap b = Bitmap.createBitmap(216, 216, Bitmap.Config.ARGB_8888);
    Canvas c = new Canvas(b);
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    float h = Math.abs(id.hashCode()) % 360;
    p.setShader(new LinearGradient(0, 0, 216, 216, Color.HSVToColor(new float[]{h, .55f, 1f}), Color.HSVToColor(new float[]{(h + 30) % 360, .9f, .62f}), Shader.TileMode.CLAMP));
    c.drawRect(0, 0, 216, 216, p);
    p.setShader(null); p.setColor(0x26FFFFFF);
    c.drawCircle(60, 20, 120, p); // soft gloss
    p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(96); p.setShadowLayer(10, 0, 5, 0x66000000);
    c.drawText(glyph.isEmpty() ? "?" : glyph, 108, 108 - (p.ascent() + p.descent()) / 2, p);
    return Icon.createWithAdaptiveBitmap(b);
  }

  ShortcutInfo info(String id, String label, String page, String glyph) {
    Intent it = new Intent(this, MainActivity.class).setAction(Intent.ACTION_VIEW).putExtra("page", page);
    return new ShortcutInfo.Builder(this, "m:" + id + ":" + (page.startsWith("action") ? "a" : "u"))
      .setShortLabel(label).setLongLabel(label).setIcon(icon(glyph, id)).setIntent(it).build();
  }

  // Same JS API the KernelSU manager exposes, plus pin/sync for ModDeck itself
  class Bridge {
    @JavascriptInterface public void exec(String cmd, String opts, String cb) {
      if (cb == null || !cb.matches("[A-Za-z_$][A-Za-z0-9_$.]*") || cmd == null) return;
      new Thread(() -> {
        String out = "", err = ""; int code = -1;
        try {
          String line = cmd;
          JSONObject o = new JSONObject(opts == null || opts.isEmpty() ? "{}" : opts);
          String cwd = o.optString("cwd", "");
          final long tmo = o.optLong("timeout", 0);
          if (cwd.matches("[\\w./@~+-]+")) line = "cd '" + cwd + "' && " + line;
          final Process p = new ProcessBuilder("su", "-c", line).start();
          final boolean[] timedOut = {false};
          if (tmo > 0) new Thread(() -> {
            try { Thread.sleep(tmo); } catch (InterruptedException e) { return; }
            timedOut[0] = true; p.destroyForcibly();
          }).start();
          final StringBuilder eb = new StringBuilder();
          Thread t = new Thread(() -> { try { eb.append(new String(bytes(p.getErrorStream()), "UTF-8")); } catch (IOException e) {} });
          t.start();
          out = new String(bytes(p.getInputStream()), "UTF-8");
          code = p.waitFor(); t.join(); err = eb.toString();
          if (timedOut[0]) { code = -2; err = "timeout"; }
        } catch (Exception e) { err = String.valueOf(e); }
        final String js = cb + "(" + code + "," + JSONObject.quote(out) + "," + JSONObject.quote(err) + ")";
        w.post(() -> w.evaluateJavascript(js, null));
      }).start();
    }
    @JavascriptInterface public void toast(String m) { runOnUiThread(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_SHORT).show()); }
    @JavascriptInterface public void fullScreen(boolean f) {
      runOnUiThread(() -> {
        int fl = View.SYSTEM_UI_FLAG_VISIBLE;
        if (f) fl = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        getWindow().getDecorView().setSystemUiVisibility(fl);
      });
    }
    @JavascriptInterface public void copy(String t) {
      runOnUiThread(() -> {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) { cm.setPrimaryClip(ClipData.newPlainText("Modora", t)); Toast.makeText(MainActivity.this, "Copied", Toast.LENGTH_SHORT).show(); }
      });
    }
    @JavascriptInterface public void share(String t) {
      runOnUiThread(() -> startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), null)));
    }
    @JavascriptInterface public void vibrate(int ms) {
      Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
      if (v != null && ms > 0 && ms <= 200) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
    }
    @JavascriptInterface public String appInfo() {
      int m = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
      return "{\"versionName\":\"2.5\",\"versionCode\":10,\"sdk\":" + Build.VERSION.SDK_INT
        + ",\"locale\":" + JSONObject.quote(Locale.getDefault().toLanguageTag())
        + ",\"nightMode\":" + (m == android.content.res.Configuration.UI_MODE_NIGHT_YES)
        + ",\"package\":\"com.custom.tweaks\"}";
    }
    @JavascriptInterface public String sysAccent() {
      if (Build.VERSION.SDK_INT < 31) return "";
      try { return String.format("#%06X", getResources().getColor(android.R.color.system_accent1_500, getTheme()) & 0xFFFFFF); } catch (Exception e) { return ""; }
    }
    @JavascriptInterface public void openExternal(String u) { MainActivity.this.openExternal(u); }
    @JavascriptInterface public String moduleInfo() { return "{\"id\":\"" + cur + "\",\"moduleDir\":\"/data/adb/modules/" + cur + "\"}"; }
    @JavascriptInterface public void openModule(String id) { runOnUiThread(() -> openMod(id)); }

    @JavascriptInterface public void pin(String id, String label, String page, String glyph) {
      runOnUiThread(() -> {
        ShortcutManager sm = getSystemService(ShortcutManager.class);
        if (sm == null || !sm.isRequestPinShortcutSupported()) { Toast.makeText(MainActivity.this, "Launcher doesn't support pinning", Toast.LENGTH_LONG).show(); return; }
        sm.requestPinShortcut(info(id, label, page, glyph), null);
      });
    }

    // Long-press menu = your first modules; pinned icons of removed modules get disabled
    @JavascriptInterface public void sync(String installed, String json) {
      runOnUiThread(() -> {
        try {
          ShortcutManager sm = getSystemService(ShortcutManager.class);
          List<String> have = Arrays.asList(installed.split(","));
          List<ShortcutInfo> dyn = new ArrayList<>();
          JSONArray a = new JSONArray(json);
          for (int i = 0; i < a.length() && i < 4; i++) {
            JSONObject o = a.getJSONObject(i);
            dyn.add(info(o.getString("id"), o.getString("label"), o.getString("page"), o.optString("glyph", "?")));
          }
          sm.setDynamicShortcuts(dyn);
          List<String> on = new ArrayList<>(), off = new ArrayList<>();
          for (ShortcutInfo s : sm.getPinnedShortcuts()) {
            String[] t = s.getId().split(":");
            if (t.length == 3) { if (have.contains(t[1])) on.add(s.getId()); else off.add(s.getId()); }
          }
          if (!off.isEmpty()) sm.disableShortcuts(off, "Module is not installed");
          if (!on.isEmpty()) sm.enableShortcuts(on);
        } catch (Exception e) {}
      });
    }
  }
}
