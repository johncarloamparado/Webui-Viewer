package com.custom.tweaks;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.webkit.*;
import android.view.DisplayCutout;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.*;
import java.util.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
  static final String HOST = "mui.kernelsu.org", ASSET = "file:///android_asset/";
  WebView w;
  volatile String cur = ""; // module whose webroot is currently being served (volatile: written on the UI thread, read by WebView I/O threads)
  // MB7.2: bounded cache for static webroot files. Cleared by openMod(), onStop() and around every ksu.exec (see WebrootCache for the rules).
  WebrootCache webroot = new WebrootCache();
  // Module-zip picker (MB4.1): one pick at a time. The chosen zip is streamed through `su` into a fixed root-readable path.
  static final int REQ_PICK_ZIP = 4101;
  static final String PICK_DIR = "/data/local/tmp/modora_install", PICK_FILE = PICK_DIR + "/module.zip";
  static final long PICK_MAX = 256L * 1024 * 1024;
  String pickCb = null;
  // Preferred file manager for Browse (Settings > File manager). "" = system default picker. Stored as a package name in app-private prefs.
  static final String PREF = "modora", PREF_PICKER = "picker_pkg";
  Intent pickIntent(boolean custom) {
    Intent it = new Intent(custom ? Intent.ACTION_GET_CONTENT : Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
      .putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/x-zip-compressed", "application/octet-stream"});
    return it;
  }
  /** Apps that can answer a "pick a file" request (other than Modora itself), by package. */
  Map<String, String> pickerApps() {
    Map<String, String> out = new LinkedHashMap<>();
    PackageManager pm = getPackageManager();
    for (String act : new String[]{Intent.ACTION_GET_CONTENT, Intent.ACTION_OPEN_DOCUMENT}) {
      try {
        Intent q = new Intent(act).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
        for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
          if (ri.activityInfo == null || getPackageName().equals(ri.activityInfo.packageName)) continue;
          String label = String.valueOf(ri.loadLabel(pm));
          if (!out.containsKey(ri.activityInfo.packageName)) out.put(ri.activityInfo.packageName, label.replaceAll("[\\p{Cntrl}]", ""));
        }
      } catch (Exception e) {}
    }
    return out;
  }
  String savedPicker() { try { return getSharedPreferences(PREF, MODE_PRIVATE).getString(PREF_PICKER, ""); } catch (Exception e) { return ""; } }
  // MB7.1: optional persistent root shell. Used ONLY when a page passes {"persist":true} to exec; any failure falls back to the per-call `su -c` below.
  RootShell rootShell = new RootShell(RootShell.suSpawner());
  // MB7.3: edge-to-edge window. `root` holds the WebView and is padded by the system bars / cutout / keyboard (see onInsets), so web content is never clipped.
  FrameLayout root;
  int barBg = BarsPolicy.DEFAULT_BG;   // colour behind the system bars (set by ksu.setBars; default = the app's dark background)
  boolean barLightIcons = true;        // true = white icons (dark bars)
  boolean barsHidden = false;          // fullScreen(true)

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    w = new WebView(this);
    w.setBackgroundColor(BarsPolicy.DEFAULT_BG);
    root = new FrameLayout(this);
    root.addView(w, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
    setContentView(root);
    setupEdgeToEdge();
    applyBars(BarsPolicy.DEFAULT_BG);
    WebSettings ws = w.getSettings();
    ws.setJavaScriptEnabled(true);
    ws.setDomStorageEnabled(true);
    ws.setAllowFileAccess(false); // file:///android_asset still loads
    ws.setAllowContentAccess(false);
    ws.setAllowFileAccessFromFileURLs(false);
    ws.setAllowUniversalAccessFromFileURLs(false);
    ws.setSafeBrowsingEnabled(true);
    WebView.setWebContentsDebuggingEnabled((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0);
    ws.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
    ws.setCacheMode(WebSettings.LOAD_DEFAULT);
    ws.setLoadWithOverviewMode(true);
    ws.setUseWideViewPort(true);
    w.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
        // Main frame (holds the root bridge): only our assets and the module host.
        String u = r.getUrl().toString();
        String scheme = r.getUrl().getScheme();
        if (u.startsWith(ASSET) || u.startsWith("https://" + HOST + "/")) return false;
        if ("https".equals(scheme) || "http".equals(scheme)) { openExternal(u); return true; }
        return true; // block intent:, javascript:, data:, file: outside assets
      }
      // Serve a module's webroot through root (same URL layout KernelSU uses)
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
        if (!HOST.equals(r.getUrl().getHost())) return null;
        String path = r.getUrl().getPath();
        if (path == null || path.equals("/")) path = "/index.html";
        if (!path.matches("[\\w./@~+ -]+") || path.contains("..")) return res(404, "text/plain", null);
        byte[] d = null;
        final String mod = cur, pth = path; // read once: the cache key and the command must use the same module
        try {
          // MB7.2: static files (html/js/css/images/fonts) are cached; data files are always read fresh. Failed reads are never cached.
          d = WebrootCache.isStatic(pth) ? webroot.get(mod + ":" + pth, () -> readWebroot(mod, pth)) : readWebroot(mod, pth);
        } catch (Exception e) { d = null; }
        return d == null ? res(404, "text/plain", null) : res(200, mime(path), d);
      }
    });
    w.addJavascriptInterface(new Bridge(), "ksu");
    open(getIntent());
  }

  // ---- MB7.3: system bars + insets -------------------------------------------------------------------------------
  // The window is laid out behind the system bars; `root` is then padded by exactly the space they (or a display cutout, or the
  // keyboard) take, and the insets are CONSUMED so the WebView does not add its own safe-area insets on top (no double padding;
  // CSS env(safe-area-inset-*) is therefore 0 and harmless). The bars are painted with the page's background colour (ksu.setBars).
  void setupEdgeToEdge() {
    Window win = getWindow();
    win.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
    win.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
    if (Build.VERSION.SDK_INT >= 28) { // draw into the cutout area on the short edges (it is padded away below)
      WindowManager.LayoutParams lp = win.getAttributes();
      lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
      win.setAttributes(lp);
    }
    if (Build.VERSION.SDK_INT >= 30) win.setDecorFitsSystemWindows(false);
    else win.getDecorView().setSystemUiVisibility(legacyUiFlags());
    root.setOnApplyWindowInsetsListener((v, ins) -> onInsets(v, ins));
    root.requestApplyInsets();
  }

  WindowInsets onInsets(View v, WindowInsets ins) {
    int[] p;
    if (Build.VERSION.SDK_INT >= 30) {
      android.graphics.Insets b = ins.getInsets(WindowInsets.Type.systemBars());
      android.graphics.Insets c = ins.getInsets(WindowInsets.Type.displayCutout());
      android.graphics.Insets k = ins.getInsets(WindowInsets.Type.ime());
      p = BarsPolicy.pad(b.left, b.top, b.right, b.bottom, c.left, c.top, c.right, c.bottom, k.bottom);
    } else {
      int cl = 0, ct = 0, cr = 0, cb = 0;
      if (Build.VERSION.SDK_INT >= 28) {
        DisplayCutout dc = ins.getDisplayCutout();
        if (dc != null) { cl = dc.getSafeInsetLeft(); ct = dc.getSafeInsetTop(); cr = dc.getSafeInsetRight(); cb = dc.getSafeInsetBottom(); }
      }
      // below API 30 the system window inset at the bottom already includes the keyboard (adjustResize), so imeB = 0
      p = BarsPolicy.pad(ins.getSystemWindowInsetLeft(), ins.getSystemWindowInsetTop(), ins.getSystemWindowInsetRight(), ins.getSystemWindowInsetBottom(), cl, ct, cr, cb, 0);
    }
    v.setPadding(p[0], p[1], p[2], p[3]);
    return Build.VERSION.SDK_INT >= 30 ? WindowInsets.CONSUMED : ins.consumeSystemWindowInsets();
  }

  // Legacy (< API 30) system UI flags: stable edge-to-edge layout + icon colour + optional immersive mode, always set together.
  @SuppressWarnings("deprecation") int legacyUiFlags() {
    int f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
    if (!barLightIcons) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR; // dark icons on a light bar
    if (barsHidden) f |= View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
    return f;
  }

  @SuppressWarnings("deprecation") void applyUiState() {
    Window win = getWindow();
    if (Build.VERSION.SDK_INT >= 30) {
      WindowInsetsController c = win.getInsetsController();
      if (c == null) return;
      int m = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
      c.setSystemBarsAppearance(barLightIcons ? 0 : m, m);
      if (barsHidden) {
        c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        c.hide(WindowInsets.Type.systemBars());
      } else c.show(WindowInsets.Type.systemBars());
    } else {
      win.getDecorView().setSystemUiVisibility(legacyUiFlags());
    }
  }

  // Paints the bars (and the window/root/WebView background) with `bg` and picks light or dark icons for contrast. UI thread only.
  void applyBars(int bg) {
    barBg = bg;
    barLightIcons = BarsPolicy.lightIcons(bg);
    Window win = getWindow();
    win.setBackgroundDrawable(new ColorDrawable(bg)); // also replaces the splash drawable (windowBackground) once the app is up
    root.setBackgroundColor(bg);
    w.setBackgroundColor(bg);
    win.setStatusBarColor(bg);
    win.setNavigationBarColor(bg);
    if (Build.VERSION.SDK_INT >= 29) { win.setStatusBarContrastEnforced(false); win.setNavigationBarContrastEnforced(false); }
    applyUiState();
  }

  // One webroot file through root: same command as before MB7.2. null = could not be read (missing, denied, su failed).
  byte[] readWebroot(String mod, String path) throws Exception {
    Process p = new ProcessBuilder("su", "-c", "cat '/data/adb/modules/" + mod + "/webroot" + path + "' 2>/dev/null").start();
    byte[] d = bytes(p.getInputStream());
    return p.waitFor() == 0 ? d : null;
  }

  WebResourceResponse res(int code, String mime, byte[] d) {
    InputStream in = new ByteArrayInputStream(d == null ? new byte[0] : d);
    if (code == 200) return new WebResourceResponse(mime, "utf-8", in);
    return new WebResourceResponse(mime, "utf-8", code, "Not Found", new HashMap<String, String>(), in);
  }

  static String mime(String p) {
    String e = p.substring(p.lastIndexOf('.') + 1).toLowerCase();
    switch (e) {
      case "js": case "mjs": return "text/javascript";
      case "json": return "application/json";
      case "wasm": return "application/wasm";
      case "woff2": return "font/woff2";
      case "svg": return "image/svg+xml";
    }
    String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(e);
    return m == null ? "application/octet-stream" : m;
  }

  void open(Intent i) {
    String p = i.getStringExtra("page");
    if (p != null && p.startsWith("module:")) openMod(p.substring(7));
    else w.loadUrl(ASSET + (p == null ? "home.html" : p));
  }

  void openMod(String id) {
    if (!id.matches("[A-Za-z0-9._-]+")) return;
    cur = id; webroot.clear(); w.clearCache(true);
    w.loadUrl("https://" + HOST + "/index.html");
  }

  @Override protected void onDestroy() { rootShell.close(); webroot.clear(); super.onDestroy(); }
  // MB7.2: coming back to the app always re-reads module files (another program may have changed them while we were away).
  @Override protected void onStop() { webroot.clear(); super.onStop(); }
  // MB7.3: re-assert icon colour / immersive state when the window regains focus (the system can reset it, and getInsetsController() may have been null in onCreate).
  @Override public void onWindowFocusChanged(boolean hasFocus) { super.onWindowFocusChanged(hasFocus); if (hasFocus && root != null) applyUiState(); }

  @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); open(i); }
  @SuppressWarnings("deprecation") @Override public void onBackPressed() {
    // Let the page close sheets/dialogs/routes first; it returns true when handled.
    w.evaluateJavascript("(window.MD&&MD.onBack&&MD.onBack())===true", v -> {
      if ("true".equals(v)) return;
      if (w.canGoBack()) w.goBack(); else finish();
    });
  }

  // Reports to the page: window[cb](ok, path, name, size, err). name is for display only (never used in a path).
  void pickDone(boolean ok, String name, long size, String err) {
    final String cb = pickCb; pickCb = null;
    if (cb == null) return;
    final String js = cb + "(" + ok + "," + JSONObject.quote(ok ? PICK_FILE : "") + "," + JSONObject.quote(name == null ? "" : name) + "," + size + "," + JSONObject.quote(err == null ? "" : err) + ")";
    w.post(() -> w.evaluateJavascript(js, null));
  }

  @SuppressWarnings("deprecation") @Override protected void onActivityResult(int req, int res, Intent data) {
    super.onActivityResult(req, res, data);
    if (req != REQ_PICK_ZIP) return;
    if (res != RESULT_OK || data == null || data.getData() == null) { pickDone(false, "", 0, "cancelled"); return; }
    final Uri uri = data.getData();
    new Thread(() -> {
      String name = "";
      try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
        if (c != null && c.moveToFirst()) name = c.getString(0) == null ? "" : c.getString(0);
      } catch (Exception e) {}
      name = name.replaceAll("[\\p{Cntrl}]", "");
      if (name.length() > 120) name = name.substring(name.length() - 120);
      Process p = null;
      try (InputStream in = getContentResolver().openInputStream(uri)) {
        if (in == null) { pickDone(false, name, 0, "open"); return; }
        byte[] head = new byte[4]; int hn = 0, r;
        while (hn < 4 && (r = in.read(head, hn, 4 - hn)) > 0) hn += r;
        if (hn < 4 || head[0] != 'P' || head[1] != 'K' || head[2] != 3 || head[3] != 4) { pickDone(false, name, 0, "notzip"); return; }
        // Fixed path, fixed command: nothing from the picked file's name or URI reaches the shell.
        p = new ProcessBuilder("su", "-c", "rm -rf " + PICK_DIR + " && mkdir -p " + PICK_DIR + " && cat > " + PICK_FILE + " && chmod 644 " + PICK_FILE).start();
        OutputStream os = p.getOutputStream();
        os.write(head, 0, 4);
        long total = 4; byte[] buf = new byte[65536]; int n;
        while ((n = in.read(buf)) > 0) {
          total += n;
          if (total > PICK_MAX) { os.close(); p.destroyForcibly(); cleanPick(); pickDone(false, name, total, "toolarge"); return; }
          os.write(buf, 0, n);
        }
        os.close();
        int code = p.waitFor();
        if (code != 0) { cleanPick(); pickDone(false, name, total, "copy"); return; }
        pickDone(true, name, total, "");
      } catch (Exception e) {
        if (p != null) p.destroyForcibly();
        cleanPick(); pickDone(false, name, 0, "copy");
      }
    }).start();
  }

  void cleanPick() {
    try { new ProcessBuilder("su", "-c", "rm -rf " + PICK_DIR).start().waitFor(); } catch (Exception e) {}
  }

  void openExternal(String u) {
    try {
      Uri uri = Uri.parse(u);
      String sc = uri.getScheme();
      if (!"http".equals(sc) && !"https".equals(sc)) return;
      startActivity(new Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    } catch (Exception e) {}
  }

  static byte[] bytes(InputStream in) throws IOException {
    ByteArrayOutputStream o = new ByteArrayOutputStream();
    byte[] b = new byte[8192]; int n;
    while ((n = in.read(b)) > 0) o.write(b, 0, n);
    return o.toByteArray();
  }

  Icon icon(String glyph, String id) {
    Bitmap b = Bitmap.createBitmap(216, 216, Bitmap.Config.ARGB_8888);
    Canvas c = new Canvas(b);
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    float h = Math.abs(id.hashCode()) % 360;
    p.setShader(new LinearGradient(0, 0, 216, 216, Color.HSVToColor(new float[]{h, .55f, 1f}), Color.HSVToColor(new float[]{(h + 30) % 360, .9f, .62f}), Shader.TileMode.CLAMP));
    c.drawRect(0, 0, 216, 216, p);
    p.setShader(null); p.setColor(0x26FFFFFF);
    c.drawCircle(60, 20, 120, p); // soft gloss
    p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(96); p.setShadowLayer(10, 0, 5, 0x66000000);
    c.drawText(glyph.isEmpty() ? "?" : glyph, 108, 108 - (p.ascent() + p.descent()) / 2, p);
    return Icon.createWithAdaptiveBitmap(b);
  }

  ShortcutInfo info(String id, String label, String page, String glyph) {
    Intent it = new Intent(this, MainActivity.class).setAction(Intent.ACTION_VIEW).putExtra("page", page);
    return new ShortcutInfo.Builder(this, "m:" + id + ":" + (page.startsWith("action") ? "a" : "u"))
      .setShortLabel(label).setLongLabel(label).setIcon(icon(glyph, id)).setIntent(it).build();
  }

  // Same JS API the KernelSU manager exposes, plus pin/sync for ModDeck itself
  class Bridge {
    @JavascriptInterface public void exec(String cmd, String opts, String cb) {
      if (cb == null || !cb.matches("[A-Za-z_$][A-Za-z0-9_$.]*") || cmd == null) return;
      new Thread(() -> {
        String out = "", err = ""; int code = -1;
        webroot.clear(); // MB7.2: any command may write module files; drop cached ones before it runs ...
        try {
          String line = cmd;
          JSONObject o = new JSONObject(opts == null || opts.isEmpty() ? "{}" : opts);
          String cwd = o.optString("cwd", "");
          final long tmo = o.optLong("timeout", 0);
          if (cwd.matches("[\\w./@~+-]+")) line = "cd '" + cwd + "' && " + line;
          // MB7.1: opt-in persistent root shell. rs.ran == false means nothing was sent, so the normal per-call su below runs it.
          // rs.ran == true is final (the command may have had effects), it is never run a second time.
          RootShell.Result rs = o.optBoolean("persist", false) ? rootShell.run(line, tmo) : null;
          if (rs != null && rs.ran) {
            out = new String(rs.out, "UTF-8"); err = new String(rs.err, "UTF-8"); code = rs.code;
            if (code == -2) err = "timeout";
          } else {
          final Process p = new ProcessBuilder("su", "-c", line).start();
          final boolean[] timedOut = {false};
          if (tmo > 0) new Thread(() -> {
            try { Thread.sleep(tmo); } catch (InterruptedException e) { return; }
            timedOut[0] = true; p.destroyForcibly();
          }).start();
          final StringBuilder eb = new StringBuilder();
          Thread t = new Thread(() -> { try { eb.append(new String(bytes(p.getErrorStream()), "UTF-8")); } catch (IOException e) {} });
          t.start();
          out = new String(bytes(p.getInputStream()), "UTF-8");
          code = p.waitFor(); t.join(); err = eb.toString();
          if (timedOut[0]) { code = -2; err = "timeout"; }
          }
        } catch (Exception e) { err = String.valueOf(e); }
        webroot.clear(); // ... and again when it ended: a file read WHILE the command ran may predate its write
        final String js = cb + "(" + code + "," + JSONObject.quote(out) + "," + JSONObject.quote(err) + ")";
        w.post(() -> w.evaluateJavascript(js, null));
      }).start();
    }
    // MB7.1: status of the optional persistent root shell as JSON (no command text, no output): {alive,spawns,runs,fallbacks,idleStops,lastError}.
    @JavascriptInterface public String rootShellInfo() { return rootShell.info(); }
    // MB7.2: counters of the webroot cache as JSON ({entries,bytes,maxBytes,hits,misses,loads,coalesced,stores,evictions,expired,bypassed,discarded,clears,...}); no file names or content.
    @JavascriptInterface public String webrootCacheInfo() { return webroot.info(); }
    @JavascriptInterface public void toast(String m) { runOnUiThread(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_SHORT).show()); }
    @JavascriptInterface public void fullScreen(boolean f) {
      // MB7.3: same effect as before (hide/show the bars, immersive sticky) but through applyUiState(), which keeps the edge-to-edge layout and icon-colour flags.
      runOnUiThread(() -> { barsHidden = f; applyUiState(); });
    }
    // MB7.3: colours the status/navigation bars (and the window behind them) with "#RRGGBB" / "#RGB"; "" restores the app default. Icons turn light/dark by contrast.
    // Returns false (and changes nothing) for an invalid colour.
    @JavascriptInterface public boolean setBars(String color) {
      final int c = (color == null || color.trim().isEmpty()) ? BarsPolicy.DEFAULT_BG : BarsPolicy.parseColor(color);
      if (c == BarsPolicy.NO_COLOR) return false;
      runOnUiThread(() -> { try { applyBars(c); } catch (Exception e) { /* keep the previous look */ } });
      return true;
    }
    @JavascriptInterface public void copy(String t) {
      runOnUiThread(() -> {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) { cm.setPrimaryClip(ClipData.newPlainText("Modora", t)); Toast.makeText(MainActivity.this, "Copied", Toast.LENGTH_SHORT).show(); }
      });
    }
    @JavascriptInterface public void share(String t) {
      runOnUiThread(() -> startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), null)));
    }
    @JavascriptInterface public void vibrate(int ms) {
      Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
      if (v != null && ms > 0 && ms <= 200) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
    }
    @JavascriptInterface public String appInfo() {
      int m = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
      return "{\"versionName\":\"2.5\",\"versionCode\":10,\"sdk\":" + Build.VERSION.SDK_INT
        + ",\"locale\":" + JSONObject.quote(Locale.getDefault().toLanguageTag())
        + ",\"nightMode\":" + (m == android.content.res.Configuration.UI_MODE_NIGHT_YES)
        + ",\"package\":\"com.custom.tweaks\"}";
    }
    @JavascriptInterface public String sysAccent() {
      if (Build.VERSION.SDK_INT < 31) return "";
      try { return String.format("#%06X", getResources().getColor(android.R.color.system_accent1_500, getTheme()) & 0xFFFFFF); } catch (Exception e) { return ""; }
    }
    @JavascriptInterface public void openExternal(String u) { MainActivity.this.openExternal(u); }
    @JavascriptInterface public String moduleInfo() { return "{\"id\":\"" + cur + "\",\"moduleDir\":\"/data/adb/modules/" + cur + "\"}"; }
    // Opens the system file picker for a module zip (MB4.1). cb gets (ok, path, name, size, err); err: cancelled|open|notzip|toolarge|copy|busy|nopicker.
    @JavascriptInterface public void pickZip(String cb) {
      if (cb == null || !cb.matches("[A-Za-z_$][A-Za-z0-9_$.]*")) return;
      runOnUiThread(() -> {
        if (pickCb != null) { String old = pickCb; pickCb = cb; pickDone(false, "", 0, "busy"); pickCb = old; return; }
        pickCb = cb;
        try {
          String pkg = savedPicker();
          boolean started = false;
          if (!pkg.isEmpty() && pickerApps().containsKey(pkg)) {          // the owner's chosen file manager; falls back to the system picker if it cannot start
            try { startActivityForResult(pickIntent(true).setPackage(pkg), REQ_PICK_ZIP); started = true; } catch (Exception e) {}
          }
          if (!started) startActivityForResult(pickIntent(false), REQ_PICK_ZIP);
        } catch (Exception e) { pickDone(false, "", 0, "nopicker"); }
      });
    }
    // File manager choice (Settings): listPickers() -> [{"pkg","label"}], getPicker() -> package or "", setPicker(pkg) -> bool ("" = system default; only an app from the list is accepted).
    @JavascriptInterface public String listPickers() {
      try {
        JSONArray a = new JSONArray();
        for (Map.Entry<String, String> e : pickerApps().entrySet()) a.put(new JSONObject().put("pkg", e.getKey()).put("label", e.getValue()));
        return a.toString();
      } catch (Exception e) { return "[]"; }
    }
    @JavascriptInterface public String getPicker() { return savedPicker(); }
    @JavascriptInterface public boolean setPicker(String pkg) {
      try {
        if (pkg == null) pkg = "";
        if (!pkg.isEmpty() && !pickerApps().containsKey(pkg)) return false;
        return getSharedPreferences(PREF, MODE_PRIVATE).edit().putString(PREF_PICKER, pkg).commit();
      } catch (Exception e) { return false; }
    }
    @JavascriptInterface public void openModule(String id) { runOnUiThread(() -> openMod(id)); }

    @JavascriptInterface public void pin(String id, String label, String page, String glyph) {
      runOnUiThread(() -> {
        ShortcutManager sm = getSystemService(ShortcutManager.class);
        if (sm == null || !sm.isRequestPinShortcutSupported()) { Toast.makeText(MainActivity.this, "Launcher doesn't support pinning", Toast.LENGTH_LONG).show(); return; }
        sm.requestPinShortcut(info(id, label, page, glyph), null);
      });
    }

    // Long-press menu = your first modules; pinned icons of removed modules get disabled
    @JavascriptInterface public void sync(String installed, String json) {
      runOnUiThread(() -> {
        try {
          ShortcutManager sm = getSystemService(ShortcutManager.class);
          List<String> have = Arrays.asList(installed.split(","));
          List<ShortcutInfo> dyn = new ArrayList<>();
          JSONArray a = new JSONArray(json);
          for (int i = 0; i < a.length() && i < 4; i++) {
            JSONObject o = a.getJSONObject(i);
            dyn.add(info(o.getString("id"), o.getString("label"), o.getString("page"), o.optString("glyph", "?")));
          }
          sm.setDynamicShortcuts(dyn);
          List<String> on = new ArrayList<>(), off = new ArrayList<>();
          for (ShortcutInfo s : sm.getPinnedShortcuts()) {
            String[] t = s.getId().split(":");
            if (t.length == 3) { if (have.contains(t[1])) on.add(s.getId()); else off.add(s.getId()); }
          }
          if (!off.isEmpty()) sm.disableShortcuts(off, "Module is not installed");
          if (!on.isEmpty()) sm.enableShortcuts(on);
        } catch (Exception e) {}
      });
    }
  }
}
