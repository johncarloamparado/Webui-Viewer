package com.custom.tweaks;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Persistent root shell (MB7.1). Keeps ONE long-lived `su` shell and runs commands through it one at a time, so callers
 * that poll often (live stats, job polling) do not pay a `su` process start per call.
 *
 * Pure java.io on purpose: no Android classes, so it can be compiled and tested on a desktop JVM with any program standing in for `su`.
 *
 * Safety rules (the reason this class exists in this shape):
 *  - Opt-in only. MainActivity.Bridge.exec uses it only when the page passes {"persist":true}. Everything else keeps the old
 *    one-shot `su -c` flow byte for byte.
 *  - Every command runs in its OWN `sh -c '<cmd>' </dev/null`, so `exit`, `cd`, variables and commands that read stdin cannot
 *    change or hang the shared shell. Exit code, stdout and stderr stay separate (one random end marker per command and stream).
 *  - run() NEVER re-runs a command. If nothing was sent (shell unavailable, root denied, backoff, shell busy, bad input) the
 *    Result has ran == false and the caller falls back to its normal per-call `su`. Once bytes were sent, the outcome is final
 *    (exit code, -1 error, or -2 timeout) even if the shell died, because the command may already have had effects.
 *  - Start-up is verified with `id -u` == 0 (same idea as the scan/diagnostics proof). A failed start is remembered and not retried
 *    for backoffMs, so a denied root prompt is not hammered.
 *  - Timeout kills the shared shell (the running command may continue as an orphan, exactly like the one-shot flow). The next call starts a new shell.
 *  - The shell is closed after idleMs without use and on close().
 *
 * Verified only against stand-in shells on a desktop JVM. Real su/KernelSU behaviour is NOT verified.
 */
final class RootShell {
  /** Starts the shell process. Default: plain `su` (interactive root shell reading commands from stdin). */
  interface Spawner { Process spawn() throws IOException; }

  /** ran == false: nothing was sent, run it per call. ran == true: code is the exit code, -1 error or -2 timeout. */
  static final class Result {
    final boolean ran;
    final int code;
    final byte[] out, err;
    final String reason; // why it was not run / how it ended ("" on success)
    Result(boolean ran, int code, byte[] out, byte[] err, String reason) {
      this.ran = ran; this.code = code; this.out = out; this.err = err; this.reason = reason;
    }
  }

  static Spawner suSpawner() { return () -> new ProcessBuilder("su").start(); }

  // ---- tunables (package-private so tests can shorten them) ----
  volatile long startupMs = 30000;   // max wait for the start-up check (a root prompt may be waiting for the user)
  volatile long busyWaitMs = 150;    // how long a call waits for the shell before the caller falls back to its own su
  volatile long idleMs = 60000;      // close the shell after this long without use
  volatile long backoffMs = 30000;   // after a failed start, do not try again for this long
  volatile long reapEveryMs = 5000;
  volatile int maxOut = 64 << 20;    // per stream; more than this kills the shell and reports an error
  volatile String expectUid = "0";
  static final int MAX_LINE = 120000;   // bytes; Linux refuses a single argument >= 128 KiB (same limit as the one-shot `su -c <line>`)

  private static final byte[] NONE = new byte[0];
  private static final SecureRandom RND = new SecureRandom();

  private final Spawner spawner;
  private final ReentrantLock gate = new ReentrantLock(true); // one command at a time, FIFO
  private final Object mon = new Object();                    // guards everything below it
  private Process proc;
  private OutputStream stdin;
  private boolean dead = true;
  private int eofs;                   // streams of the current shell that reached EOF (2 = fully drained)
  private int gen;
  private byte[] tok;                  // end marker of the command in flight (null = discard output)
  private byte[] outB = new byte[8192], errB = new byte[8192];
  private int outN, errN, outScan, errScan, outEnd, errEnd, codeVal;
  private boolean outDone, errDone, overflow;
  private volatile boolean closed;
  private volatile long lastUse, nextSpawnAt;
  private Thread reaper;
  private volatile String lastError = "";
  private final AtomicLong spawns = new AtomicLong(), runs = new AtomicLong(), fallbacks = new AtomicLong(), idleStops = new AtomicLong();

  RootShell(Spawner spawner) { this.spawner = spawner; }

  private static long ms() { return System.nanoTime() / 1000000L; }

  /** Runs shell code `line` (already carrying any `cd` prefix). timeoutMs <= 0 means no timeout. */
  Result run(String line, long timeoutMs) {
    if (closed) return skip("closed");
    if (line == null || line.indexOf('\0') >= 0 || line.length() > MAX_LINE || line.getBytes(StandardCharsets.UTF_8).length > MAX_LINE) return skip("unsupported command");
    boolean got;
    try { got = gate.tryLock(busyWaitMs, TimeUnit.MILLISECONDS); }
    catch (InterruptedException e) { Thread.currentThread().interrupt(); return skip("interrupted"); }
    if (!got) return skip("busy");
    try {
      String why = ensureAlive(timeoutMs);
      if (why != null) return skip(why);
      runs.incrementAndGet();
      Result r = exchange(line, timeoutMs);
      lastUse = ms();
      return r;
    } finally { gate.unlock(); }
  }

  boolean isAlive() { synchronized (mon) { return proc != null && !dead && proc.isAlive(); } }

  /** Closes the shell for good. */
  void close() {
    closed = true;
    killCurrent();
    Thread t = reaper;
    if (t != null) t.interrupt();
  }

  /** Small JSON status for diagnostics (never contains command text or output). */
  String info() {
    return "{\"alive\":" + isAlive() + ",\"spawns\":" + spawns.get() + ",\"runs\":" + runs.get() + ",\"fallbacks\":" + fallbacks.get()
      + ",\"idleStops\":" + idleStops.get() + ",\"lastError\":" + quote(lastError) + "}";
  }

  // ------------------------------------------------------------------ internals

  private Result skip(String why) {
    fallbacks.incrementAndGet();
    return new Result(false, 0, NONE, NONE, why);
  }

  /** Called with the gate held. budgetMs = the caller's timeout (<= 0: none). Returns null when a verified shell is running, otherwise the reason it is not usable. */
  private String ensureAlive(long budgetMs) {
    if (isAlive()) return null;
    killCurrent();                                   // clear a dead/half-dead shell
    long now = ms();
    if (now < nextSpawnAt) return "backoff: " + lastError;
    Process p;
    try { p = spawner.spawn(); }
    catch (Exception e) { return failStart("could not start su: " + e); }
    if (p == null) return failStart("could not start su");
    final int myGen;
    synchronized (mon) {
      proc = p; stdin = p.getOutputStream(); dead = false; eofs = 0; myGen = ++gen;
      // Output that arrives before the check (su's own error text) is kept for the failure reason.
      tok = newToken().getBytes(StandardCharsets.US_ASCII);
      outN = errN = outScan = errScan = outEnd = errEnd = codeVal = 0;
      outDone = errDone = overflow = false;
    }
    startPump(p.getInputStream(), false, myGen);
    startPump(p.getErrorStream(), true, myGen);
    // The start-up check may not hold a caller far beyond its own timeout, but su needs time to start: at least 3 s.
    long hs = startupMs;
    if (budgetMs > 0) hs = Math.min(hs, Math.max(budgetMs, 3000));
    Result h = exchange("id -u", hs, true);
    String why = null;
    if (h.code == -2) why = "root shell did not answer in time (is a root prompt waiting?)";
    else if (h.code != 0) why = "root shell not usable";
    else {
      String u = lastLine(new String(h.out, StandardCharsets.UTF_8));
      if (!u.equals(expectUid)) why = "shell is not root (uid " + clean(u, 20) + ")";
    }
    if (why != null) {
      String cap;
      synchronized (mon) { cap = clean(new String(errB, 0, errN, StandardCharsets.UTF_8), 120); }
      killCurrent();
      return failStart(cap.isEmpty() ? why : why + ": " + cap);
    }
    spawns.incrementAndGet();
    lastUse = ms();
    startReaper();
    return null;
  }

  private static String lastLine(String s) {
    String t = s.trim();
    int i = t.lastIndexOf('\n');
    return (i < 0 ? t : t.substring(i + 1)).trim();
  }

  /** mon held: waits (bounded) until both pipes of a dead shell are fully read, so its last words are not lost. */
  private void waitDrained(long maxMs) {
    long end = ms() + maxMs;
    try { while (eofs < 2 && ms() < end) mon.wait(50); }
    catch (InterruptedException e) { Thread.currentThread().interrupt(); }
  }

  private String failStart(String why) {
    lastError = clean(why, 200);
    nextSpawnAt = ms() + backoffMs;
    return lastError;
  }

  private static String clean(String s, int max) {
    StringBuilder b = new StringBuilder();
    for (int i = 0; i < s.length() && b.length() < max; i++) { char c = s.charAt(i); b.append(c < 32 || c == 127 ? ' ' : c); }
    return b.toString().trim();
  }

  private void startPump(final InputStream in, final boolean isErr, final int myGen) {
    Thread t = new Thread(() -> pump(in, isErr, myGen), isErr ? "RootShell-err" : "RootShell-out");
    t.setDaemon(true);
    t.start();
  }

  private void pump(InputStream in, boolean isErr, int myGen) {
    byte[] buf = new byte[16384];
    try {
      int n;
      while ((n = in.read(buf)) != -1) {
        synchronized (mon) {
          if (myGen != gen) return;
          if (tok != null && n > 0) append(isErr, buf, n);   // output while no command is running is dropped
          mon.notifyAll();
        }
      }
    } catch (IOException e) { /* stream closed */ }
    synchronized (mon) { if (myGen == gen) { eofs++; dead = true; mon.notifyAll(); } }
  }

  // ---- called with mon held ----
  private void append(boolean isErr, byte[] b, int n) {
    if (isErr ? errDone : outDone) return;
    if (isErr) {
      if (errN + n > errB.length) errB = Arrays.copyOf(errB, Math.max(errB.length * 2, errN + n));
      System.arraycopy(b, 0, errB, errN, n); errN += n;
      if (errN > maxOut) overflow = true;
      int i = indexOf(errB, errN, tok, errScan);
      if (i < 0) { errScan = Math.max(0, errN - tok.length + 1); return; }
      int p = i + tok.length;
      if (p < errN && errB[p] == '\n') { errEnd = i; errDone = true; } else errScan = i;
    } else {
      if (outN + n > outB.length) outB = Arrays.copyOf(outB, Math.max(outB.length * 2, outN + n));
      System.arraycopy(b, 0, outB, outN, n); outN += n;
      if (outN > maxOut) overflow = true;
      int i = indexOf(outB, outN, tok, outScan);
      if (i < 0) { outScan = Math.max(0, outN - tok.length + 1); return; }
      int p = i + tok.length, q = p, v = 0;
      while (q < outN && outB[q] >= '0' && outB[q] <= '9' && q - p < 4) { v = v * 10 + (outB[q] - '0'); q++; }
      if (q > p && q < outN && outB[q] == '\n') { outEnd = i; codeVal = v; outDone = true; }
      else if (q == outN) outScan = i;          // marker still arriving
      else outScan = i + 1;                      // malformed: keep looking
    }
  }

  private static int indexOf(byte[] h, int n, byte[] needle, int from) {
    outer:
    for (int i = from; i + needle.length <= n; i++) {
      for (int j = 0; j < needle.length; j++) if (h[i + j] != needle[j]) continue outer;
      return i;
    }
    return -1;
  }

  private static String shq(String s) { return "'" + s.replace("'", "'\\''") + "'"; }

  private static String newToken() {
    byte[] r = new byte[12];
    RND.nextBytes(r);
    StringBuilder b = new StringBuilder("@@MDRS");
    for (byte x : r) { b.append(Character.forDigit((x >> 4) & 15, 16)).append(Character.forDigit(x & 15, 16)); }
    return b.append('@').toString();
  }

  /** Gate held. Sends one wrapped command and waits for both end markers. Always ran == true. */
  private Result exchange(String line, long timeoutMs) { return exchange(line, timeoutMs, false); }

  /** keepEarly: the start-up check keeps what the shell printed before it (see ensureAlive). */
  private Result exchange(String line, long timeoutMs, boolean keepEarly) {
    String token = newToken();
    synchronized (mon) {
      if (dead || proc == null) {
        if (keepEarly) waitDrained(300);
        return new Result(true, -1, NONE, bytes("root shell is not running"), "died");
      }
      tok = token.getBytes(StandardCharsets.US_ASCII);
      if (!keepEarly) outN = errN = 0;
      outScan = errScan = outEnd = errEnd = codeVal = 0;
      outDone = errDone = overflow = false;
    }
    // sh -c isolates the command (exit/cd/vars/stdin); the two printf lines are the end markers (code on stdout, bare on stderr).
    String wrapped = "sh -c " + shq(line) + " </dev/null; R=$?; printf '%s%d\\n' " + shq(token) + " \"$R\"; printf '%s\\n' " + shq(token) + " >&2\n";
    try {
      OutputStream os = stdin;
      os.write(wrapped.getBytes(StandardCharsets.UTF_8));
      os.flush();
    } catch (IOException e) {
      if (keepEarly) synchronized (mon) { waitDrained(300); }
      killCurrent();
      return new Result(true, -1, NONE, bytes("root shell write failed: " + e), "io");
    }
    long deadline = timeoutMs > 0 ? ms() + timeoutMs : Long.MAX_VALUE;
    long exitSeen = 0;
    synchronized (mon) {
      try {
        while (true) {
          if (outDone && errDone) break;
          if (overflow) return finish(-1, "root shell output too large", "overflow");
          if (dead) { if (keepEarly) waitDrained(300); return finish(-1, "root shell exited unexpectedly", "died"); }
          long left = deadline == Long.MAX_VALUE ? 250 : deadline - ms();
          if (left <= 0) return finish(-2, "timeout", "timeout");
          mon.wait(Math.min(left, 250));
          if (!(outDone && errDone) && proc != null && !proc.isAlive()) {
            if (exitSeen == 0) exitSeen = ms();                       // let the pumps drain the pipes first
            else if (ms() - exitSeen > 1000) return finish(-1, "root shell exited unexpectedly", "died");
          }
        }
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        return finish(-1, "interrupted", "interrupted");
      }
      byte[] o = Arrays.copyOf(outB, outEnd), e = Arrays.copyOf(errB, errEnd);
      int c = codeVal;
      tok = null;
      return new Result(true, c, o, e, "");
    }
  }

  /** mon held. The command may have run, so the shell is dropped and the outcome is final. */
  private Result finish(int code, String msg, String reason) {
    byte[] o = Arrays.copyOf(outB, Math.min(outN, outDone ? outEnd : outN));
    killCurrent();
    return new Result(true, code, o, bytes(msg), reason);
  }

  private static byte[] bytes(String s) { return s.getBytes(StandardCharsets.UTF_8); }

  private void killCurrent() {
    Process p; OutputStream os;
    synchronized (mon) {
      p = proc; os = stdin; proc = null; stdin = null; dead = true; tok = null; gen++;
      mon.notifyAll();
    }
    if (os != null) { try { os.close(); } catch (IOException e) { /* already gone */ } }
    if (p != null) p.destroyForcibly();
  }

  private void startReaper() {
    if (reaper != null) return;
    Thread t = new Thread(() -> {
      while (!closed) {
        try { Thread.sleep(reapEveryMs); } catch (InterruptedException e) { return; }
        if (closed) return;
        if (gate.tryLock()) {                         // never waits behind a running command
          try {
            if (isAlive() && ms() - lastUse > idleMs) { killCurrent(); idleStops.incrementAndGet(); }
          } finally { gate.unlock(); }
        }
      }
    }, "RootShell-idle");
    t.setDaemon(true);
    reaper = t;
    t.start();
  }

  private static String quote(String s) {
    StringBuilder b = new StringBuilder("\"");
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      if (c == '"' || c == '\\') b.append('\\').append(c);
      else if (c < 32) b.append(String.format("\\u%04x", (int) c));
      else b.append(c);
    }
    return b.append('"').toString();
  }
}
