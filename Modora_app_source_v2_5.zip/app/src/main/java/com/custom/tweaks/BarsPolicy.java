package com.custom.tweaks;

/**
 * MB7.3: pure decisions for the system bars (no Android classes, so they can be unit tested off-device).
 *  - parseColor(): "#RRGGBB" / "#RGB" (also without "#") -> 0xFFRRGGBB, or NO_COLOR when invalid. Never throws.
 *  - lightIcons(): true when the bars' icons should be LIGHT (white) because the bar background is dark.
 *  - pad(): the padding the page container needs so web content never sits under a system bar / cutout / keyboard.
 */
final class BarsPolicy {
  private BarsPolicy() {}

  static final int DEFAULT_BG = 0xFF060B1C; // = --md-bg / --bg of the pages, the theme windowBackground and the WebView background
  static final int NO_COLOR = 0;            // alpha is always 0xFF for a valid colour, so 0 can never be a valid result

  static int parseColor(String s) {
    if (s == null) return NO_COLOR;
    s = s.trim();
    if (s.startsWith("#")) s = s.substring(1);
    if (s.length() == 3) {
      StringBuilder b = new StringBuilder(6);
      for (int i = 0; i < 3; i++) { char c = s.charAt(i); b.append(c).append(c); }
      s = b.toString();
    }
    if (s.length() != 6) return NO_COLOR;
    int v = 0;
    for (int i = 0; i < 6; i++) {
      int d = Character.digit(s.charAt(i), 16);
      if (d < 0) return NO_COLOR;
      v = (v << 4) | d;
    }
    return 0xFF000000 | v;
  }

  private static double chan(int c) { double x = c / 255.0; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4); }

  /** WCAG relative luminance of an RGB colour (alpha ignored). */
  static double luminance(int argb) {
    return 0.2126 * chan((argb >> 16) & 0xFF) + 0.7152 * chan((argb >> 8) & 0xFF) + 0.0722 * chan(argb & 0xFF);
  }

  /** WCAG contrast ratio, 1..21. */
  static double contrast(int a, int b) {
    double la = luminance(a), lb = luminance(b);
    double hi = Math.max(la, lb), lo = Math.min(la, lb);
    return (hi + 0.05) / (lo + 0.05);
  }

  /** true = white icons (dark bar), false = dark icons (light bar). Picks whichever has the higher contrast. */
  static boolean lightIcons(int bgArgb) {
    return contrast(bgArgb, 0xFFFFFFFF) >= contrast(bgArgb, 0xFF000000);
  }

  /** Inset values in px (any may be negative/garbage from a buggy ROM: they are clamped to >= 0). */
  static int[] pad(int barL, int barT, int barR, int barB, int cutL, int cutT, int cutR, int cutB, int imeB) {
    int l = Math.max(0, Math.max(barL, cutL));
    int t = Math.max(0, Math.max(barT, cutT));
    int r = Math.max(0, Math.max(barR, cutR));
    int b = Math.max(0, Math.max(Math.max(barB, cutB), imeB)); // keyboard replaces the nav bar inset, it does not add to it
    return new int[] { l, t, r, b };
  }
}
